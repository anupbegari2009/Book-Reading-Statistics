import React, {useState} from 'react';
import {AlertCircle, CheckCircle2} from 'lucide-react';
import {AppSettings, GENRES, NavSection, READING_STATUSES, ReadingStatus} from '../types';

export function AddBookView({
  settings,
  onAddBook,
  onNavigate,
}: {
  settings: AppSettings;
  onAddBook: (
    payload: Record<string, unknown>,
    allowDuplicate: boolean,
  ) => Promise<{ok: boolean; errors: string[]}>;
  onNavigate: (section: NavSection) => void;
}) {
  const today = new Date().toISOString().slice(0, 10);
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [genre, setGenre] = useState<string>(GENRES[0]);
  const [pages, setPages] = useState('');
  const [status, setStatus] = useState<ReadingStatus>('Completed');
  const [startDate, setStartDate] = useState(today);
  const [completionDate, setCompletionDate] = useState(today);
  const [rating, setRating] = useState('4.5');
  const [notes, setNotes] = useState('');
  const [allowDuplicate, setAllowDuplicate] = useState(false);

  const [errors, setErrors] = useState<string[]>([]);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleStatusChange = (nextStatus: ReadingStatus) => {
    setStatus(nextStatus);
    if (nextStatus === 'Completed' && !completionDate) {
      setCompletionDate(today);
    } else if (nextStatus !== 'Completed') {
      setCompletionDate('');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors([]);
    setSuccessMsg(null);
    setSubmitting(true);

    const result = await onAddBook(
      {
        title,
        author,
        genre,
        pages,
        status,
        start_date: startDate,
        completion_date: completionDate,
        rating,
        notes,
      },
      allowDuplicate,
    );

    setSubmitting(false);
    if (!result.ok) {
      setErrors(result.errors);
      return;
    }

    setSuccessMsg(`Saved '${title.trim()}' by ${author.trim()} to your reading library.`);
    setTitle('');
    setAuthor('');
    setPages('');
    setNotes('');
    setAllowDuplicate(false);
  };

  return (
    <div className="max-w-3xl space-y-6">
      <div className="bg-white border border-slate-200 rounded-lg p-6">
        <div className="mb-6">
          <h2 className="text-lg font-semibold text-slate-900 font-display">Record a New Book</h2>
          <p className="text-sm text-slate-500 mt-1">
            All fields are validated for positive page counts, date order, rating bounds, and
            duplicate records before persisting.
          </p>
        </div>

        {errors.length > 0 && (
          <div className="mb-5 bg-red-50 border border-red-200 rounded-md p-4">
            <div className="flex items-center gap-2 text-sm font-medium text-red-800 mb-1.5">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>Please resolve the following validation errors:</span>
            </div>
            <ul className="list-disc pl-5 text-xs text-red-700 space-y-1">
              {errors.map((err, i) => (
                <li key={i}>{err}</li>
              ))}
            </ul>
          </div>
        )}

        {successMsg && (
          <div className="mb-5 bg-teal-50 border border-teal-200 rounded-md p-4 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-sm text-teal-900">
              <CheckCircle2 className="w-4 h-4 text-teal-700 shrink-0" />
              <span>{successMsg}</span>
            </div>
            <div className="flex items-center gap-3 text-xs font-medium">
              <button
                type="button"
                onClick={() => onNavigate('library')}
                className="text-teal-800 hover:underline cursor-pointer"
              >
                View in My Library
              </button>
              <button
                type="button"
                onClick={() => onNavigate('dashboard')}
                className="text-blue-900 hover:underline cursor-pointer"
              >
                Open Dashboard
              </button>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="book-title" className="block text-xs font-medium text-slate-700 mb-1">
                Book Title *
              </label>
              <input
                id="book-title"
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., Storytelling with Data"
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-900/20 focus:border-blue-900"
              />
            </div>

            <div>
              <label htmlFor="book-author" className="block text-xs font-medium text-slate-700 mb-1">
                Author Name *
              </label>
              <input
                id="book-author"
                type="text"
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
                placeholder="e.g., Cole Nussbaumer Knaflic"
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-900/20 focus:border-blue-900"
              />
            </div>

            <div>
              <label htmlFor="book-genre" className="block text-xs font-medium text-slate-700 mb-1">
                Genre *
              </label>
              <select
                id="book-genre"
                value={genre}
                onChange={(e) => setGenre(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-blue-900/20 focus:border-blue-900"
              >
                {GENRES.map((g) => (
                  <option key={g} value={g}>
                    {g}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="book-pages" className="block text-xs font-medium text-slate-700 mb-1">
                Total Pages *
              </label>
              <input
                id="book-pages"
                type="text"
                value={pages}
                onChange={(e) => setPages(e.target.value)}
                placeholder="Positive integer (e.g., 288)"
                className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-900/20 focus:border-blue-900"
              />
            </div>

            <div>
              <label htmlFor="book-status" className="block text-xs font-medium text-slate-700 mb-1">
                Reading Status *
              </label>
              <select
                id="book-status"
                value={status}
                onChange={(e) => handleStatusChange(e.target.value as ReadingStatus)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-blue-900/20 focus:border-blue-900"
              >
                {READING_STATUSES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="book-rating" className="block text-xs font-medium text-slate-700 mb-1">
                Personal Rating ({settings.rating_min}–{settings.rating_max}, optional)
              </label>
              <input
                id="book-rating"
                type="text"
                value={rating}
                onChange={(e) => setRating(e.target.value)}
                placeholder="e.g., 4.5"
                className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-900/20 focus:border-blue-900"
              />
            </div>

            <div>
              <label htmlFor="book-start" className="block text-xs font-medium text-slate-700 mb-1">
                Start Date *
              </label>
              <input
                id="book-start"
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-900/20 focus:border-blue-900"
              />
            </div>

            <div>
              <label htmlFor="book-comp" className="block text-xs font-medium text-slate-700 mb-1">
                Completion Date {status === 'Completed' ? '*' : '(optional)'}
              </label>
              <input
                id="book-comp"
                type="date"
                value={completionDate}
                onChange={(e) => setCompletionDate(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-900/20 focus:border-blue-900"
              />
            </div>
          </div>

          <div>
            <label htmlFor="book-notes" className="block text-xs font-medium text-slate-700 mb-1">
              Optional Notes
            </label>
            <textarea
              id="book-notes"
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Key takeaways, themes, or reading context..."
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-900/20 focus:border-blue-900"
            />
          </div>

          <label className="flex items-center gap-2 text-xs text-slate-600 cursor-pointer">
            <input
              type="checkbox"
              checked={allowDuplicate}
              onChange={(e) => setAllowDuplicate(e.target.checked)}
              className="rounded border-slate-300"
            />
            <span>Allow saving even if a book with the same title and author already exists</span>
          </label>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={() => {
                setTitle('');
                setAuthor('');
                setPages('');
                setNotes('');
                setErrors([]);
                setSuccessMsg(null);
              }}
              className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-50 cursor-pointer"
            >
              Reset Form
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 text-xs font-medium text-white bg-blue-900 rounded-md hover:bg-blue-800 transition-colors cursor-pointer disabled:opacity-50"
            >
              {submitting ? 'Validating & Saving...' : 'Save Book Record'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
