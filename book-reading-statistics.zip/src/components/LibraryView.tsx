import React, {useMemo, useState} from 'react';
import {ChevronLeft, ChevronRight, Eye, Pencil, Search, Trash2} from 'lucide-react';
import {AppSettings, BookRecord, GENRES, NavSection, READING_STATUSES} from '../types';

type SortOption =
  | 'date_desc'
  | 'date_asc'
  | 'title_asc'
  | 'title_desc'
  | 'pages_desc'
  | 'pages_asc'
  | 'rating_desc';

export function LibraryView({
  books,
  settings,
  onSelectBook,
  onEditBook,
  onRequestDelete,
  onNavigate,
}: {
  books: BookRecord[];
  settings: AppSettings;
  onSelectBook: (book: BookRecord) => void;
  onEditBook: (book: BookRecord) => void;
  onRequestDelete: (book: BookRecord) => void;
  onNavigate: (section: NavSection) => void;
}) {
  const [query, setQuery] = useState('');
  const [genre, setGenre] = useState('All');
  const [status, setStatus] = useState('All');
  const [year, setYear] = useState('All');
  const [month, setMonth] = useState('All');
  const [sortBy, setSortBy] = useState<SortOption>('date_desc');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(settings.default_page_size || 12);

  const availableYears = useMemo(() => {
    const yrs = new Set<string>();
    books.forEach((b) => {
      const ref = b.completion_date || b.start_date;
      if (ref && /^\d{4}/.test(ref)) yrs.add(ref.slice(0, 4));
    });
    return Array.from(yrs).sort((a, b) => Number(b) - Number(a));
  }, [books]);

  const filtered = useMemo(() => {
    let list = [...books];
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      list = list.filter(
        (b) =>
          b.title.toLowerCase().includes(q) ||
          b.author.toLowerCase().includes(q) ||
          b.notes.toLowerCase().includes(q),
      );
    }
    if (genre !== 'All') list = list.filter((b) => b.genre === genre);
    if (status !== 'All') list = list.filter((b) => b.status === status);
    if (year !== 'All') {
      list = list.filter((b) => (b.completion_date || b.start_date).startsWith(`${year}-`));
    }
    if (month !== 'All') {
      list = list.filter((b) => (b.completion_date || b.start_date).slice(5, 7) === month);
    }

    list.sort((a, b) => {
      switch (sortBy) {
        case 'title_asc':
          return a.title.localeCompare(b.title);
        case 'title_desc':
          return b.title.localeCompare(a.title);
        case 'pages_desc':
          return b.pages - a.pages;
        case 'pages_asc':
          return a.pages - b.pages;
        case 'rating_desc':
          return (b.rating ?? -1) - (a.rating ?? -1);
        case 'date_asc':
          return (a.completion_date || a.start_date).localeCompare(
            b.completion_date || b.start_date,
          );
        case 'date_desc':
        default:
          return (b.completion_date || b.start_date).localeCompare(
            a.completion_date || a.start_date,
          );
      }
    });
    return list;
  }, [books, query, genre, status, year, month, sortBy]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const paginated = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  if (books.length === 0) {
    return (
      <div className="bg-white border border-slate-200 rounded-lg p-10 text-center max-w-xl mx-auto mt-6">
        <h3 className="text-lg font-semibold text-slate-900 font-display">No Stored Books</h3>
        <p className="text-sm text-slate-600 mt-1.5">
          Your library is currently empty. Add a book or import a CSV dataset to populate this
          table.
        </p>
        <button
          type="button"
          onClick={() => onNavigate('add-book')}
          className="mt-5 px-4 py-2 text-xs font-medium text-white bg-blue-900 rounded-md hover:bg-blue-800 cursor-pointer"
        >
          Add a Book
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="bg-white border border-slate-200 rounded-lg p-4 space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          <div className="md:col-span-4 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setPage(1);
              }}
              placeholder="Search title, author, or notes..."
              className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-900/20 focus:border-blue-900"
            />
          </div>

          <div className="md:col-span-2">
            <select
              value={genre}
              onChange={(e) => {
                setGenre(e.target.value);
                setPage(1);
              }}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md bg-white"
              aria-label="Filter by genre"
            >
              <option value="All">All Genres</option>
              {GENRES.map((g) => (
                <option key={g} value={g}>
                  {g}
                </option>
              ))}
            </select>
          </div>

          <div className="md:col-span-2">
            <select
              value={status}
              onChange={(e) => {
                setStatus(e.target.value);
                setPage(1);
              }}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md bg-white"
              aria-label="Filter by status"
            >
              <option value="All">All Statuses</option>
              {READING_STATUSES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>

          <div className="md:col-span-2">
            <select
              value={year}
              onChange={(e) => {
                setYear(e.target.value);
                setPage(1);
              }}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md bg-white"
              aria-label="Filter by year"
            >
              <option value="All">All Years</option>
              {availableYears.map((y) => (
                <option key={y} value={y}>
                  {y}
                </option>
              ))}
            </select>
          </div>

          <div className="md:col-span-2">
            <select
              value={month}
              onChange={(e) => {
                setMonth(e.target.value);
                setPage(1);
              }}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md bg-white"
              aria-label="Filter by month"
            >
              <option value="All">All Months</option>
              {[
                '01 Jan',
                '02 Feb',
                '03 Mar',
                '04 Apr',
                '05 May',
                '06 Jun',
                '07 Jul',
                '08 Aug',
                '09 Sep',
                '10 Oct',
                '11 Nov',
                '12 Dec',
              ].map((label) => {
                const [val, name] = label.split(' ');
                return (
                  <option key={val} value={val}>
                    {name}
                  </option>
                );
              })}
            </select>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 text-xs text-slate-600">
          <div className="flex items-center gap-3">
            <span className="font-mono">
              Showing {paginated.length} of {filtered.length} records
            </span>
            {(query || genre !== 'All' || status !== 'All' || year !== 'All' || month !== 'All') && (
              <button
                type="button"
                onClick={() => {
                  setQuery('');
                  setGenre('All');
                  setStatus('All');
                  setYear('All');
                  setMonth('All');
                  setPage(1);
                }}
                className="text-blue-900 hover:underline font-medium cursor-pointer"
              >
                Reset Filters
              </button>
            )}
          </div>

          <div className="flex items-center gap-3">
            <label className="flex items-center gap-1.5">
              <span>Sort:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as SortOption)}
                className="px-2 py-1 border border-slate-300 rounded bg-white text-slate-800"
              >
                <option value="date_desc">Date (Newest)</option>
                <option value="date_asc">Date (Oldest)</option>
                <option value="title_asc">Title (A–Z)</option>
                <option value="title_desc">Title (Z–A)</option>
                <option value="pages_desc">Pages (High–Low)</option>
                <option value="pages_asc">Pages (Low–High)</option>
                <option value="rating_desc">Rating (High–Low)</option>
              </select>
            </label>

            <label className="flex items-center gap-1.5">
              <span>Rows:</span>
              <select
                value={pageSize}
                onChange={(e) => {
                  setPageSize(Number(e.target.value));
                  setPage(1);
                }}
                className="px-2 py-1 border border-slate-300 rounded bg-white text-slate-800 font-mono"
              >
                {[10, 12, 20, 50].map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            </label>
          </div>
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-xs font-medium text-slate-500">
                <th className="py-2.5 px-4">Title</th>
                <th className="py-2.5 px-4">Author</th>
                <th className="py-2.5 px-4">Genre</th>
                <th className="py-2.5 px-4 text-right">Pages</th>
                <th className="py-2.5 px-4">Status</th>
                <th className="py-2.5 px-4 text-right">Completed</th>
                <th className="py-2.5 px-4 text-right">Rating</th>
                <th className="py-2.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {paginated.map((book) => (
                <tr key={book.id} className="hover:bg-slate-50 transition-colors">
                  <td
                    onClick={() => onSelectBook(book)}
                    className="py-2.5 px-4 font-medium text-slate-900 cursor-pointer hover:text-blue-900"
                  >
                    {book.title}
                  </td>
                  <td className="py-2.5 px-4 text-slate-600">{book.author}</td>
                  <td className="py-2.5 px-4 text-slate-600">{book.genre}</td>
                  <td className="py-2.5 px-4 text-right font-mono text-slate-800">
                    {book.pages.toLocaleString()}
                  </td>
                  <td className="py-2.5 px-4 text-xs font-medium">
                    <span
                      className={
                        book.status === 'Completed'
                          ? 'text-teal-700'
                          : book.status === 'Currently Reading'
                            ? 'text-blue-700'
                            : 'text-slate-500'
                      }
                    >
                      {book.status}
                    </span>
                  </td>
                  <td className="py-2.5 px-4 text-right font-mono text-xs text-slate-600">
                    {book.completion_date ?? '-'}
                  </td>
                  <td className="py-2.5 px-4 text-right font-mono text-xs text-slate-800">
                    {book.rating !== null ? book.rating.toFixed(1) : '-'}
                  </td>
                  <td className="py-2.5 px-4 text-right">
                    <div className="inline-flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => onSelectBook(book)}
                        className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded cursor-pointer"
                        title="View details"
                        aria-label={`View ${book.title}`}
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => onEditBook(book)}
                        className="p-1.5 text-slate-500 hover:text-blue-900 hover:bg-slate-100 rounded cursor-pointer"
                        title="Edit record"
                        aria-label={`Edit ${book.title}`}
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => onRequestDelete(book)}
                        className="p-1.5 text-slate-500 hover:text-red-700 hover:bg-red-50 rounded cursor-pointer"
                        title="Delete record"
                        aria-label={`Delete ${book.title}`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {paginated.length === 0 && (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-sm text-slate-500">
                    No books match the current filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Footer */}
        <div className="flex items-center justify-between px-4 py-3 border-t border-slate-200 bg-slate-50 text-xs text-slate-600">
          <span className="font-mono">
            Page {currentPage} of {totalPages}
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={currentPage <= 1}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-white border border-slate-300 rounded hover:bg-slate-100 disabled:opacity-40 cursor-pointer"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              <span>Previous</span>
            </button>
            <button
              type="button"
              disabled={currentPage >= totalPages}
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-white border border-slate-300 rounded hover:bg-slate-100 disabled:opacity-40 cursor-pointer"
            >
              <span>Next</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
