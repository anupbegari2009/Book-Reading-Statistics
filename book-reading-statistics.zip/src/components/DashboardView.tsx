import React, {useState} from 'react';
import {AlertTriangle, ChevronDown, ChevronUp, Info} from 'lucide-react';
import {AnalyticsPayload, AppSettings, BookRecord, NavSection} from '../types';
import {GenreDonutChart, MonthlyBooksBarChart, MonthlyPagesLineChart} from './Charts';

export function DashboardView({
  books,
  analytics,
  settings,
  onNavigate,
  onSelectBook,
  onLoadSample,
}: {
  books: BookRecord[];
  analytics: AnalyticsPayload;
  settings: AppSettings;
  onNavigate: (section: NavSection) => void;
  onSelectBook: (book: BookRecord) => void;
  onLoadSample: () => void;
}) {
  const [warningsExpanded, setWarningsExpanded] = useState(false);
  const {kpis, monthly, genres, insights, warnings, startup_warnings} = analytics;

  const recentBooks = [...books]
    .sort((a, b) => (b.completion_date || b.start_date).localeCompare(a.completion_date || a.start_date))
    .slice(0, 7);

  if (books.length === 0) {
    return (
      <div className="space-y-6">
        {startup_warnings.length > 0 && (
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 text-sm text-amber-900">
            {startup_warnings.map((w, i) => (
              <p key={i}>{w}</p>
            ))}
          </div>
        )}

        <div className="bg-white border border-slate-200 rounded-lg p-10 text-center max-w-2xl mx-auto mt-8">
          <h2 className="text-xl font-semibold text-slate-900 font-display">
            Your Reading Library is Empty
          </h2>
          <p className="text-sm text-slate-600 mt-2 leading-relaxed">
            Record your first book to populate monthly activity trends, page velocity metrics, and
            genre breakdowns, or load the bundled 40-book demonstration dataset.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3 mt-6">
            <button
              type="button"
              onClick={() => onNavigate('add-book')}
              className="px-4 py-2 text-sm font-medium text-white bg-blue-900 rounded-md hover:bg-blue-800 transition-colors cursor-pointer"
            >
              Log First Book
            </button>
            <button
              type="button"
              onClick={onLoadSample}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-md hover:bg-slate-50 transition-colors cursor-pointer"
            >
              Load Sample Dataset (40 Books)
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {startup_warnings.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 text-sm text-amber-900 space-y-1">
          {startup_warnings.map((w, i) => (
            <p key={i}>{w}</p>
          ))}
        </div>
      )}

      {warnings.length > 0 && (
        <div className="bg-white border border-slate-200 rounded-lg">
          <button
            type="button"
            onClick={() => setWarningsExpanded((v) => !v)}
            className="w-full flex items-center justify-between px-5 py-3 text-left hover:bg-slate-50 transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-2.5 text-sm">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
              <span className="font-medium text-slate-900">
                Active Threshold &amp; Data Quality Notices
              </span>
              <span className="text-slate-400">·</span>
              <span className="text-xs font-mono text-slate-600">{warnings.length} items</span>
            </div>
            {warningsExpanded ? (
              <ChevronUp className="w-4 h-4 text-slate-500" />
            ) : (
              <ChevronDown className="w-4 h-4 text-slate-500" />
            )}
          </button>
          {warningsExpanded && (
            <div className="border-t border-slate-200 divide-y divide-slate-100">
              {warnings.map((w, idx) => (
                <div key={idx} className="px-5 py-2.5 flex items-start gap-2.5 text-xs">
                  {w.severity === 'error' ? (
                    <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                  ) : w.severity === 'warning' ? (
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  ) : (
                    <Info className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
                  )}
                  <span className="font-mono text-slate-500 shrink-0">{w.code}</span>
                  <span className="text-slate-700">{w.message}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 6 Dynamic KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200 rounded-lg p-5">
          <p className="text-xs font-medium text-slate-500">Total Books Read</p>
          <p className="text-3xl font-semibold text-slate-900 font-mono mt-2">
            {kpis.total_books_read}
          </p>
          <p className="text-xs text-slate-500 mt-1.5">
            {kpis.currently_reading_count} currently reading · {kpis.planned_count} planned
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-5">
          <p className="text-xs font-medium text-slate-500">Total Pages Read</p>
          <p className="text-3xl font-semibold text-slate-900 font-mono mt-2">
            {kpis.total_pages_read.toLocaleString()}
          </p>
          <p className="text-xs text-slate-500 mt-1.5">
            Across {kpis.total_books_read} completed books
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-5">
          <p className="text-xs font-medium text-slate-500">Average Pages per Book</p>
          <p className="text-3xl font-semibold text-slate-900 font-mono mt-2">
            {kpis.average_pages.toLocaleString()}
          </p>
          <p className="text-xs text-slate-500 mt-1.5">
            Avg rating:{' '}
            {kpis.average_rating !== null ? `${kpis.average_rating.toFixed(2)} / 5.0` : 'Unrated'}
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-5">
          <p className="text-xs font-medium text-slate-500">Total Genres Explored</p>
          <p className="text-3xl font-semibold text-slate-900 font-mono mt-2">
            {kpis.genres_explored}
          </p>
          <p className="text-xs text-slate-500 mt-1.5">
            {kpis.total_stored} total records in database
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-5">
          <p className="text-xs font-medium text-slate-500">
            Books Read This Month ({kpis.reference_month_label})
          </p>
          <p className="text-3xl font-semibold text-slate-900 font-mono mt-2">
            {kpis.books_this_month}
          </p>
          <p className="text-xs text-slate-500 mt-1.5">
            {kpis.pages_this_month.toLocaleString()} pages · Target {settings.monthly_book_target}{' '}
            books
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-5">
          <p className="text-xs font-medium text-slate-500">
            Reading Activity ({kpis.reference_year})
          </p>
          <p className="text-3xl font-semibold text-slate-900 font-mono mt-2">
            {kpis.books_this_year} <span className="text-base font-normal text-slate-500">books</span>
          </p>
          <p className="text-xs text-slate-500 mt-1.5">
            {kpis.pages_this_year.toLocaleString()} pages completed this year
          </p>
        </div>
      </div>

      {/* Charts A & B */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <MonthlyBooksBarChart data={monthly} limit={12} />
        <MonthlyPagesLineChart data={monthly} limit={12} />
      </div>

      {/* Chart C + Insights E */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7">
          <GenreDonutChart data={genres} />
        </div>
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-lg p-5 flex flex-col">
          <h3 className="text-base font-semibold text-slate-900 font-display">Reading Insights</h3>
          <p className="text-xs text-slate-500 mt-0.5 mb-4">
            Observations derived directly from stored records
          </p>
          <ul className="space-y-3 text-sm text-slate-700 leading-relaxed flex-1">
            {insights.observations.map((obs, idx) => (
              <li key={idx} className="pb-3 border-b border-slate-100 last:border-b-0 last:pb-0">
                {obs}
              </li>
            ))}
          </ul>
          <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-500">Monthly Avg Pace</span>
            <span className="font-mono font-semibold text-slate-900">
              {insights.avg_books_per_active_month} books ·{' '}
              {insights.avg_pages_per_active_month.toLocaleString()} pages/mo
            </span>
          </div>
        </div>
      </div>

      {/* D. Recent Reading Activity */}
      <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200">
          <div>
            <h3 className="text-base font-semibold text-slate-900 font-display">
              Recent Reading Activity
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Latest books recorded or completed; click any row to inspect details
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('library')}
            className="text-xs font-medium text-blue-900 hover:underline whitespace-nowrap shrink-0 cursor-pointer"
          >
            View All Library
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-xs font-medium text-slate-500">
                <th className="py-2.5 px-5">Book Title</th>
                <th className="py-2.5 px-4">Author</th>
                <th className="py-2.5 px-4">Genre</th>
                <th className="py-2.5 px-4 text-right">Pages</th>
                <th className="py-2.5 px-4">Status</th>
                <th className="py-2.5 px-5 text-right">Completion Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {recentBooks.map((book) => (
                <tr
                  key={book.id}
                  onClick={() => onSelectBook(book)}
                  className="hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  <td className="py-2.5 px-5 font-medium text-slate-900">{book.title}</td>
                  <td className="py-2.5 px-4 text-slate-600">{book.author}</td>
                  <td className="py-2.5 px-4 text-slate-600">{book.genre}</td>
                  <td className="py-2.5 px-4 text-right font-mono text-slate-800">
                    {book.pages.toLocaleString()}
                  </td>
                  <td className="py-2.5 px-4 text-xs font-medium">
                    <span
                      className={
                        book.status === 'Completed'
                          ? 'text-teal-700'
                          : book.status === 'Currently Reading'
                            ? 'text-blue-700'
                            : 'text-slate-500'
                      }
                    >
                      {book.status}
                    </span>
                  </td>
                  <td className="py-2.5 px-5 text-right font-mono text-xs text-slate-600">
                    {book.completion_date ?? 'In Progress'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
