import React, {useState} from 'react';
import {AlertCircle, CheckCircle2, Download, Upload} from 'lucide-react';
import {AnalyticsPayload, AppSettings, BookRecord, ImportSummary} from '../types';
import {downloadTextFile} from '../utils/exportHelpers';
import {
  GenreDonutChart,
  MonthlyBooksBarChart,
  MonthlyPagesLineChart,
  YearlyComparisonChart,
} from './Charts';

export function ImportDatasetView({
  onImportCsv,
}: {
  onImportCsv: (
    csvText: string,
    skipDuplicates: boolean,
  ) => Promise<{ok: boolean; error?: string; summary?: ImportSummary}>;
}) {
  const [csvText, setCsvText] = useState('');
  const [fileName, setFileName] = useState<string | null>(null);
  const [skipDuplicates, setSkipDuplicates] = useState(true);
  const [loading, setLoading] = useState(false);
  const [headerError, setHeaderError] = useState<string | null>(null);
  const [summary, setSummary] = useState<ImportSummary | null>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    const content = await file.text();
    setCsvText(content);
    setHeaderError(null);
    setSummary(null);
  };

  const handleLoadTestCsvWithBadRow = () => {
    const sampleCsv = [
      'title,author,genre,pages,status,start_date,completion_date,rating,notes',
      'The Art of Statistics,David Spiegelhalter,Science,448,Completed,2026-11-01,2026-11-18,4.8,"Clear applied probability and inference."',
      ',Missing Title Example,Fiction,210,Planned,2026-11-10,,,"Should fail row validation cleanly"',
      'Negative Pages Example,Test Author,Technology,-120,Planned,2026-11-10,,,"Should fail negative pages check"',
      'Bad Date Order,Test Author,History,310,Completed,2026-11-20,2026-11-05,4.0,"Completion precedes start"',
    ].join('\n');
    setFileName('validation_demo.csv');
    setCsvText(sampleCsv);
    setHeaderError(null);
    setSummary(null);
  };

  const handleRunImport = async () => {
    setLoading(true);
    setHeaderError(null);
    const res = await onImportCsv(csvText, skipDuplicates);
    setLoading(false);
    if (!res.ok) {
      setHeaderError(res.error || 'Import failed.');
    }
    if (res.summary) {
      setSummary(res.summary);
    }
  };

  return (
    <div className="max-w-4xl space-y-6">
      <div className="bg-white border border-slate-200 rounded-lg p-6 space-y-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h2 className="text-lg font-semibold text-slate-900 font-display">
              Bulk CSV Dataset Import
            </h2>
            <p className="text-sm text-slate-500 mt-1">
              Validates headers, checks every row independently, skips duplicates, and imports valid
              records even if some rows contain errors.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <a
              href="/api/sample-csv"
              download="sample_books.csv"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-md hover:bg-slate-50"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Sample CSV</span>
            </a>
            <button
              type="button"
              onClick={handleLoadTestCsvWithBadRow}
              className="px-3 py-1.5 text-xs font-medium text-blue-900 bg-blue-50 border border-blue-200 rounded-md hover:bg-blue-100 cursor-pointer"
            >
              Load Mixed Valid/Invalid CSV Demo
            </button>
          </div>
        </div>

        <div className="border border-dashed border-slate-300 rounded-lg p-6 bg-slate-50/70">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <p className="text-sm font-medium text-slate-800">
                {fileName ? `Selected file: ${fileName}` : 'Choose a CSV file to upload'}
              </p>
              <p className="text-xs text-slate-500 mt-0.5">
                Required columns: title, author, genre, pages, status, start_date
              </p>
            </div>
            <label className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-slate-900 rounded-md hover:bg-slate-800 cursor-pointer whitespace-nowrap shrink-0">
              <Upload className="w-3.5 h-3.5" />
              <span>Select CSV File</span>
              <input type="file" accept=".csv,text/csv" onChange={handleFileChange} className="hidden" />
            </label>
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-700 mb-1">
            CSV Payload Preview / Direct Paste
          </label>
          <textarea
            rows={6}
            value={csvText}
            onChange={(e) => setCsvText(e.target.value)}
            placeholder="Paste CSV content or select a .csv file above..."
            className="w-full px-3 py-2 text-xs font-mono border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-900/20 focus:border-blue-900"
          />
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
          <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={skipDuplicates}
              onChange={(e) => setSkipDuplicates(e.target.checked)}
              className="rounded border-slate-300"
            />
            <span>Skip duplicate records matching existing Title + Author</span>
          </label>

          <button
            type="button"
            disabled={!csvText.trim() || loading}
            onClick={handleRunImport}
            className="px-5 py-2 text-xs font-medium text-white bg-blue-900 rounded-md hover:bg-blue-800 disabled:opacity-40 cursor-pointer"
          >
            {loading ? 'Importing...' : 'Validate & Import Rows'}
          </button>
        </div>

        {headerError && (
          <div className="bg-red-50 border border-red-200 rounded-md p-3 flex items-center gap-2 text-xs text-red-800">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{headerError}</span>
          </div>
        )}
      </div>

      {summary && (
        <div className="bg-white border border-slate-200 rounded-lg p-6 space-y-4">
          <div className="flex items-center gap-2 text-base font-semibold text-slate-900 font-display">
            <CheckCircle2 className="w-5 h-5 text-teal-700" />
            <span>Import Execution Summary</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="border border-slate-200 rounded-md p-3">
              <p className="text-xs text-slate-500">Total Rows Processed</p>
              <p className="text-2xl font-semibold font-mono text-slate-900 mt-1">
                {summary.total_rows}
              </p>
            </div>
            <div className="border border-slate-200 rounded-md p-3">
              <p className="text-xs text-slate-500">Successfully Imported</p>
              <p className="text-2xl font-semibold font-mono text-teal-700 mt-1">
                {summary.imported_count}
              </p>
            </div>
            <div className="border border-slate-200 rounded-md p-3">
              <p className="text-xs text-slate-500">Duplicates Skipped</p>
              <p className="text-2xl font-semibold font-mono text-amber-700 mt-1">
                {summary.duplicate_count}
              </p>
            </div>
            <div className="border border-slate-200 rounded-md p-3">
              <p className="text-xs text-slate-500">Invalid Rows Rejected</p>
              <p className="text-2xl font-semibold font-mono text-red-700 mt-1">
                {summary.failed_count}
              </p>
            </div>
          </div>

          {summary.errors.length > 0 && (
            <div className="border border-slate-200 rounded-md overflow-hidden">
              <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-200 text-xs font-medium text-slate-700">
                Row-by-Row Validation &amp; Duplicate Report
              </div>
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500">
                    <th className="py-2 px-4 w-20">Row #</th>
                    <th className="py-2 px-4">Title</th>
                    <th className="py-2 px-4">Reason</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {summary.errors.map((err, idx) => (
                    <tr key={idx}>
                      <td className="py-2 px-4 font-mono text-slate-700">{err.row_number}</td>
                      <td className="py-2 px-4 font-medium text-slate-900">{err.title}</td>
                      <td className="py-2 px-4 text-red-700">{err.reason}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export function ExportReportsView({
  books,
  analytics,
}: {
  books: BookRecord[];
  analytics: AnalyticsPayload;
}) {
  const [scope, setScope] = useState<'all' | 'completed'>('all');
  const [previewFormat, setPreviewFormat] = useState<'markdown' | 'txt' | 'csv' | 'json'>('markdown');
  const [previewContent, setPreviewContent] = useState<string | null>(null);
  const [loadingPreview, setLoadingPreview] = useState(false);

  const scopedBooks =
    scope === 'all' ? books : books.filter((b) => b.status === 'Completed');

  const fetchAndDownload = async (
    format: 'csv' | 'json' | 'markdown' | 'txt',
    download: boolean,
  ) => {
    setLoadingPreview(true);
    const res = await fetch('/api/export/preview', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({scope, format}),
    });
    const data = await res.json();
    setLoadingPreview(false);
    const content = String(data.content ?? '');
    if (download) {
      const extMap = {csv: 'csv', json: 'json', markdown: 'md', txt: 'txt'};
      const mimeMap = {
        csv: 'text/csv',
        json: 'application/json',
        markdown: 'text/markdown',
        txt: 'text/plain',
      };
      downloadTextFile(
        content,
        `book_reading_statistics.${extMap[format]}`,
        mimeMap[format],
      );
    } else {
      setPreviewFormat(format);
      setPreviewContent(content);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-lg p-6 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-semibold text-slate-900 font-display">
              Export Reports &amp; Datasets
            </h2>
            <p className="text-sm text-slate-500 mt-0.5">
              Download live reading records and executive analytics in CSV, JSON, Markdown, Plain
              Text, or PNG charts.
            </p>
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-md text-xs">
            <button
              type="button"
              onClick={() => {
                setScope('all');
                setPreviewContent(null);
              }}
              className={`px-3 py-1.5 rounded font-medium cursor-pointer ${
                scope === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              All Books ({books.length})
            </button>
            <button
              type="button"
              onClick={() => {
                setScope('completed');
                setPreviewContent(null);
              }}
              className={`px-3 py-1.5 rounded font-medium cursor-pointer ${
                scope === 'completed' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              Completed Only ({books.filter((b) => b.status === 'Completed').length})
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            {
              fmt: 'csv' as const,
              title: 'CSV Dataset',
              desc: 'Standardized tabular columns for spreadsheets & BI tools.',
            },
            {
              fmt: 'json' as const,
              title: 'JSON Archive',
              desc: 'Structured book records with export timestamp metadata.',
            },
            {
              fmt: 'markdown' as const,
              title: 'Markdown Summary',
              desc: 'Executive summary with KPIs, genre tables, and observations.',
            },
            {
              fmt: 'txt' as const,
              title: 'Plain Text Audit',
              desc: 'Audit-style summary report and full numbered book ledger.',
            },
          ].map((item) => (
            <div
              key={item.fmt}
              className="border border-slate-200 rounded-md p-4 flex flex-col justify-between gap-4"
            >
              <div>
                <h3 className="text-sm font-semibold text-slate-900 font-display">{item.title}</h3>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">{item.desc}</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => fetchAndDownload(item.fmt, true)}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-blue-900 rounded hover:bg-blue-800 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download</span>
                </button>
                <button
                  type="button"
                  onClick={() => fetchAndDownload(item.fmt, false)}
                  className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 border border-slate-200 rounded hover:bg-slate-100 cursor-pointer"
                >
                  Preview
                </button>
              </div>
            </div>
          ))}
        </div>

        {loadingPreview && <p className="text-xs text-slate-500">Generating report preview...</p>}
        {previewContent !== null && !loadingPreview && (
          <div className="border border-slate-200 rounded-md overflow-hidden">
            <div className="flex items-center justify-between px-4 py-2 bg-slate-50 border-b border-slate-200 text-xs">
              <span className="font-mono font-medium text-slate-700">
                Preview ({previewFormat.toUpperCase()} · {scopedBooks.length} records)
              </span>
              <button
                type="button"
                onClick={() => setPreviewContent(null)}
                className="text-slate-500 hover:text-slate-900 cursor-pointer"
              >
                Close Preview
              </button>
            </div>
            <pre className="p-4 text-xs font-mono text-slate-800 bg-white max-h-80 overflow-auto whitespace-pre-wrap">
              {previewContent}
            </pre>
          </div>
        )}
      </div>

      {/* PNG Chart Exports */}
      <div>
        <h3 className="text-base font-semibold text-slate-900 font-display mb-3">
          Export Charts as High-Resolution PNG
        </h3>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <MonthlyBooksBarChart data={analytics.monthly} />
          <MonthlyPagesLineChart data={analytics.monthly} />
          <GenreDonutChart data={analytics.genres} />
          <YearlyComparisonChart data={analytics.yearly} />
        </div>
      </div>
    </div>
  );
}

export function SettingsView({
  settings,
  storagePath,
  bookCount,
  onSaveSettings,
  onLoadSample,
  onClearDatabase,
}: {
  settings: AppSettings;
  storagePath: string;
  bookCount: number;
  onSaveSettings: (next: AppSettings) => Promise<void>;
  onLoadSample: (replace: boolean) => Promise<{added: number; skipped: number}>;
  onClearDatabase: () => void;
}) {
  const [monthlyBooks, setMonthlyBooks] = useState(settings.monthly_book_target);
  const [monthlyPages, setMonthlyPages] = useState(settings.monthly_page_target);
  const [highPageThreshold, setHighPageThreshold] = useState(settings.high_page_threshold);
  const [ratingMin, setRatingMin] = useState(settings.rating_min);
  const [ratingMax, setRatingMax] = useState(settings.rating_max);
  const [strictDup, setStrictDup] = useState(settings.strict_duplicate_check);
  const [pageSize, setPageSize] = useState(settings.default_page_size);
  const [statusNote, setStatusNote] = useState<string | null>(null);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSaveSettings({
      monthly_book_target: Number(monthlyBooks),
      monthly_page_target: Number(monthlyPages),
      high_page_threshold: Number(highPageThreshold),
      rating_min: Number(ratingMin),
      rating_max: Number(ratingMax),
      strict_duplicate_check: strictDup,
      default_page_size: Number(pageSize),
    });
    setStatusNote('Settings saved and thresholds recalculated.');
  };

  const handleLoadSample = async (replace: boolean) => {
    const res = await onLoadSample(replace);
    setStatusNote(
      replace
        ? `Replaced database with ${res.added} demonstration books.`
        : `Merged ${res.added} sample book(s) (${res.skipped} duplicate records skipped).`,
    );
  };

  return (
    <div className="max-w-3xl space-y-6">
      <form onSubmit={handleSave} className="bg-white border border-slate-200 rounded-lg p-6 space-y-5">
        <div>
          <h2 className="text-lg font-semibold text-slate-900 font-display">
            Reading Targets &amp; Validation Settings
          </h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Configure monthly reading goals, threshold warning triggers, and duplicate protection.
          </p>
        </div>

        {statusNote && (
          <div className="bg-teal-50 border border-teal-200 rounded-md px-4 py-2.5 text-xs text-teal-900 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-teal-700 shrink-0" />
            <span>{statusNote}</span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Monthly Book Target
            </label>
            <input
              type="number"
              min={1}
              max={50}
              value={monthlyBooks}
              onChange={(e) => setMonthlyBooks(Number(e.target.value))}
              className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-md"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Monthly Page Target
            </label>
            <input
              type="number"
              min={50}
              step={50}
              value={monthlyPages}
              onChange={(e) => setMonthlyPages(Number(e.target.value))}
              className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-md"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              High Page Count Warning Threshold
            </label>
            <input
              type="number"
              min={100}
              step={50}
              value={highPageThreshold}
              onChange={(e) => setHighPageThreshold(Number(e.target.value))}
              className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-md"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Default Library Page Size
            </label>
            <input
              type="number"
              min={5}
              max={100}
              value={pageSize}
              onChange={(e) => setPageSize(Number(e.target.value))}
              className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-md"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Minimum Rating</label>
            <input
              type="number"
              step={0.5}
              value={ratingMin}
              onChange={(e) => setRatingMin(Number(e.target.value))}
              className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-md"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Maximum Rating</label>
            <input
              type="number"
              step={0.5}
              value={ratingMax}
              onChange={(e) => setRatingMax(Number(e.target.value))}
              className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-md"
            />
          </div>
        </div>

        <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
          <input
            type="checkbox"
            checked={strictDup}
            onChange={(e) => setStrictDup(e.target.checked)}
            className="rounded border-slate-300"
          />
          <span>Enforce strict duplicate prevention (reject matching Title + Author)</span>
        </label>

        <div className="flex justify-end pt-3 border-t border-slate-200">
          <button
            type="submit"
            className="px-5 py-2 text-xs font-medium text-white bg-blue-900 rounded-md hover:bg-blue-800 cursor-pointer"
          >
            Save Settings
          </button>
        </div>
      </form>

      <div className="bg-white border border-slate-200 rounded-lg p-6 space-y-4">
        <div>
          <h3 className="text-base font-semibold text-slate-900 font-display">
            Local Storage &amp; Demonstration Dataset
          </h3>
          <p className="text-xs text-slate-500 mt-1 font-mono">
            Storage File: {storagePath} · {bookCount} active records
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={() => handleLoadSample(false)}
            className="px-4 py-2 text-xs font-medium text-slate-800 bg-white border border-slate-300 rounded-md hover:bg-slate-50 cursor-pointer"
          >
            Merge Sample Dataset (Skip Duplicates)
          </button>

          <a
            href="/api/database/raw"
            download="books.json"
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-slate-800 bg-white border border-slate-300 rounded-md hover:bg-slate-50"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Backup Raw JSON</span>
          </a>

          <button
            type="button"
            onClick={onClearDatabase}
            className="px-4 py-2 text-xs font-medium text-red-700 bg-red-50 border border-red-200 rounded-md hover:bg-red-100 cursor-pointer"
          >
            Clear All Books (Empty Database)
          </button>
        </div>
      </div>
    </div>
  );
}
