import React from 'react';
import {AnalyticsPayload, BookRecord, NavSection} from '../types';
import {
  GenreDonutChart,
  MonthlyBooksBarChart,
  MonthlyPagesLineChart,
  StatusDistributionChart,
  YearlyComparisonChart,
} from './Charts';

export function AnalyticsView({
  books,
  analytics,
  onNavigate,
}: {
  books: BookRecord[];
  analytics: AnalyticsPayload;
  onNavigate: (section: NavSection) => void;
}) {
  const {kpis, monthly, yearly, genres, statuses, insights} = analytics;

  if (books.length === 0) {
    return (
      <div className="bg-white border border-slate-200 rounded-lg p-10 text-center max-w-xl mx-auto mt-6">
        <h3 className="text-lg font-semibold text-slate-900 font-display">
          No Analytics Available Yet
        </h3>
        <p className="text-sm text-slate-600 mt-1.5">
          Statistics and trend visualizations remain hidden when the database is empty to prevent
          misleading metrics. Add a book or load sample records to begin.
        </p>
        <button
          type="button"
          onClick={() => onNavigate('add-book')}
          className="mt-5 px-4 py-2 text-xs font-medium text-white bg-blue-900 rounded-md hover:bg-blue-800 cursor-pointer"
        >
          Add a Book
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-white border border-slate-200 rounded-lg p-4">
          <p className="text-xs text-slate-500">Completed Books</p>
          <p className="text-2xl font-semibold text-slate-900 font-mono mt-1">
            {kpis.total_books_read}
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-lg p-4">
          <p className="text-xs text-slate-500">Total Pages Read</p>
          <p className="text-2xl font-semibold text-slate-900 font-mono mt-1">
            {kpis.total_pages_read.toLocaleString()}
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-lg p-4">
          <p className="text-xs text-slate-500">Avg Pages / Book</p>
          <p className="text-2xl font-semibold text-slate-900 font-mono mt-1">
            {kpis.average_pages}
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-lg p-4">
          <p className="text-xs text-slate-500">Avg Books / Active Month</p>
          <p className="text-2xl font-semibold text-slate-900 font-mono mt-1">
            {insights.avg_books_per_active_month}
          </p>
        </div>
        <div className="bg-white border border-slate-200 rounded-lg p-4 col-span-2 lg:col-span-1">
          <p className="text-xs text-slate-500">Highest Reading Month</p>
          <p className="text-lg font-semibold text-slate-900 font-mono mt-1">
            {insights.highest_reading_month_pages
              ? `${insights.highest_reading_month_pages.label}`
              : 'N/A'}
          </p>
          {insights.highest_reading_month_pages && (
            <p className="text-xs text-slate-500 font-mono">
              {insights.highest_reading_month_pages.pages.toLocaleString()} pages
            </p>
          )}
        </div>
      </div>

      {/* Charts 1 & 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <MonthlyBooksBarChart data={monthly} limit={24} />
        <MonthlyPagesLineChart data={monthly} limit={24} />
      </div>

      {/* Charts 3 & 4 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <GenreDonutChart data={genres} />
        <YearlyComparisonChart data={yearly} />
      </div>

      {/* Chart 5 + Yearly Breakdown Table */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <StatusDistributionChart data={statuses} />

        <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200">
            <h3 className="text-base font-semibold text-slate-900 font-display">
              Yearly Reading Totals
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Completed books, cumulative pages, and average book length per year
            </p>
          </div>
          {yearly.length > 0 ? (
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs font-medium text-slate-500">
                  <th className="py-2.5 px-5">Year</th>
                  <th className="py-2.5 px-4 text-right">Completed</th>
                  <th className="py-2.5 px-4 text-right">Total Pages</th>
                  <th className="py-2.5 px-5 text-right">Avg Pages</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm font-mono">
                {yearly.map((y) => (
                  <tr key={y.year}>
                    <td className="py-2.5 px-5 font-semibold text-slate-900">{y.year}</td>
                    <td className="py-2.5 px-4 text-right text-slate-700">{y.books}</td>
                    <td className="py-2.5 px-4 text-right text-slate-900">
                      {y.pages.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-5 text-right text-slate-600">{y.avg_pages}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p className="p-6 text-sm text-slate-500">No completed yearly records yet.</p>
          )}
        </div>
      </div>
    </div>
  );
}
