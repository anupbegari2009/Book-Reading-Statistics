import React, {useCallback, useEffect, useState} from 'react';
import {
  BarChart3,
  BookOpen,
  Download,
  FileUp,
  LayoutDashboard,
  Library,
  Menu,
  PlusCircle,
  Search,
  Settings,
  X,
} from 'lucide-react';
import {AddBookView} from './components/AddBookView';
import {AnalyticsView} from './components/AnalyticsView';
import {BookDetailModal, ConfirmDialog, EditBookModal} from './components/BookModals';
import {DashboardView} from './components/DashboardView';
import {
  ExportReportsView,
  ImportDatasetView,
  SettingsView,
} from './components/ImportExportSettingsViews';
import {LibraryView} from './components/LibraryView';
import {SearchFilterView} from './components/SearchFilterView';
import {AnalyticsPayload, AppSettings, BookRecord, ImportSummary, NavSection} from './types';
import {downloadTextFile} from './utils/exportHelpers';

const NAV_ITEMS: {id: NavSection; label: string; icon: React.ComponentType<{className?: string}>}[] = [
  {id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard},
  {id: 'add-book', label: 'Add a Book', icon: PlusCircle},
  {id: 'library', label: 'My Library', icon: Library},
  {id: 'analytics', label: 'Reading Analytics', icon: BarChart3},
  {id: 'search', label: 'Search & Filter', icon: Search},
  {id: 'import', label: 'Import Dataset', icon: FileUp},
  {id: 'export', label: 'Export Reports', icon: Download},
  {id: 'settings', label: 'Settings', icon: Settings},
];

export default function App() {
  const [activeNav, setActiveNav] = useState<NavSection>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [books, setBooks] = useState<BookRecord[]>([]);
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [analytics, setAnalytics] = useState<AnalyticsPayload | null>(null);
  const [storagePath, setStoragePath] = useState('book-reading-statistics/data/books.json');
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState<{type: 'success' | 'error'; text: string} | null>(null);

  const [detailBook, setDetailBook] = useState<BookRecord | null>(null);
  const [editingBook, setEditingBook] = useState<BookRecord | null>(null);
  const [deletingBook, setDeletingBook] = useState<BookRecord | null>(null);
  const [confirmClearAll, setConfirmClearAll] = useState(false);

  const showToast = useCallback((type: 'success' | 'error', text: string) => {
    setToast({type, text});
    window.setTimeout(() => {
      setToast((curr) => (curr?.text === text ? null : curr));
    }, 4000);
  }, []);

  const loadBootstrap = useCallback(async () => {
    try {
      const res = await fetch('/api/bootstrap');
      const data = await res.json();
      setBooks(data.books ?? []);
      setSettings(data.settings);
      setAnalytics(data.analytics);
      if (data.storagePath) setStoragePath(data.storagePath);
    } catch {
      showToast('error', 'Failed to load reading statistics from local storage.');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => {
    loadBootstrap();
  }, [loadBootstrap]);

  const handleAddBook = async (
    payload: Record<string, unknown>,
    allowDuplicate: boolean,
  ): Promise<{ok: boolean; errors: string[]}> => {
    const res = await fetch('/api/books', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({...payload, allowDuplicate}),
    });
    const data = await res.json();
    if (!res.ok) {
      return {ok: false, errors: data.errors ?? ['Validation error']};
    }
    setBooks(data.books);
    setAnalytics(data.analytics);
    showToast('success', `Added '${data.book.title}' to library.`);
    return {ok: true, errors: []};
  };

  const handleEditBook = async (
    id: string,
    payload: Record<string, unknown>,
  ): Promise<string[]> => {
    const res = await fetch(`/api/books/${encodeURIComponent(id)}`, {
      method: 'PUT',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) {
      return data.errors ?? ['Failed to update record.'];
    }
    setBooks(data.books);
    setAnalytics(data.analytics);
    if (detailBook?.id === id) setDetailBook(data.book);
    showToast('success', `Updated '${data.book.title}'.`);
    return [];
  };

  const handleDeleteBook = async (book: BookRecord) => {
    const res = await fetch(`/api/books/${encodeURIComponent(book.id)}`, {
      method: 'DELETE',
    });
    const data = await res.json();
    if (!res.ok) {
      showToast('error', data.error ?? 'Failed to delete book.');
      return;
    }
    setBooks(data.books);
    setAnalytics(data.analytics);
    setDeletingBook(null);
    if (detailBook?.id === book.id) setDetailBook(null);
    showToast('success', `Deleted '${book.title}'.`);
  };

  const handleImportCsv = async (
    csvText: string,
    skipDuplicates: boolean,
  ): Promise<{ok: boolean; error?: string; summary?: ImportSummary}> => {
    const res = await fetch('/api/import/csv', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({csvText, skipDuplicates}),
    });
    const data = await res.json();
    if (!res.ok) {
      return {ok: false, error: data.error ?? 'CSV import failed.', summary: data.summary};
    }
    setBooks(data.books);
    setAnalytics(data.analytics);
    if (data.summary?.imported_count > 0) {
      showToast('success', `Imported ${data.summary.imported_count} book(s) from CSV.`);
    }
    return {ok: true, summary: data.summary};
  };

  const handleSaveSettings = async (next: AppSettings) => {
    const res = await fetch('/api/settings', {
      method: 'PUT',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(next),
    });
    const data = await res.json();
    setSettings(data.settings);
    setAnalytics(data.analytics);
    showToast('success', 'Settings saved.');
  };

  const handleLoadSample = async (replace: boolean) => {
    const res = await fetch('/api/database/load-sample', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({replace}),
    });
    const data = await res.json();
    setBooks(data.books);
    setAnalytics(data.analytics);
    showToast('success', `Loaded ${data.added} sample book(s).`);
    return {added: data.added as number, skipped: data.skipped as number};
  };

  const handleClearDatabase = async () => {
    const res = await fetch('/api/database/clear', {method: 'POST'});
    const data = await res.json();
    setBooks(data.books);
    setAnalytics(data.analytics);
    setConfirmClearAll(false);
    showToast('success', 'Cleared all book records from local storage.');
  };

  const handleQuickExportCsv = async (subset?: BookRecord[]) => {
    const res = await fetch('/api/export/preview', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        format: 'csv',
        ids: subset ? subset.map((b) => b.id) : undefined,
      }),
    });
    const data = await res.json();
    downloadTextFile(data.content, 'book_reading_statistics.csv', 'text/csv');
    showToast('success', `Exported ${data.count} book(s) to CSV.`);
  };

  const activeItem = NAV_ITEMS.find((n) => n.id === activeNav) ?? NAV_ITEMS[0];

  const handleSelectNav = (id: NavSection) => {
    setActiveNav(id);
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen flex bg-slate-50 text-slate-900">
      {/* Sidebar Desktop */}
      <aside className="hidden lg:flex lg:flex-col w-64 bg-white border-r border-slate-200 shrink-0">
        <div className="h-16 px-5 flex items-center gap-2.5 border-b border-slate-200">
          <BookOpen className="w-5 h-5 text-blue-900 shrink-0" />
          <span className="font-display font-bold text-base tracking-tight text-slate-900 whitespace-nowrap">
            Book Reading Stats
          </span>
        </div>

        <nav className="flex-1 p-3 space-y-1">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = activeNav === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleSelectNav(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-blue-50 text-blue-900'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-blue-900' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-200 text-xs text-slate-500">
          <div className="flex items-center justify-between">
            <span>Stored Books</span>
            <span className="font-mono font-semibold text-slate-900">{books.length}</span>
          </div>
          <div className="flex items-center justify-between mt-1">
            <span>Completed</span>
            <span className="font-mono font-semibold text-teal-700">
              {books.filter((b) => b.status === 'Completed').length}
            </span>
          </div>
        </div>
      </aside>

      {/* Mobile Sidebar Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-900/40"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative z-10 w-64 bg-white h-full flex flex-col border-r border-slate-200">
            <div className="h-16 px-5 flex items-center justify-between border-b border-slate-200">
              <div className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-blue-900" />
                <span className="font-display font-bold text-base text-slate-900">
                  Book Reading Stats
                </span>
              </div>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="p-1 text-slate-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="flex-1 p-3 space-y-1">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const isActive = activeNav === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleSelectNav(item.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium ${
                      isActive ? 'bg-blue-50 text-blue-900' : 'text-slate-600'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </aside>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-16 bg-white border-b border-slate-200 px-4 sm:px-8 flex items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-2 -ml-2 text-slate-600 hover:text-slate-900"
              aria-label="Open menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-sm truncate">
              <span className="text-slate-500 hidden sm:inline">Book Reading Statistics</span>
              <span className="text-slate-300 hidden sm:inline">/</span>
              <h1 className="font-display font-semibold text-slate-900 truncate">
                {activeItem.label}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => handleQuickExportCsv()}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-md hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
            <button
              type="button"
              onClick={() => handleSelectNav('add-book')}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-blue-900 rounded-md hover:bg-blue-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>Add a Book</span>
            </button>
          </div>
        </header>

        {toast && (
          <div className="fixed bottom-5 right-5 z-50">
            <div
              className={`px-4 py-3 rounded-md shadow-md border text-xs font-medium flex items-center gap-3 ${
                toast.type === 'success'
                  ? 'bg-slate-900 text-white border-slate-800'
                  : 'bg-red-600 text-white border-red-700'
              }`}
            >
              <span>{toast.text}</span>
              <button
                type="button"
                onClick={() => setToast(null)}
                className="text-white/70 hover:text-white cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        <main className="flex-1 p-4 sm:p-8 max-w-[1360px] w-full mx-auto">
          {loading || !settings || !analytics ? (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {[1, 2, 3].map((n) => (
                <div
                  key={n}
                  className="h-28 bg-white border border-slate-200 rounded-lg animate-pulse"
                />
              ))}
            </div>
          ) : (
            <>
              {activeNav === 'dashboard' && (
                <DashboardView
                  books={books}
                  analytics={analytics}
                  settings={settings}
                  onNavigate={handleSelectNav}
                  onSelectBook={(b) => setDetailBook(b)}
                  onLoadSample={() => handleLoadSample(false)}
                />
              )}

              {activeNav === 'add-book' && (
                <AddBookView
                  settings={settings}
                  onAddBook={handleAddBook}
                  onNavigate={handleSelectNav}
                />
              )}

              {activeNav === 'library' && (
                <LibraryView
                  books={books}
                  settings={settings}
                  onSelectBook={(b) => setDetailBook(b)}
                  onEditBook={(b) => setEditingBook(b)}
                  onRequestDelete={(b) => setDeletingBook(b)}
                  onNavigate={handleSelectNav}
                />
              )}

              {activeNav === 'analytics' && (
                <AnalyticsView
                  books={books}
                  analytics={analytics}
                  onNavigate={handleSelectNav}
                />
              )}

              {activeNav === 'search' && (
                <SearchFilterView
                  books={books}
                  onSelectBook={(b) => setDetailBook(b)}
                  onExportSubsetCsv={(subset) => handleQuickExportCsv(subset)}
                />
              )}

              {activeNav === 'import' && <ImportDatasetView onImportCsv={handleImportCsv} />}

              {activeNav === 'export' && (
                <ExportReportsView books={books} analytics={analytics} />
              )}

              {activeNav === 'settings' && (
                <SettingsView
                  settings={settings}
                  storagePath={storagePath}
                  bookCount={books.length}
                  onSaveSettings={handleSaveSettings}
                  onLoadSample={handleLoadSample}
                  onClearDatabase={() => setConfirmClearAll(true)}
                />
              )}
            </>
          )}
        </main>
      </div>

      {/* Modals */}
      {detailBook && analytics && (
        <BookDetailModal
          book={detailBook}
          warnings={analytics.warnings}
          onClose={() => setDetailBook(null)}
          onEdit={() => {
            setEditingBook(detailBook);
            setDetailBook(null);
          }}
          onDelete={() => setDeletingBook(detailBook)}
        />
      )}

      {editingBook && settings && (
        <EditBookModal
          book={editingBook}
          settings={settings}
          onClose={() => setEditingBook(null)}
          onSave={handleEditBook}
        />
      )}

      {deletingBook && (
        <ConfirmDialog
          title="Delete Book Record"
          message={`Are you sure you want to permanently delete '${deletingBook.title}' by ${deletingBook.author}?`}
          confirmLabel="Delete Book"
          onCancel={() => setDeletingBook(null)}
          onConfirm={() => handleDeleteBook(deletingBook)}
        />
      )}

      {confirmClearAll && (
        <ConfirmDialog
          title="Clear All Books"
          message="This will permanently remove all stored book records from books.json. You can reload the sample dataset later from Settings."
          confirmLabel="Clear Database"
          onCancel={() => setConfirmClearAll(false)}
          onConfirm={handleClearDatabase}
        />
      )}
    </div>
  );
}
