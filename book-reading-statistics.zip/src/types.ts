export const GENRES = [
  'Fiction',
  'Non-Fiction',
  'Science',
  'Technology',
  'Business',
  'Self-Help',
  'History',
  'Biography',
  'Fantasy',
  'Mystery',
  'Education',
  'Other',
] as const;

export type Genre = (typeof GENRES)[number];

export const READING_STATUSES = [
  'Completed',
  'Currently Reading',
  'Planned',
] as const;

export type ReadingStatus = (typeof READING_STATUSES)[number];

export interface BookRecord {
  id: string;
  title: string;
  author: string;
  genre: string;
  pages: number;
  status: ReadingStatus;
  start_date: string;
  completion_date: string | null;
  rating: number | null;
  notes: string;
  is_sample: boolean;
}

export interface AppSettings {
  monthly_book_target: number;
  monthly_page_target: number;
  high_page_threshold: number;
  rating_min: number;
  rating_max: number;
  strict_duplicate_check: boolean;
  default_page_size: number;
}

export interface WarningItem {
  severity: 'warning' | 'info' | 'error';
  code: string;
  message: string;
  book_id?: string;
  book_title?: string;
}

export interface DashboardKPIs {
  total_stored: number;
  total_books_read: number;
  currently_reading_count: number;
  planned_count: number;
  total_pages_read: number;
  average_pages: number;
  average_rating: number | null;
  genres_explored: number;
  books_this_month: number;
  pages_this_month: number;
  books_this_year: number;
  pages_this_year: number;
  reference_year: number;
  reference_month_label: string;
}

export interface MonthlyPoint {
  month_key: string;
  label: string;
  books: number;
  pages: number;
}

export interface YearlyPoint {
  year: number;
  books: number;
  pages: number;
  avg_pages: number;
}

export interface GenreSlice {
  genre: string;
  count: number;
  pages: number;
  percentage: number;
}

export interface StatusSlice {
  status: string;
  count: number;
  percentage: number;
}

export interface ReadingInsights {
  has_data: boolean;
  most_read_genre: GenreSlice | null;
  most_productive_month: MonthlyPoint | null;
  highest_reading_month_pages: MonthlyPoint | null;
  avg_books_per_active_month: number;
  avg_pages_per_active_month: number;
  page_std_dev: number;
  longest_book: BookRecord | null;
  observations: string[];
}

export interface AnalyticsPayload {
  kpis: DashboardKPIs;
  monthly: MonthlyPoint[];
  yearly: YearlyPoint[];
  genres: GenreSlice[];
  statuses: StatusSlice[];
  insights: ReadingInsights;
  warnings: WarningItem[];
  startup_warnings: string[];
}

export interface ImportRowError {
  row_number: number;
  title: string;
  reason: string;
}

export interface ImportSummary {
  total_rows: number;
  imported_count: number;
  duplicate_count: number;
  failed_count: number;
  errors: ImportRowError[];
}

export type NavSection =
  | 'dashboard'
  | 'add-book'
  | 'library'
  | 'analytics'
  | 'search'
  | 'import'
  | 'export'
  | 'settings';
