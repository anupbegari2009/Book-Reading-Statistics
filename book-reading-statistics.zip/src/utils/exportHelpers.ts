export function downloadTextFile(content: string, filename: string, mimeType: string): void {
  const blob = new Blob([content], {type: `${mimeType};charset=utf-8`});
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export async function downloadSvgAsPng(
  svgElement: SVGSVGElement | null,
  filename: string,
  chartTitle: string,
): Promise<boolean> {
  if (!svgElement) return false;
  const clone = svgElement.cloneNode(true) as SVGSVGElement;
  const viewBox = svgElement.getAttribute('viewBox');
  let width = svgElement.clientWidth || 720;
  let height = svgElement.clientHeight || 360;
  if (viewBox) {
    const parts = viewBox.split(/\s+/).map(Number);
    if (parts.length === 4 && parts[2] > 0 && parts[3] > 0) {
      width = parts[2];
      height = parts[3];
    }
  }
  clone.setAttribute('width', String(width));
  clone.setAttribute('height', String(height));
  clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');

  const serializer = new XMLSerializer();
  const svgStr = serializer.serializeToString(clone);
  const svgBlob = new Blob([svgStr], {type: 'image/svg+xml;charset=utf-8'});
  const svgUrl = URL.createObjectURL(svgBlob);

  return new Promise<boolean>((resolve) => {
    const img = new Image();
    img.onload = () => {
      const scale = 2;
      const paddingTop = 48;
      const padding = 24;
      const canvas = document.createElement('canvas');
      canvas.width = (width + padding * 2) * scale;
      canvas.height = (height + paddingTop + padding) * scale;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        URL.revokeObjectURL(svgUrl);
        resolve(false);
        return;
      }
      ctx.scale(scale, scale);
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, width + padding * 2, height + paddingTop + padding);

      ctx.fillStyle = '#0F172A';
      ctx.font = '600 15px "Plus Jakarta Sans", sans-serif';
      ctx.fillText(chartTitle, padding, 30);

      ctx.drawImage(img, padding, paddingTop, width, height);
      URL.revokeObjectURL(svgUrl);

      canvas.toBlob((pngBlob) => {
        if (!pngBlob) {
          resolve(false);
          return;
        }
        const pngUrl = URL.createObjectURL(pngBlob);
        const link = document.createElement('a');
        link.href = pngUrl;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(pngUrl);
        resolve(true);
      }, 'image/png');
    };
    img.onerror = () => {
      URL.revokeObjectURL(svgUrl);
      resolve(false);
    };
    img.src = svgUrl;
  });
}
