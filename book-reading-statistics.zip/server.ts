import express from 'express';
import fs from 'fs';
import path from 'path';
import {createServer as createViteServer} from 'vite';
import {
  BOOKS_JSON_PATH,
  SAMPLE_CSV_PATH,
  addBookRecord,
  clearAllBooks,
  computeAnalytics,
  deleteBookRecord,
  exportBooksToCsv,
  generateMarkdownReport,
  generatePlainTextAudit,
  importCsvText,
  loadBooks,
  loadSampleBooksIntoDb,
  loadSettings,
  saveSettings,
  updateBookRecord,
} from './server/bookService';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({limit: '4mb'}));

  // Initial load check (creates empty books.json only if missing; never overwrites valid data)
  loadBooks();

  app.get('/api/bootstrap', (_req, res) => {
    const {books, warnings} = loadBooks();
    const settings = loadSettings();
    const analytics = computeAnalytics(books, settings);
    res.json({
      books,
      settings,
      analytics: {...analytics, startup_warnings: warnings},
      storagePath: 'book-reading-statistics/data/books.json',
    });
  });

  app.post('/api/books', (req, res) => {
    const {allowDuplicate, ...payload} = req.body ?? {};
    const result = addBookRecord(payload, Boolean(allowDuplicate));
    if (!result.ok) {
      res.status(400).json({errors: result.errors});
      return;
    }
    const {books} = loadBooks();
    const settings = loadSettings();
    res.status(201).json({
      book: result.book,
      books,
      analytics: computeAnalytics(books, settings),
    });
  });

  app.put('/api/books/:id', (req, res) => {
    const {allowDuplicate, ...payload} = req.body ?? {};
    const result = updateBookRecord(req.params.id, payload, Boolean(allowDuplicate));
    if (!result.ok) {
      res.status(400).json({errors: result.errors});
      return;
    }
    const {books} = loadBooks();
    const settings = loadSettings();
    res.json({
      book: result.book,
      books,
      analytics: computeAnalytics(books, settings),
    });
  });

  app.delete('/api/books/:id', (req, res) => {
    const result = deleteBookRecord(req.params.id);
    if (!result.ok) {
      res.status(404).json({error: result.message});
      return;
    }
    const {books} = loadBooks();
    const settings = loadSettings();
    res.json({
      message: result.message,
      books,
      analytics: computeAnalytics(books, settings),
    });
  });

  app.post('/api/import/csv', (req, res) => {
    const {csvText, skipDuplicates = true} = req.body ?? {};
    const outcome = importCsvText(String(csvText ?? ''), Boolean(skipDuplicates));
    if (!outcome.headerOk) {
      res.status(400).json({error: outcome.headerError, summary: outcome.summary});
      return;
    }
    const {books} = loadBooks();
    const settings = loadSettings();
    res.json({
      summary: outcome.summary,
      books,
      analytics: computeAnalytics(books, settings),
    });
  });

  app.get('/api/sample-csv', (_req, res) => {
    if (!fs.existsSync(SAMPLE_CSV_PATH)) {
      res.status(404).send('Sample CSV not found');
      return;
    }
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="sample_books.csv"');
    res.send(fs.readFileSync(SAMPLE_CSV_PATH, 'utf-8'));
  });

  app.post('/api/export/preview', (req, res) => {
    const {scope = 'all', format = 'markdown', ids} = req.body ?? {};
    const {books} = loadBooks();
    const settings = loadSettings();
    let subset = books;
    if (Array.isArray(ids)) {
      const idSet = new Set(ids.map(String));
      subset = books.filter((b) => idSet.has(b.id));
    } else if (scope === 'completed') {
      subset = books.filter((b) => b.status === 'Completed');
    }

    if (format === 'csv') {
      res.json({content: exportBooksToCsv(subset), count: subset.length});
      return;
    }
    if (format === 'json') {
      res.json({
        content: JSON.stringify(
          {
            exported_at: new Date().toISOString(),
            record_count: subset.length,
            books: subset,
          },
          null,
          2,
        ),
        count: subset.length,
      });
      return;
    }
    if (format === 'txt') {
      res.json({content: generatePlainTextAudit(subset, settings), count: subset.length});
      return;
    }
    res.json({content: generateMarkdownReport(subset, settings), count: subset.length});
  });

  app.put('/api/settings', (req, res) => {
    const updated = saveSettings(req.body ?? {});
    const {books} = loadBooks();
    res.json({
      settings: updated,
      analytics: computeAnalytics(books, updated),
    });
  });

  app.post('/api/database/load-sample', (req, res) => {
    const replace = Boolean(req.body?.replace);
    const result = loadSampleBooksIntoDb(replace);
    const {books} = loadBooks();
    const settings = loadSettings();
    res.json({
      ...result,
      books,
      analytics: computeAnalytics(books, settings),
    });
  });

  app.post('/api/database/clear', (_req, res) => {
    clearAllBooks();
    const {books} = loadBooks();
    const settings = loadSettings();
    res.json({
      books,
      analytics: computeAnalytics(books, settings),
    });
  });

  app.get('/api/database/raw', (_req, res) => {
    if (!fs.existsSync(BOOKS_JSON_PATH)) {
      res.json([]);
      return;
    }
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="books.json"');
    res.send(fs.readFileSync(BOOKS_JSON_PATH, 'utf-8'));
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: {middlewareMode: true},
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Book Reading Statistics running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
