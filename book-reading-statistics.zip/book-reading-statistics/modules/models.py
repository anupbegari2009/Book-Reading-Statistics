"""Domain data models and configuration constants for Book Reading Statistics."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Optional

GENRES: tuple[str, ...] = (
    "Fiction",
    "Non-Fiction",
    "Science",
    "Technology",
    "Business",
    "Self-Help",
    "History",
    "Biography",
    "Fantasy",
    "Mystery",
    "Education",
    "Other",
)

READING_STATUSES: tuple[str, ...] = (
    "Completed",
    "Currently Reading",
    "Planned",
)

CSV_COLUMNS: tuple[str, ...] = (
    "id",
    "title",
    "author",
    "genre",
    "pages",
    "status",
    "start_date",
    "completion_date",
    "rating",
    "notes",
    "is_sample",
)


@dataclass
class AppSettings:
    """User-configurable reading targets, validation bounds, and display settings."""

    monthly_book_target: int = 2
    monthly_page_target: int = 700
    high_page_threshold: int = 1200
    rating_min: float = 1.0
    rating_max: float = 5.0
    strict_duplicate_check: bool = True
    default_page_size: int = 12

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AppSettings":
        defaults = cls()
        try:
            monthly_book_target = max(1, int(data.get("monthly_book_target", defaults.monthly_book_target)))
        except (TypeError, ValueError):
            monthly_book_target = defaults.monthly_book_target
        try:
            monthly_page_target = max(50, int(data.get("monthly_page_target", defaults.monthly_page_target)))
        except (TypeError, ValueError):
            monthly_page_target = defaults.monthly_page_target
        try:
            high_page_threshold = max(100, int(data.get("high_page_threshold", defaults.high_page_threshold)))
        except (TypeError, ValueError):
            high_page_threshold = defaults.high_page_threshold
        try:
            rating_min = float(data.get("rating_min", defaults.rating_min))
            rating_max = float(data.get("rating_max", defaults.rating_max))
            if rating_min >= rating_max:
                rating_min, rating_max = defaults.rating_min, defaults.rating_max
        except (TypeError, ValueError):
            rating_min, rating_max = defaults.rating_min, defaults.rating_max
        strict_duplicate_check = bool(data.get("strict_duplicate_check", defaults.strict_duplicate_check))
        try:
            default_page_size = max(5, min(100, int(data.get("default_page_size", defaults.default_page_size))))
        except (TypeError, ValueError):
            default_page_size = defaults.default_page_size

        return cls(
            monthly_book_target=monthly_book_target,
            monthly_page_target=monthly_page_target,
            high_page_threshold=high_page_threshold,
            rating_min=rating_min,
            rating_max=rating_max,
            strict_duplicate_check=strict_duplicate_check,
            default_page_size=default_page_size,
        )


@dataclass
class BookRecord:
    """Represents a single tracked book record."""

    id: str
    title: str
    author: str
    genre: str
    pages: int
    status: str
    start_date: str
    completion_date: Optional[str] = None
    rating: Optional[float] = None
    notes: str = ""
    is_sample: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "author": self.author,
            "genre": self.genre,
            "pages": self.pages,
            "status": self.status,
            "start_date": self.start_date,
            "completion_date": self.completion_date,
            "rating": self.rating,
            "notes": self.notes,
            "is_sample": self.is_sample,
        }

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "BookRecord":
        completion = raw.get("completion_date")
        if completion is not None:
            completion = str(completion).strip() or None
        rating_raw = raw.get("rating")
        rating: Optional[float]
        if rating_raw is None or str(rating_raw).strip() == "":
            rating = None
        else:
            rating = round(float(rating_raw), 1)
        return cls(
            id=str(raw.get("id", "")).strip(),
            title=str(raw.get("title", "")).strip(),
            author=str(raw.get("author", "")).strip(),
            genre=str(raw.get("genre", "Other")).strip() or "Other",
            pages=int(raw.get("pages", 0)),
            status=str(raw.get("status", "Planned")).strip(),
            start_date=str(raw.get("start_date", "")).strip(),
            completion_date=completion,
            rating=rating,
            notes=str(raw.get("notes", "") or "").strip(),
            is_sample=bool(raw.get("is_sample", False)),
        )


@dataclass
class WarningItem:
    """Automated threshold or data quality warning."""

    severity: str  # "warning" | "info" | "error"
    code: str
    message: str
    book_id: Optional[str] = None
    book_title: Optional[str] = None


@dataclass
class ImportRowError:
    """Captures a validation or duplicate failure for a single imported CSV row."""

    row_number: int
    title: str
    reason: str


@dataclass
class ImportSummary:
    """Result summary for bulk CSV import operations."""

    total_rows: int
    imported_count: int
    duplicate_count: int
    failed_count: int
    errors: list[ImportRowError] = field(default_factory=list)
    imported_books: list[BookRecord] = field(default_factory=list)
