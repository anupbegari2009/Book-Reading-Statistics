"""Multi-format report generation: CSV, JSON, Markdown executive summary, and Plain Text audit."""

from __future__ import annotations

import csv
import io
import json
from datetime import datetime
from typing import Optional

from .analytics import (
    compute_dashboard_kpis,
    compute_genre_distribution,
    compute_monthly_series,
    compute_reading_insights,
    compute_yearly_comparison,
)
from .models import CSV_COLUMNS, BookRecord


def export_books_to_csv(books: list[BookRecord]) -> str:
    """Serialize book records into standardized CSV text."""
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=list(CSV_COLUMNS))
    writer.writeheader()
    for book in books:
        row = book.to_dict()
        row["completion_date"] = row["completion_date"] or ""
        row["rating"] = "" if row["rating"] is None else row["rating"]
        row["is_sample"] = "true" if row["is_sample"] else "false"
        writer.writerow(row)
    return output.getvalue()


def export_books_to_json(books: list[BookRecord]) -> str:
    """Serialize book records into formatted JSON."""
    payload = {
        "exported_at": datetime.now().isoformat(timespec="seconds"),
        "record_count": len(books),
        "books": [b.to_dict() for b in books],
    }
    return json.dumps(payload, indent=2, ensure_ascii=False)


def export_markdown_report(books: list[BookRecord], title: str = "Book Reading Statistics Report") -> str:
    """Generate a formatted Markdown executive summary reflecting live records."""
    kpis = compute_dashboard_kpis(books)
    insights = compute_reading_insights(books)
    genres = compute_genre_distribution(books, completed_only=True)
    monthly = compute_monthly_series(books)
    yearly = compute_yearly_comparison(books)

    lines: list[str] = [
        f"# {title}",
        "",
        f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        "",
        "## Executive Summary",
        "",
        f"- **Total Stored Books:** {kpis['total_stored']}",
        f"- **Total Completed Books:** {kpis['total_books_read']}",
        f"- **Currently Reading:** {kpis['currently_reading_count']}",
        f"- **Planned:** {kpis['planned_count']}",
        f"- **Total Pages Read (Completed):** {kpis['total_pages_read']:,}",
        f"- **Average Pages per Completed Book:** {kpis['average_pages']}",
        f"- **Genres Explored:** {kpis['genres_explored']}",
        f"- **Completed This Month ({kpis['reference_month_label']}):** {kpis['books_this_month']} books ({kpis['pages_this_month']:,} pages)",
        f"- **Completed This Year ({kpis['reference_year']}):** {kpis['books_this_year']} books ({kpis['pages_this_year']:,} pages)",
        "",
        "## Key Insights",
        "",
    ]

    for obs in insights["observations"]:
        lines.append(f"- {obs}")

    lines.extend(["", "## Genre Distribution (Completed Books)", ""])
    if genres:
        lines.append("| Genre | Books | Pages | Share |")
        lines.append("| --- | ---: | ---: | ---: |")
        for g in genres:
            lines.append(f"| {g['genre']} | {g['count']} | {g['pages']:,} | {g['percentage']}% |")
    else:
        lines.append("_No completed books recorded yet._")

    lines.extend(["", "## Yearly Reading Comparison", ""])
    if yearly:
        lines.append("| Year | Completed Books | Total Pages | Avg Pages/Book |")
        lines.append("| ---: | ---: | ---: | ---: |")
        for y in yearly:
            lines.append(f"| {y['year']} | {y['books']} | {y['pages']:,} | {y['avg_pages']} |")
    else:
        lines.append("_No yearly completion records available._")

    lines.extend(["", "## Recent Monthly Activity (Up to 12 Months)", ""])
    if monthly:
        lines.append("| Month | Books Completed | Pages Read |")
        lines.append("| --- | ---: | ---: |")
        for m in monthly[-12:]:
            lines.append(f"| {m['label']} | {m['books']} | {m['pages']:,} |")
    else:
        lines.append("_No monthly reading activity available._")

    lines.extend(["", "## Library Records", ""])
    if books:
        lines.append("| Title | Author | Genre | Pages | Status | Completion Date | Rating |")
        lines.append("| --- | --- | --- | ---: | --- | --- | ---: |")
        for b in books:
            rating_str = f"{b.rating:.1f}" if b.rating is not None else "-"
            comp_str = b.completion_date or "-"
            lines.append(
                f"| {b.title} | {b.author} | {b.genre} | {b.pages:,} | {b.status} | {comp_str} | {rating_str} |"
            )
    else:
        lines.append("_The library is currently empty._")

    return "\n".join(lines) + "\n"


def export_plain_text_audit(books: list[BookRecord], title: str = "BOOK READING STATISTICS AUDIT REPORT") -> str:
    """Generate an audit-style plain-text report."""
    kpis = compute_dashboard_kpis(books)
    insights = compute_reading_insights(books)
    genres = compute_genre_distribution(books, completed_only=True)

    divider = "=" * 72
    sub_divider = "-" * 72
    lines: list[str] = [
        divider,
        title,
        f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        divider,
        "",
        "SUMMARY METRICS",
        sub_divider,
        f"Total Records in Database : {kpis['total_stored']}",
        f"Completed Books           : {kpis['total_books_read']}",
        f"Currently Reading         : {kpis['currently_reading_count']}",
        f"Planned                   : {kpis['planned_count']}",
        f"Total Pages Completed     : {kpis['total_pages_read']:,}",
        f"Average Pages / Book      : {kpis['average_pages']}",
        f"Average Rating            : {kpis['average_rating'] if kpis['average_rating'] is not None else 'N/A'}",
        f"Genres Explored           : {kpis['genres_explored']}",
        f"This Month ({kpis['reference_month_label']}) : {kpis['books_this_month']} books / {kpis['pages_this_month']:,} pages",
        f"This Year ({kpis['reference_year']})          : {kpis['books_this_year']} books / {kpis['pages_this_year']:,} pages",
        "",
        "ANALYTICAL OBSERVATIONS",
        sub_divider,
    ]
    for idx, obs in enumerate(insights["observations"], start=1):
        lines.append(f"{idx}. {obs}")

    lines.extend(["", "GENRE BREAKDOWN", sub_divider])
    if genres:
        for g in genres:
            lines.append(
                f"{g['genre']:<16} | {g['count']:>3} books | {g['pages']:>7,} pages | {g['percentage']:>5.1f}%"
            )
    else:
        lines.append("No completed records available.")

    lines.extend(["", "RECORD LEDGER", sub_divider])
    if books:
        for idx, b in enumerate(books, start=1):
            comp = b.completion_date or "N/A"
            rating = f"{b.rating:.1f}/5" if b.rating is not None else "Unrated"
            lines.append(
                f"[{idx:03d}] {b.title} — {b.author} ({b.genre}) | {b.pages}p | {b.status} | Completed: {comp} | Rating: {rating}"
            )
    else:
        lines.append("No book records found.")

    lines.extend(["", divider, "END OF AUDIT REPORT", divider])
    return "\n".join(lines) + "\n"
