"""Fault-tolerant CSV bulk import engine with header checks and row-level reporting."""

from __future__ import annotations

import csv
import io
from typing import Any

from .book_manager import BookManager
from .models import ImportRowError, ImportSummary
from .validation import find_duplicate_book, validate_book_payload

REQUIRED_IMPORT_COLUMNS = ("title", "author", "genre", "pages", "status", "start_date")

COLUMN_ALIASES: dict[str, str] = {
    "book_title": "title",
    "book title": "title",
    "title": "title",
    "author_name": "author",
    "author name": "author",
    "author": "author",
    "category": "genre",
    "genre": "genre",
    "total_pages": "pages",
    "total pages": "pages",
    "page_count": "pages",
    "pages": "pages",
    "reading_status": "status",
    "reading status": "status",
    "status": "status",
    "start_date": "start_date",
    "start date": "start_date",
    "completion_date": "completion_date",
    "completion date": "completion_date",
    "end_date": "completion_date",
    "rating": "rating",
    "personal_rating": "rating",
    "notes": "notes",
    "id": "id",
    "is_sample": "is_sample",
}


def normalize_headers(raw_headers: list[str]) -> dict[str, str]:
    """Map raw CSV header names onto canonical field names."""
    mapping: dict[str, str] = {}
    for header in raw_headers:
        cleaned = header.strip().lower().lstrip("\ufeff")
        canonical = COLUMN_ALIASES.get(cleaned, cleaned.replace(" ", "_"))
        mapping[header] = canonical
    return mapping


def import_csv_content(
    csv_text: str,
    manager: BookManager,
    skip_duplicates: bool = True,
) -> tuple[bool, Optional[str], ImportSummary]:
    """
    Parse and import CSV text into the BookManager row-by-row.

    One invalid row never crashes or aborts valid rows.
    Returns (header_ok, header_error_message, ImportSummary).
    """
    if not csv_text or not csv_text.strip():
        return (
            False,
            "Uploaded CSV file is empty.",
            ImportSummary(total_rows=0, imported_count=0, duplicate_count=0, failed_count=0),
        )

    try:
        reader = csv.DictReader(io.StringIO(csv_text))
        raw_fieldnames = list(reader.fieldnames or [])
    except csv.Error as exc:
        return (
            False,
            f"Malformed CSV header structure: {exc}",
            ImportSummary(total_rows=0, imported_count=0, duplicate_count=0, failed_count=0),
        )

    if not raw_fieldnames:
        return (
            False,
            "CSV file is missing a header row.",
            ImportSummary(total_rows=0, imported_count=0, duplicate_count=0, failed_count=0),
        )

    header_map = normalize_headers(raw_fieldnames)
    canonical_headers = set(header_map.values())
    missing_cols = [col for col in REQUIRED_IMPORT_COLUMNS if col not in canonical_headers]
    if missing_cols:
        return (
            False,
            f"Missing required CSV column(s): {', '.join(missing_cols)}.",
            ImportSummary(total_rows=0, imported_count=0, duplicate_count=0, failed_count=0),
        )

    summary = ImportSummary(total_rows=0, imported_count=0, duplicate_count=0, failed_count=0)

    try:
        rows = list(reader)
    except csv.Error as exc:
        return (
            False,
            f"Failed while reading CSV rows: {exc}",
            summary,
        )

    for idx, raw_row in enumerate(rows, start=2):  # Row 1 is header
        summary.total_rows += 1
        normalized_row: dict[str, Any] = {}
        for orig_key, val in raw_row.items():
            if orig_key is None:
                continue
            canonical_key = header_map.get(orig_key, orig_key.strip().lower())
            normalized_row[canonical_key] = val.strip() if isinstance(val, str) else val

        row_title = str(normalized_row.get("title") or "").strip() or "(Untitled Row)"
        row_author = str(normalized_row.get("author") or "").strip()

        if "is_sample" in normalized_row:
            raw_sample = str(normalized_row["is_sample"]).strip().lower()
            normalized_row["is_sample"] = raw_sample in {"true", "1", "yes"}

        # Explicit duplicate detection before validation so duplicate_count is accurately reported
        if row_title != "(Untitled Row)" and row_author:
            dup = find_duplicate_book(row_title, row_author, manager.books)
            if dup is not None:
                if skip_duplicates:
                    summary.duplicate_count += 1
                    summary.errors.append(
                        ImportRowError(
                            row_number=idx,
                            title=row_title,
                            reason=f"Duplicate skipped: '{dup.title}' by {dup.author} already exists.",
                        )
                    )
                    continue

        is_valid, errors, _ = validate_book_payload(
            payload=normalized_row,
            existing_books=manager.books,
            settings=manager.settings,
            allow_duplicate=not skip_duplicates,
        )
        if not is_valid:
            summary.failed_count += 1
            summary.errors.append(
                ImportRowError(
                    row_number=idx,
                    title=row_title,
                    reason="; ".join(errors),
                )
            )
            continue

        ok, add_errors, created = manager.add_book(normalized_row, allow_duplicate=not skip_duplicates)
        if ok and created is not None:
            summary.imported_count += 1
            summary.imported_books.append(created)
        else:
            summary.failed_count += 1
            summary.errors.append(
                ImportRowError(
                    row_number=idx,
                    title=row_title,
                    reason="; ".join(add_errors) or "Unexpected save error.",
                )
            )

    return True, None, summary
