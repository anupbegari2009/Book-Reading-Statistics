"""Input validation, date verification, duplicate detection, and schema checking."""

from __future__ import annotations

from datetime import date, datetime
from typing import Any, Optional

from .models import GENRES, READING_STATUSES, AppSettings, BookRecord

DATE_FORMAT = "%Y-%m-%d"


def parse_iso_date(value: Any) -> Optional[date]:
    """Parse an ISO YYYY-MM-DD string into a datetime.date, or return None if invalid."""
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    try:
        return datetime.strptime(text, DATE_FORMAT).date()
    except ValueError:
        return None


def normalize_text_key(title: str, author: str) -> tuple[str, str]:
    """Produce a case-insensitive, whitespace-normalized key for duplicate detection."""
    clean_title = " ".join(title.strip().lower().split())
    clean_author = " ".join(author.strip().lower().split())
    return clean_title, clean_author


def find_duplicate_book(
    title: str,
    author: str,
    existing_books: list[BookRecord],
    exclude_id: Optional[str] = None,
) -> Optional[BookRecord]:
    """Return the first matching duplicate BookRecord if one exists."""
    target_key = normalize_text_key(title, author)
    if not target_key[0] or not target_key[1]:
        return None
    for book in existing_books:
        if exclude_id and book.id == exclude_id:
            continue
        if normalize_text_key(book.title, book.author) == target_key:
            return book
    return None


def validate_book_payload(
    payload: dict[str, Any],
    existing_books: Optional[list[BookRecord]] = None,
    settings: Optional[AppSettings] = None,
    exclude_id: Optional[str] = None,
    allow_duplicate: bool = False,
) -> tuple[bool, list[str], Optional[dict[str, Any]]]:
    """
    Validate raw form or CSV book data.

    Returns (is_valid, errors, cleaned_dict).
    """
    cfg = settings or AppSettings()
    errors: list[str] = []

    title = str(payload.get("title", "") or "").strip()
    author = str(payload.get("author", "") or "").strip()
    genre = str(payload.get("genre", "") or "").strip()
    status = str(payload.get("status", "") or "").strip()
    notes = str(payload.get("notes", "") or "").strip()
    is_sample = bool(payload.get("is_sample", False))

    if not title:
        errors.append("Book title cannot be blank.")
    if not author:
        errors.append("Author name cannot be blank.")

    if not genre:
        errors.append("Genre is required.")
    elif genre not in GENRES:
        # Match case-insensitively if possible before rejecting
        matched_genre = next((g for g in GENRES if g.lower() == genre.lower()), None)
        if matched_genre:
            genre = matched_genre
        else:
            errors.append(f"Unsupported genre '{genre}'. Choose from: {', '.join(GENRES)}.")

    if not status:
        errors.append("Reading status is required.")
    elif status not in READING_STATUSES:
        matched_status = next((s for s in READING_STATUSES if s.lower() == status.lower()), None)
        if matched_status:
            status = matched_status
        else:
            errors.append(
                f"Invalid reading status '{status}'. Must be one of: {', '.join(READING_STATUSES)}."
            )

    # Validate pages as a strict positive integer
    pages_val: Optional[int] = None
    raw_pages = payload.get("pages")
    if raw_pages is None or str(raw_pages).strip() == "":
        errors.append("Page count is required and must be a positive integer.")
    else:
        try:
            if isinstance(raw_pages, bool):
                raise ValueError("Boolean is not a valid page count")
            if isinstance(raw_pages, float) and not raw_pages.is_integer():
                raise ValueError("Page count must be a whole integer")
            pages_str = str(raw_pages).strip()
            if "." in pages_str:
                float_val = float(pages_str)
                if not float_val.is_integer():
                    raise ValueError("Decimal page count")
                pages_val = int(float_val)
            else:
                pages_val = int(pages_str)
            if pages_val <= 0:
                errors.append("Page count must be greater than zero.")
        except (TypeError, ValueError):
            errors.append("Page count must be a valid positive integer.")

    # Validate dates
    raw_start = payload.get("start_date")
    start_str = str(raw_start or "").strip()
    start_dt = parse_iso_date(start_str)
    if not start_str:
        errors.append("Start date is required (YYYY-MM-DD).")
    elif start_dt is None:
        errors.append(f"Invalid start date '{start_str}'. Expected YYYY-MM-DD.")

    raw_completion = payload.get("completion_date")
    completion_str = str(raw_completion or "").strip()
    completion_dt: Optional[date] = None
    if completion_str:
        completion_dt = parse_iso_date(completion_str)
        if completion_dt is None:
            errors.append(f"Invalid completion date '{completion_str}'. Expected YYYY-MM-DD.")
    elif status == "Completed":
        errors.append("Completion date is required when status is 'Completed'.")

    if start_dt is not None and completion_dt is not None:
        if completion_dt < start_dt:
            errors.append("Completion date cannot precede the start date.")

    # Validate rating
    rating_val: Optional[float] = None
    raw_rating = payload.get("rating")
    if raw_rating is not None and str(raw_rating).strip() != "":
        try:
            if isinstance(raw_rating, bool):
                raise ValueError("Boolean is not a valid rating")
            rating_val = round(float(str(raw_rating).strip()), 1)
            if rating_val < cfg.rating_min or rating_val > cfg.rating_max:
                errors.append(
                    f"Rating must be between {cfg.rating_min:g} and {cfg.rating_max:g}."
                )
        except (TypeError, ValueError):
            errors.append("Rating must be a numeric value.")

    # Duplicate check
    if existing_books is not None and title and author and not allow_duplicate:
        dup = find_duplicate_book(title, author, existing_books, exclude_id=exclude_id)
        if dup is not None and cfg.strict_duplicate_check:
            errors.append(
                f"Duplicate record detected: '{dup.title}' by {dup.author} already exists in your library."
            )

    if errors:
        return False, errors, None

    cleaned = {
        "id": str(payload.get("id", "") or "").strip(),
        "title": title,
        "author": author,
        "genre": genre,
        "pages": pages_val,
        "status": status,
        "start_date": start_dt.strftime(DATE_FORMAT) if start_dt else start_str,
        "completion_date": completion_dt.strftime(DATE_FORMAT) if completion_dt else None,
        "rating": rating_val,
        "notes": notes,
        "is_sample": is_sample,
    }
    return True, [], cleaned


def validate_storage_schema(records: Any) -> tuple[bool, list[str]]:
    """Validate that a parsed JSON payload matches the expected list-of-books schema."""
    if not isinstance(records, list):
        return False, ["Root JSON value must be a list of book records."]
    issues: list[str] = []
    required_keys = {"id", "title", "author", "genre", "pages", "status", "start_date"}
    for idx, item in enumerate(records):
        if not isinstance(item, dict):
            issues.append(f"Record #{idx + 1} is not a JSON object.")
            continue
        missing = required_keys - set(item.keys())
        if missing:
            issues.append(f"Record #{idx + 1} is missing keys: {', '.join(sorted(missing))}.")
    return len(issues) == 0, issues
