"""Centralized JSON and CSV persistence layer with automatic recovery."""

from __future__ import annotations

import csv
import json
import shutil
from datetime import datetime
from pathlib import Path
from typing import Optional

from .models import CSV_COLUMNS, AppSettings, BookRecord
from .validation import validate_storage_schema

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
DEFAULT_BOOKS_PATH = DATA_DIR / "books.json"
DEFAULT_CSV_PATH = DATA_DIR / "books.csv"
DEFAULT_SETTINGS_PATH = DATA_DIR / "settings.json"
SAMPLE_JSON_PATH = DATA_DIR / "sample_books.json"
SAMPLE_CSV_PATH = DATA_DIR / "sample_books.csv"


class StorageLoadResult:
    """Encapsulates loaded records along with any non-fatal recovery notices."""

    def __init__(self, books: list[BookRecord], warnings: Optional[list[str]] = None) -> None:
        self.books = books
        self.warnings = warnings or []


def ensure_data_dir(target_path: Path) -> None:
    """Create parent directories if they do not exist."""
    target_path.parent.mkdir(parents=True, exist_ok=True)


def load_books(books_path: Path = DEFAULT_BOOKS_PATH) -> StorageLoadResult:
    """
    Load book records from JSON storage.

    - Creates an empty JSON array file if missing.
    - Never overwrites existing valid data with sample records.
    - Handles corrupted JSON or invalid schema by backing up the bad file and returning empty list + warning.
    """
    ensure_data_dir(books_path)
    warnings: list[str] = []

    if not books_path.exists():
        save_books([], books_path)
        return StorageLoadResult([], warnings)

    try:
        raw_text = books_path.read_text(encoding="utf-8")
    except OSError as exc:
        warnings.append(f"Unable to read storage file ({exc}). Starting with an empty in-memory list.")
        return StorageLoadResult([], warnings)

    if not raw_text.strip():
        warnings.append("Storage file was empty; initialized an empty book list.")
        save_books([], books_path)
        return StorageLoadResult([], warnings)

    try:
        parsed = json.loads(raw_text)
    except json.JSONDecodeError as exc:
        backup_path = _backup_corrupted_file(books_path)
        warnings.append(
            f"Corrupted JSON detected ({exc.msg} at line {exc.lineno}). "
            f"Backed up damaged file to '{backup_path.name}' and initialized clean storage."
        )
        save_books([], books_path)
        return StorageLoadResult([], warnings)

    is_valid_schema, schema_issues = validate_storage_schema(parsed)
    if not is_valid_schema:
        backup_path = _backup_corrupted_file(books_path)
        warnings.append(
            f"Invalid storage schema ({'; '.join(schema_issues[:3])}). "
            f"Backed up file to '{backup_path.name}' and initialized clean storage."
        )
        save_books([], books_path)
        return StorageLoadResult([], warnings)

    books: list[BookRecord] = []
    for idx, item in enumerate(parsed):
        try:
            books.append(BookRecord.from_dict(item))
        except (TypeError, ValueError) as exc:
            warnings.append(f"Skipped malformed record #{idx + 1}: {exc}")

    return StorageLoadResult(books, warnings)


def save_books(books: list[BookRecord], books_path: Path = DEFAULT_BOOKS_PATH) -> None:
    """Atomically persist book records to JSON and sync CSV interchange copy."""
    ensure_data_dir(books_path)
    temp_path = books_path.with_suffix(".json.tmp")
    serialized = [b.to_dict() for b in books]
    temp_path.write_text(json.dumps(serialized, indent=2, ensure_ascii=False), encoding="utf-8")
    temp_path.replace(books_path)

    # Keep a synchronized CSV interchange mirror alongside books.json when using default directory
    csv_mirror = books_path.with_suffix(".csv")
    try:
        write_books_csv(books, csv_mirror)
    except OSError:
        # CSV mirror failure must never break primary JSON persistence
        pass


def write_books_csv(books: list[BookRecord], csv_path: Path = DEFAULT_CSV_PATH) -> None:
    """Write standardized CSV interchange file."""
    ensure_data_dir(csv_path)
    with csv_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(CSV_COLUMNS))
        writer.writeheader()
        for book in books:
            row = book.to_dict()
            row["completion_date"] = row["completion_date"] or ""
            row["rating"] = "" if row["rating"] is None else row["rating"]
            row["is_sample"] = "true" if row["is_sample"] else "false"
            writer.writerow(row)


def load_settings(settings_path: Path = DEFAULT_SETTINGS_PATH) -> AppSettings:
    """Load persisted settings, returning safe defaults if missing or corrupted."""
    ensure_data_dir(settings_path)
    if not settings_path.exists():
        defaults = AppSettings()
        save_settings(defaults, settings_path)
        return defaults
    try:
        raw = json.loads(settings_path.read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            return AppSettings.from_dict(raw)
    except (OSError, json.JSONDecodeError):
        pass
    return AppSettings()


def save_settings(settings: AppSettings, settings_path: Path = DEFAULT_SETTINGS_PATH) -> None:
    """Persist application settings to JSON."""
    ensure_data_dir(settings_path)
    settings_path.write_text(json.dumps(settings.to_dict(), indent=2), encoding="utf-8")


def load_sample_dataset(sample_path: Path = SAMPLE_JSON_PATH) -> list[BookRecord]:
    """Load the bundled realistic sample dataset without mutating active storage."""
    if not sample_path.exists():
        return []
    raw = json.loads(sample_path.read_text(encoding="utf-8"))
    return [BookRecord.from_dict({**item, "is_sample": True}) for item in raw]


def _backup_corrupted_file(path: Path) -> Path:
    """Preserve a corrupted file with a timestamped suffix before resetting."""
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = path.with_name(f"{path.stem}.corrupted_{stamp}{path.suffix}")
    shutil.copy2(path, backup)
    return backup
