"""Matplotlib and Plotly chart builders with graceful missing-dependency fallbacks."""

from __future__ import annotations

import io
from typing import Any, Optional

from .analytics import (
    compute_genre_distribution,
    compute_monthly_series,
    compute_status_distribution,
    compute_yearly_comparison,
)
from .models import BookRecord

try:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    MATPLOTLIB_AVAILABLE = True
except ImportError:
    plt = None  # type: ignore[assignment]
    MATPLOTLIB_AVAILABLE = False

try:
    import plotly.graph_objects as go

    PLOTLY_AVAILABLE = True
except ImportError:
    go = None  # type: ignore[assignment]
    PLOTLY_AVAILABLE = False

PALETTE = [
    "#1E3A8A",
    "#0F766E",
    "#2563EB",
    "#D97706",
    "#4F46E5",
    "#059669",
    "#64748B",
    "#B45309",
    "#0284C7",
    "#475569",
]


def dependency_status() -> dict[str, bool]:
    """Report availability of optional plotting libraries."""
    return {
        "matplotlib": MATPLOTLIB_AVAILABLE,
        "plotly": PLOTLY_AVAILABLE,
    }


def _fig_to_png_bytes(fig: Any) -> bytes:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=180, bbox_inches="tight", facecolor="#FFFFFF")
    plt.close(fig)
    buf.seek(0)
    return buf.getvalue()


def build_monthly_books_matplotlib(books: list[BookRecord]) -> tuple[Optional[Any], Optional[bytes], Optional[str]]:
    """Build Matplotlib bar chart of monthly books completed and return (fig, png_bytes, error)."""
    if not MATPLOTLIB_AVAILABLE:
        return None, None, "Matplotlib is not installed. Run `pip install matplotlib` to render static PNG charts."
    series = compute_monthly_series(books)
    if not series:
        return None, None, "No completed books with valid completion dates to plot."

    recent = series[-12:]
    labels = [row["label"] for row in recent]
    values = [row["books"] for row in recent]

    fig, ax = plt.subplots(figsize=(8.5, 4.2))
    bars = ax.bar(labels, values, color="#1E3A8A", width=0.58)
    ax.set_title("Monthly Books Completed", fontsize=12, fontweight="bold", color="#0F172A", pad=12)
    ax.set_ylabel("Books Completed", fontsize=10, color="#334155")
    ax.yaxis.get_major_locator().set_params(integer=True)
    ax.grid(axis="y", linestyle="--", alpha=0.35, color="#CBD5E1")
    ax.set_axisbelow(True)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    plt.xticks(rotation=30, ha="right", fontsize=8.5, color="#475569")

    for bar in bars:
        height = bar.get_height()
        ax.annotate(
            f"{int(height)}",
            xy=(bar.get_x() + bar.get_width() / 2, height),
            xytext=(0, 4),
            textcoords="offset points",
            ha="center",
            fontsize=8.5,
            color="#0F172A",
        )

    png_bytes = _fig_to_png_bytes(fig)
    return fig, png_bytes, None


def build_monthly_pages_matplotlib(books: list[BookRecord]) -> tuple[Optional[Any], Optional[bytes], Optional[str]]:
    """Build Matplotlib line chart of monthly pages read."""
    if not MATPLOTLIB_AVAILABLE:
        return None, None, "Matplotlib is not installed. Run `pip install matplotlib` to render static PNG charts."
    series = compute_monthly_series(books)
    if not series:
        return None, None, "No completed books with valid completion dates to plot."

    recent = series[-12:]
    labels = [row["label"] for row in recent]
    pages = [row["pages"] for row in recent]

    fig, ax = plt.subplots(figsize=(8.5, 4.2))
    ax.plot(labels, pages, marker="o", linewidth=2.2, color="#0F766E", markersize=6)
    ax.fill_between(range(len(labels)), pages, color="#0F766E", alpha=0.10)
    ax.set_title("Pages Read Over Time", fontsize=12, fontweight="bold", color="#0F172A", pad=12)
    ax.set_ylabel("Pages Read", fontsize=10, color="#334155")
    ax.grid(axis="y", linestyle="--", alpha=0.35, color="#CBD5E1")
    ax.set_axisbelow(True)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    plt.xticks(rotation=30, ha="right", fontsize=8.5, color="#475569")

    png_bytes = _fig_to_png_bytes(fig)
    return fig, png_bytes, None


def build_genre_distribution_matplotlib(books: list[BookRecord]) -> tuple[Optional[Any], Optional[bytes], Optional[str]]:
    """Build Matplotlib donut chart of genre distribution."""
    if not MATPLOTLIB_AVAILABLE:
        return None, None, "Matplotlib is not installed. Run `pip install matplotlib` to render static PNG charts."
    dist = compute_genre_distribution(books, completed_only=True)
    if not dist:
        return None, None, "No completed books available for genre distribution."

    labels = [row["genre"] for row in dist]
    counts = [row["count"] for row in dist]
    colors = [PALETTE[i % len(PALETTE)] for i in range(len(labels))]

    fig, ax = plt.subplots(figsize=(7.2, 4.5))
    wedges, texts, autotexts = ax.pie(
        counts,
        labels=labels,
        autopct="%1.1f%%",
        startangle=140,
        colors=colors,
        pctdistance=0.78,
        wedgeprops={"width": 0.42, "edgecolor": "#FFFFFF", "linewidth": 1.5},
        textprops={"fontsize": 8.5, "color": "#1E293B"},
    )
    for autotext in autotexts:
        autotext.set_color("#FFFFFF")
        autotext.set_fontsize(8)
        autotext.set_fontweight("bold")
    ax.set_title("Genre Distribution (Completed Books)", fontsize=12, fontweight="bold", color="#0F172A", pad=10)

    png_bytes = _fig_to_png_bytes(fig)
    return fig, png_bytes, None


def build_yearly_comparison_matplotlib(books: list[BookRecord]) -> tuple[Optional[Any], Optional[bytes], Optional[str]]:
    """Build Matplotlib bar chart comparing books and pages across years."""
    if not MATPLOTLIB_AVAILABLE:
        return None, None, "Matplotlib is not installed. Run `pip install matplotlib` to render static PNG charts."
    yearly = compute_yearly_comparison(books)
    if not yearly:
        return None, None, "No yearly reading records available."

    years = [str(row["year"]) for row in yearly]
    book_counts = [row["books"] for row in yearly]
    page_counts = [row["pages"] for row in yearly]

    fig, ax1 = plt.subplots(figsize=(8.0, 4.2))
    x = range(len(years))
    ax1.bar([i - 0.18 for i in x], book_counts, width=0.35, color="#1E3A8A", label="Books Completed")
    ax1.set_ylabel("Books Completed", color="#1E3A8A", fontsize=10)
    ax1.set_xticks(list(x))
    ax1.set_xticklabels(years, fontsize=9.5)
    ax1.spines["top"].set_visible(False)

    ax2 = ax1.twinx()
    ax2.bar([i + 0.18 for i in x], page_counts, width=0.35, color="#0F766E", label="Total Pages")
    ax2.set_ylabel("Total Pages", color="#0F766E", fontsize=10)
    ax2.spines["top"].set_visible(False)

    ax1.set_title("Yearly Reading Comparison", fontsize=12, fontweight="bold", color="#0F172A", pad=12)
    png_bytes = _fig_to_png_bytes(fig)
    return fig, png_bytes, None


def build_status_distribution_matplotlib(books: list[BookRecord]) -> tuple[Optional[Any], Optional[bytes], Optional[str]]:
    """Build Matplotlib horizontal bar chart of reading statuses."""
    if not MATPLOTLIB_AVAILABLE:
        return None, None, "Matplotlib is not installed. Run `pip install matplotlib` to render static PNG charts."
    dist = compute_status_distribution(books)
    if not dist:
        return None, None, "No books stored yet."

    statuses = [row["status"] for row in dist]
    counts = [row["count"] for row in dist]
    colors = ["#0F766E", "#2563EB", "#64748B"]

    fig, ax = plt.subplots(figsize=(7.5, 3.4))
    bars = ax.barh(statuses, counts, color=colors[: len(statuses)], height=0.52)
    ax.set_title("Reading Status Breakdown", fontsize=12, fontweight="bold", color="#0F172A", pad=10)
    ax.set_xlabel("Book Count", fontsize=10, color="#334155")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    for bar in bars:
        width = bar.get_width()
        ax.annotate(
            f"{int(width)}",
            xy=(width, bar.get_y() + bar.get_height() / 2),
            xytext=(5, 0),
            textcoords="offset points",
            va="center",
            fontsize=9,
            color="#0F172A",
        )

    png_bytes = _fig_to_png_bytes(fig)
    return fig, png_bytes, None


def build_plotly_monthly_activity(books: list[BookRecord]) -> tuple[Optional[Any], Optional[str]]:
    """Optional interactive Plotly chart with clean ImportError fallback."""
    if not PLOTLY_AVAILABLE:
        return None, "Plotly is not installed. Install `plotly` for interactive charts or use the Matplotlib view."
    series = compute_monthly_series(books)
    if not series:
        return None, "No completed books available to plot."
    fig = go.Figure(
        data=[
            go.Bar(
                x=[row["label"] for row in series],
                y=[row["books"] for row in series],
                marker_color="#1E3A8A",
                hovertemplate="%{x}<br>Books: %{y}<extra></extra>",
            )
        ]
    )
    fig.update_layout(
        title="Monthly Books Completed",
        xaxis_title="Month",
        yaxis_title="Books",
        template="plotly_white",
        height=360,
        margin=dict(l=40, r=20, t=48, b=40),
    )
    return fig, None
