"""Book CRUD operations, multi-criteria search/filtering, sorting, and pagination."""

from __future__ import annotations

import math
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from .models import AppSettings, BookRecord
from .storage import (
    DEFAULT_BOOKS_PATH,
    SAMPLE_JSON_PATH,
    load_books,
    load_sample_dataset,
    save_books,
)
from .validation import parse_iso_date, validate_book_payload


@dataclass
class FilterCriteria:
    """Combined search and filter options for library queries."""

    query: str = ""
    genre: str = "All"
    status: str = "All"
    year: Optional[int] = None
    month: Optional[int] = None
    start_date_from: Optional[str] = None
    completion_date_from: Optional[str] = None
    completion_date_to: Optional[str] = None
    min_pages: Optional[int] = None
    max_pages: Optional[int] = None
    min_rating: Optional[float] = None


@dataclass
class PaginatedResult:
    """Paginated slice of books along with pagination metadata."""

    items: list[BookRecord]
    total_items: int
    page: int
    page_size: int
    total_pages: int


class BookManager:
    """Coordinates validated CRUD operations and persistent state."""

    def __init__(
        self,
        books_path: Path = DEFAULT_BOOKS_PATH,
        settings: Optional[AppSettings] = None,
    ) -> None:
        self.books_path = books_path
        self.settings = settings or AppSettings()
        load_result = load_books(self.books_path)
        self.books: list[BookRecord] = load_result.books
        self.startup_warnings: list[str] = load_result.warnings

    def reload(self) -> None:
        """Refresh in-memory records from disk."""
        load_result = load_books(self.books_path)
        self.books = load_result.books
        self.startup_warnings = load_result.warnings

    def get_all(self) -> list[BookRecord]:
        return list(self.books)

    def get_by_id(self, book_id: str) -> Optional[BookRecord]:
        return next((b for b in self.books if b.id == book_id), None)

    def add_book(
        self,
        payload: dict[str, Any],
        allow_duplicate: bool = False,
    ) -> tuple[bool, list[str], Optional[BookRecord]]:
        """Validate and persist a new book record."""
        is_valid, errors, cleaned = validate_book_payload(
            payload=payload,
            existing_books=self.books,
            settings=self.settings,
            allow_duplicate=allow_duplicate,
        )
        if not is_valid or cleaned is None:
            return False, errors, None

        book_id = cleaned["id"] or f"bk-{uuid.uuid4().hex[:8]}"
        while any(b.id == book_id for b in self.books):
            book_id = f"bk-{uuid.uuid4().hex[:8]}"

        record = BookRecord(
            id=book_id,
            title=cleaned["title"],
            author=cleaned["author"],
            genre=cleaned["genre"],
            pages=int(cleaned["pages"]),
            status=cleaned["status"],
            start_date=cleaned["start_date"],
            completion_date=cleaned["completion_date"],
            rating=cleaned["rating"],
            notes=cleaned["notes"],
            is_sample=bool(cleaned.get("is_sample", False)),
        )
        self.books.append(record)
        save_books(self.books, self.books_path)
        return True, [], record

    def update_book(
        self,
        book_id: str,
        payload: dict[str, Any],
        allow_duplicate: bool = False,
    ) -> tuple[bool, list[str], Optional[BookRecord]]:
        """Validate and update an existing book record by ID."""
        index = next((i for i, b in enumerate(self.books) if b.id == book_id), -1)
        if index < 0:
            return False, [f"Book record '{book_id}' was not found."], None

        existing = self.books[index]
        merged = {**existing.to_dict(), **payload, "id": book_id}
        is_valid, errors, cleaned = validate_book_payload(
            payload=merged,
            existing_books=self.books,
            settings=self.settings,
            exclude_id=book_id,
            allow_duplicate=allow_duplicate,
        )
        if not is_valid or cleaned is None:
            return False, errors, None

        updated = BookRecord(
            id=book_id,
            title=cleaned["title"],
            author=cleaned["author"],
            genre=cleaned["genre"],
            pages=int(cleaned["pages"]),
            status=cleaned["status"],
            start_date=cleaned["start_date"],
            completion_date=cleaned["completion_date"],
            rating=cleaned["rating"],
            notes=cleaned["notes"],
            is_sample=bool(cleaned.get("is_sample", existing.is_sample)),
        )
        self.books[index] = updated
        save_books(self.books, self.books_path)
        return True, [], updated

    def delete_book(self, book_id: str) -> tuple[bool, str]:
        """Delete a book record by ID and persist changes."""
        before = len(self.books)
        self.books = [b for b in self.books if b.id != book_id]
        if len(self.books) == before:
            return False, f"Book record '{book_id}' was not found."
        save_books(self.books, self.books_path)
        return True, "Book record deleted."

    def clear_all_books(self) -> None:
        """Remove all books and persist an empty database."""
        self.books = []
        save_books(self.books, self.books_path)

    def load_demo_dataset(
        self,
        replace_existing: bool = False,
        sample_path: Path = SAMPLE_JSON_PATH,
    ) -> tuple[int, int]:
        """
        Insert realistic sample books without duplicating existing sample or user entries.

        Returns (added_count, skipped_count).
        """
        samples = load_sample_dataset(sample_path)
        if replace_existing:
            self.books = samples
            save_books(self.books, self.books_path)
            return len(samples), 0

        added = 0
        skipped = 0
        existing_keys = {(b.title.strip().lower(), b.author.strip().lower()) for b in self.books}
        for sample in samples:
            key = (sample.title.strip().lower(), sample.author.strip().lower())
            if key in existing_keys:
                skipped += 1
                continue
            self.books.append(sample)
            existing_keys.add(key)
            added += 1

        if added > 0:
            save_books(self.books, self.books_path)
        return added, skipped

    def filter_books(
        self,
        criteria: Optional[FilterCriteria] = None,
        sort_by: str = "date_desc",
    ) -> list[BookRecord]:
        """Filter and sort stored books."""
        f = criteria or FilterCriteria()
        results = list(self.books)

        if f.query and f.query.strip():
            q = f.query.strip().lower()
            results = [
                b
                for b in results
                if q in b.title.lower() or q in b.author.lower() or q in b.notes.lower()
            ]

        if f.genre and f.genre != "All":
            results = [b for b in results if b.genre == f.genre]

        if f.status and f.status != "All":
            results = [b for b in results if b.status == f.status]

        if f.year is not None:
            year_prefix = f"{f.year:04d}-"
            results = [
                b
                for b in results
                if (b.completion_date and b.completion_date.startswith(year_prefix))
                or (not b.completion_date and b.start_date.startswith(year_prefix))
            ]

        if f.month is not None:
            month_token = f"-{f.month:02d}-"
            results = [
                b
                for b in results
                if (b.completion_date and month_token in b.completion_date)
                or (not b.completion_date and month_token in b.start_date)
            ]

        comp_from = parse_iso_date(f.completion_date_from)
        if comp_from is not None:
            filtered = []
            for b in results:
                dt = parse_iso_date(b.completion_date)
                if dt is not None and dt >= comp_from:
                    filtered.append(b)
            results = filtered

        comp_to = parse_iso_date(f.completion_date_to)
        if comp_to is not None:
            filtered = []
            for b in results:
                dt = parse_iso_date(b.completion_date)
                if dt is not None and dt <= comp_to:
                    filtered.append(b)
            results = filtered

        if f.min_pages is not None:
            results = [b for b in results if b.pages >= f.min_pages]

        if f.max_pages is not None:
            results = [b for b in results if b.pages <= f.max_pages]

        if f.min_rating is not None:
            results = [b for b in results if b.rating is not None and b.rating >= f.min_rating]

        return sort_books(results, sort_by=sort_by)


def sort_books(books: list[BookRecord], sort_by: str = "date_desc") -> list[BookRecord]:
    """Sort books by title, pages, rating, or date."""
    if sort_by == "title_asc":
        return sorted(books, key=lambda b: b.title.lower())
    if sort_by == "title_desc":
        return sorted(books, key=lambda b: b.title.lower(), reverse=True)
    if sort_by == "pages_desc":
        return sorted(books, key=lambda b: b.pages, reverse=True)
    if sort_by == "pages_asc":
        return sorted(books, key=lambda b: b.pages)
    if sort_by == "rating_desc":
        return sorted(books, key=lambda b: (b.rating is not None, b.rating or 0.0), reverse=True)
    if sort_by == "rating_asc":
        return sorted(books, key=lambda b: (b.rating is None, b.rating or 99.0))
    if sort_by == "date_asc":
        return sorted(books, key=lambda b: b.completion_date or b.start_date)
    # Default: newest activity first
    return sorted(books, key=lambda b: b.completion_date or b.start_date, reverse=True)


def paginate_books(books: list[BookRecord], page: int = 1, page_size: int = 12) -> PaginatedResult:
    """Return a clean paginated slice of books."""
    safe_size = max(1, page_size)
    total_items = len(books)
    total_pages = max(1, math.ceil(total_items / safe_size))
    safe_page = max(1, min(page, total_pages))
    start = (safe_page - 1) * safe_size
    end = start + safe_size
    return PaginatedResult(
        items=books[start:end],
        total_items=total_items,
        page=safe_page,
        page_size=safe_size,
        total_pages=total_pages,
    )
