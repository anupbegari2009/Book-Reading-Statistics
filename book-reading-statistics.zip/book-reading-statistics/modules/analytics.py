"""Statistical calculations, monthly/yearly trends, insights, and threshold warnings."""

from __future__ import annotations

import math
from collections import Counter, defaultdict
from datetime import date
from typing import Any, Optional

from .models import READING_STATUSES, AppSettings, BookRecord, WarningItem
from .validation import normalize_text_key, parse_iso_date


def compute_dashboard_kpis(
    books: list[BookRecord],
    reference_date: Optional[date] = None,
) -> dict[str, Any]:
    """Calculate core KPIs from stored book records."""
    ref = reference_date or date.today()
    completed = [b for b in books if b.status == "Completed"]
    currently_reading = [b for b in books if b.status == "Currently Reading"]
    planned = [b for b in books if b.status == "Planned"]

    total_books_read = len(completed)
    total_pages_read = sum(b.pages for b in completed)
    avg_pages = round(total_pages_read / total_books_read, 1) if total_books_read > 0 else 0.0

    rated_completed = [b.rating for b in completed if b.rating is not None]
    avg_rating = round(sum(rated_completed) / len(rated_completed), 2) if rated_completed else None

    genres_explored = len({b.genre for b in completed}) if completed else len({b.genre for b in books})

    books_this_month = 0
    pages_this_month = 0
    books_this_year = 0
    pages_this_year = 0

    for book in completed:
        comp_dt = parse_iso_date(book.completion_date)
        if comp_dt is None:
            continue
        if comp_dt.year == ref.year:
            books_this_year += 1
            pages_this_year += book.pages
            if comp_dt.month == ref.month:
                books_this_month += 1
                pages_this_month += book.pages

    return {
        "total_stored": len(books),
        "total_books_read": total_books_read,
        "currently_reading_count": len(currently_reading),
        "planned_count": len(planned),
        "total_pages_read": total_pages_read,
        "average_pages": avg_pages,
        "average_rating": avg_rating,
        "genres_explored": genres_explored,
        "books_this_month": books_this_month,
        "pages_this_month": pages_this_month,
        "books_this_year": books_this_year,
        "pages_this_year": pages_this_year,
        "reference_year": ref.year,
        "reference_month_label": ref.strftime("%B %Y"),
    }


def compute_monthly_series(books: list[BookRecord]) -> list[dict[str, Any]]:
    """Aggregate completed books and pages read by YYYY-MM chronologically."""
    buckets: dict[str, dict[str, Any]] = defaultdict(lambda: {"books": 0, "pages": 0})

    for book in books:
        if book.status != "Completed":
            continue
        dt = parse_iso_date(book.completion_date)
        if dt is None:
            continue
        ym = dt.strftime("%Y-%m")
        buckets[ym]["books"] += 1
        buckets[ym]["pages"] += book.pages

    series: list[dict[str, Any]] = []
    for ym in sorted(buckets.keys()):
        year_num, month_num = map(int, ym.split("-"))
        label = date(year_num, month_num, 1).strftime("%b %Y")
        series.append(
            {
                "month_key": ym,
                "label": label,
                "books": buckets[ym]["books"],
                "pages": buckets[ym]["pages"],
            }
        )
    return series


def compute_yearly_comparison(books: list[BookRecord]) -> list[dict[str, Any]]:
    """Aggregate completed books, total pages, and average pages per year."""
    yearly: dict[int, dict[str, int]] = defaultdict(lambda: {"books": 0, "pages": 0})
    for book in books:
        if book.status != "Completed":
            continue
        dt = parse_iso_date(book.completion_date)
        if dt is None:
            continue
        yearly[dt.year]["books"] += 1
        yearly[dt.year]["pages"] += book.pages

    results: list[dict[str, Any]] = []
    for yr in sorted(yearly.keys()):
        count = yearly[yr]["books"]
        pages = yearly[yr]["pages"]
        results.append(
            {
                "year": yr,
                "books": count,
                "pages": pages,
                "avg_pages": round(pages / count, 1) if count > 0 else 0.0,
            }
        )
    return results


def compute_genre_distribution(books: list[BookRecord], completed_only: bool = True) -> list[dict[str, Any]]:
    """Return sorted genre counts, pages, and percentages."""
    subset = [b for b in books if b.status == "Completed"] if completed_only else list(books)
    if not subset:
        return []

    counts: Counter[str] = Counter()
    pages_by_genre: defaultdict[str, int] = defaultdict(int)
    for book in subset:
        counts[book.genre] += 1
        pages_by_genre[book.genre] += book.pages

    total = len(subset)
    distribution: list[dict[str, Any]] = []
    for genre, count in counts.most_common():
        distribution.append(
            {
                "genre": genre,
                "count": count,
                "pages": pages_by_genre[genre],
                "percentage": round((count / total) * 100, 1),
            }
        )
    return distribution


def compute_status_distribution(books: list[BookRecord]) -> list[dict[str, Any]]:
    """Return counts and percentages across all reading statuses."""
    total = len(books)
    if total == 0:
        return []
    counts = Counter(b.status for b in books)
    return [
        {
            "status": status,
            "count": counts.get(status, 0),
            "percentage": round((counts.get(status, 0) / total) * 100, 1),
        }
        for status in READING_STATUSES
    ]


def compute_reading_insights(
    books: list[BookRecord],
    reference_date: Optional[date] = None,
) -> dict[str, Any]:
    """Generate factual executive observations from stored records."""
    kpis = compute_dashboard_kpis(books, reference_date=reference_date)
    monthly = compute_monthly_series(books)
    genres = compute_genre_distribution(books, completed_only=True)

    if kpis["total_books_read"] == 0:
        return {
            "has_data": False,
            "most_read_genre": None,
            "most_productive_month": None,
            "highest_reading_month_pages": None,
            "avg_books_per_active_month": 0.0,
            "avg_pages_per_active_month": 0.0,
            "page_std_dev": 0.0,
            "longest_book": None,
            "observations": [
                "No completed books recorded yet. Add a completed book or load the sample dataset to generate reading insights."
            ],
        }

    most_read_genre = genres[0] if genres else None
    most_productive = max(monthly, key=lambda m: (m["books"], m["pages"])) if monthly else None
    highest_pages_month = max(monthly, key=lambda m: (m["pages"], m["books"])) if monthly else None

    active_months = len(monthly)
    avg_books_per_month = round(kpis["total_books_read"] / active_months, 2) if active_months else 0.0
    avg_pages_per_month = round(kpis["total_pages_read"] / active_months, 1) if active_months else 0.0

    completed_pages = [b.pages for b in books if b.status == "Completed"]
    mean_p = sum(completed_pages) / len(completed_pages)
    variance = sum((p - mean_p) ** 2 for p in completed_pages) / len(completed_pages)
    page_std_dev = round(math.sqrt(variance), 1)

    longest_book = max((b for b in books if b.status == "Completed"), key=lambda b: b.pages, default=None)

    observations: list[str] = []
    if most_read_genre:
        observations.append(
            f"Most-read genre is {most_read_genre['genre']} with {most_read_genre['count']} completed "
            f"books ({most_read_genre['percentage']}% of completions, {most_read_genre['pages']:,} pages)."
        )
    if most_productive:
        observations.append(
            f"Most productive month was {most_productive['label']} with {most_productive['books']} "
            f"books and {most_productive['pages']:,} pages completed."
        )
    observations.append(
        f"You have completed {kpis['books_this_year']} books ({kpis['pages_this_year']:,} pages) in "
        f"{kpis['reference_year']} and average {avg_books_per_month} books per active reading month."
    )
    if longest_book:
        observations.append(
            f"Longest completed work is '{longest_book.title}' by {longest_book.author} at {longest_book.pages:,} pages "
            f"(page spread SD: {page_std_dev} pages)."
        )

    return {
        "has_data": True,
        "most_read_genre": most_read_genre,
        "most_productive_month": most_productive,
        "highest_reading_month_pages": highest_pages_month,
        "avg_books_per_active_month": avg_books_per_month,
        "avg_pages_per_active_month": avg_pages_per_month,
        "page_std_dev": page_std_dev,
        "longest_book": longest_book.to_dict() if longest_book else None,
        "observations": observations,
    }


def detect_threshold_warnings(
    books: list[BookRecord],
    settings: Optional[AppSettings] = None,
    reference_date: Optional[date] = None,
) -> list[WarningItem]:
    """Identify anomalies, threshold alerts, duplicates, and target gaps without blocking usage."""
    cfg = settings or AppSettings()
    ref = reference_date or date.today()
    warnings: list[WarningItem] = []

    seen_keys: dict[tuple[str, str], BookRecord] = {}

    for book in books:
        if book.pages > cfg.high_page_threshold:
            warnings.append(
                WarningItem(
                    severity="warning",
                    code="HIGH_PAGE_COUNT",
                    message=f"'{book.title}' has {book.pages:,} pages (above {cfg.high_page_threshold:,}-page threshold).",
                    book_id=book.id,
                    book_title=book.title,
                )
            )

        start_dt = parse_iso_date(book.start_date)
        comp_dt = parse_iso_date(book.completion_date)
        if start_dt is None:
            warnings.append(
                WarningItem(
                    severity="error",
                    code="INVALID_START_DATE",
                    message=f"'{book.title}' has an invalid start date '{book.start_date}'.",
                    book_id=book.id,
                    book_title=book.title,
                )
            )
        if book.completion_date and comp_dt is None:
            warnings.append(
                WarningItem(
                    severity="error",
                    code="INVALID_COMPLETION_DATE",
                    message=f"'{book.title}' has an invalid completion date '{book.completion_date}'.",
                    book_id=book.id,
                    book_title=book.title,
                )
            )
        if start_dt and comp_dt and comp_dt < start_dt:
            warnings.append(
                WarningItem(
                    severity="error",
                    code="DATE_ORDER_CONFLICT",
                    message=f"'{book.title}' completion date ({book.completion_date}) precedes start date ({book.start_date}).",
                    book_id=book.id,
                    book_title=book.title,
                )
            )

        if book.status == "Completed":
            if not book.completion_date:
                warnings.append(
                    WarningItem(
                        severity="warning",
                        code="MISSING_COMPLETION_DATE",
                        message=f"Completed book '{book.title}' is missing a completion date.",
                        book_id=book.id,
                        book_title=book.title,
                    )
                )
            if book.rating is None:
                warnings.append(
                    WarningItem(
                        severity="info",
                        code="MISSING_RATING",
                        message=f"Completed book '{book.title}' has no personal rating recorded.",
                        book_id=book.id,
                        book_title=book.title,
                    )
                )

        key = normalize_text_key(book.title, book.author)
        if key in seen_keys:
            warnings.append(
                WarningItem(
                    severity="warning",
                    code="DUPLICATE_BOOK",
                    message=f"Possible duplicate entry for '{book.title}' by {book.author}.",
                    book_id=book.id,
                    book_title=book.title,
                )
            )
        else:
            seen_keys[key] = book

    # Monthly target progress warning
    kpis = compute_dashboard_kpis(books, reference_date=ref)
    if books and kpis["books_this_month"] < cfg.monthly_book_target:
        remaining = cfg.monthly_book_target - kpis["books_this_month"]
        warnings.append(
            WarningItem(
                severity="info",
                code="MONTHLY_BOOK_TARGET",
                message=(
                    f"{kpis['reference_month_label']} progress: {kpis['books_this_month']} of "
                    f"{cfg.monthly_book_target} target books completed ({remaining} remaining)."
                ),
            )
        )
    if books and kpis["pages_this_month"] < cfg.monthly_page_target:
        remaining_pages = cfg.monthly_page_target - kpis["pages_this_month"]
        warnings.append(
            WarningItem(
                severity="info",
                code="MONTHLY_PAGE_TARGET",
                message=(
                    f"{kpis['reference_month_label']} page goal: {kpis['pages_this_month']:,} of "
                    f"{cfg.monthly_page_target:,} pages read ({remaining_pages:,} remaining)."
                ),
            )
        )

    return warnings
