"""Book Reading Statistics — Streamlit Analytics Application."""

from __future__ import annotations

from datetime import date
from pathlib import Path

import streamlit as st

from modules.analytics import (
    compute_dashboard_kpis,
    compute_genre_distribution,
    compute_monthly_series,
    compute_reading_insights,
    compute_status_distribution,
    compute_yearly_comparison,
    detect_threshold_warnings,
)
from modules.book_manager import BookManager, FilterCriteria, paginate_books
from modules.exports import (
    export_books_to_csv,
    export_books_to_json,
    export_markdown_report,
    export_plain_text_audit,
)
from modules.imports import import_csv_content
from modules.models import GENRES, READING_STATUSES, AppSettings
from modules.storage import (
    DEFAULT_BOOKS_PATH,
    DEFAULT_SETTINGS_PATH,
    SAMPLE_CSV_PATH,
    load_settings,
    save_settings,
)
from modules.validation import parse_iso_date
from modules.visualizations import (
    build_genre_distribution_matplotlib,
    build_monthly_books_matplotlib,
    build_monthly_pages_matplotlib,
    build_plotly_monthly_activity,
    build_status_distribution_matplotlib,
    build_yearly_comparison_matplotlib,
    dependency_status,
)

APP_DIR = Path(__file__).resolve().parent
CSS_PATH = APP_DIR / "assets" / "styles.css"

NAV_PAGES = [
    "Dashboard",
    "Add a Book",
    "My Library",
    "Reading Analytics",
    "Search & Filter",
    "Import Dataset",
    "Export Reports",
    "Settings",
]


def load_custom_css() -> None:
    if CSS_PATH.exists():
        st.markdown(f"<style>{CSS_PATH.read_text(encoding='utf-8')}</style>", unsafe_allow_html=True)


def get_manager() -> BookManager:
    settings = load_settings(DEFAULT_SETTINGS_PATH)
    manager = BookManager(books_path=DEFAULT_BOOKS_PATH, settings=settings)
    return manager


def render_warnings_banner(manager: BookManager) -> None:
    for msg in manager.startup_warnings:
        st.warning(msg)

    warnings = detect_threshold_warnings(manager.books, settings=manager.settings)
    if warnings:
        with st.expander(f"Active Data & Target Notices ({len(warnings)})", expanded=False):
            for w in warnings:
                if w.severity == "error":
                    st.error(f"[{w.code}] {w.message}")
                elif w.severity == "warning":
                    st.warning(f"[{w.code}] {w.message}")
                else:
                    st.info(f"[{w.code}] {w.message}")


def render_dashboard(manager: BookManager) -> None:
    st.title("Reading Overview Dashboard")
    st.caption("Live reading metrics, monthly activity trends, and genre composition derived from local storage.")

    books = manager.books
    kpis = compute_dashboard_kpis(books)
    insights = compute_reading_insights(books)

    if not books:
        st.info("Your reading library is currently empty. Add your first book or load the demonstration dataset.")
        col1, col2 = st.columns(2)
        with col1:
            if st.button("Load Sample Dataset (40 Books)", type="primary"):
                added, _ = manager.load_demo_dataset()
                st.success(f"Loaded {added} sample records.")
                st.rerun()
        with col2:
            if st.button("Go to Add a Book"):
                st.session_state["nav_page"] = "Add a Book"
                st.rerun()
        return

    c1, c2, c3 = st.columns(3)
    c1.metric("Total Books Read", f"{kpis['total_books_read']}", f"{kpis['currently_reading_count']} currently reading")
    c2.metric("Total Pages Read", f"{kpis['total_pages_read']:,}", f"Avg {kpis['average_pages']} pages/book")
    c3.metric("Total Genres Explored", f"{kpis['genres_explored']}", f"{kpis['total_stored']} total records")

    c4, c5, c6 = st.columns(3)
    c4.metric(
        f"Books Read ({kpis['reference_month_label']})",
        f"{kpis['books_this_month']}",
        f"{kpis['pages_this_month']:,} pages this month",
    )
    c5.metric(
        f"Reading Activity ({kpis['reference_year']})",
        f"{kpis['books_this_year']} books",
        f"{kpis['pages_this_year']:,} pages this year",
    )
    avg_rating_label = f"{kpis['average_rating']:.2f} / 5.0" if kpis["average_rating"] is not None else "No ratings yet"
    c6.metric("Average Rating", avg_rating_label, f"Target: {manager.settings.monthly_book_target} books/mo")

    st.divider()

    col_left, col_right = st.columns(2)
    with col_left:
        st.subheader("Monthly Reading Activity")
        fig_m, _, err_m = build_monthly_books_matplotlib(books)
        if err_m:
            st.info(err_m)
        elif fig_m is not None:
            st.pyplot(fig_m)

    with col_right:
        st.subheader("Pages Read Over Time")
        fig_p, _, err_p = build_monthly_pages_matplotlib(books)
        if err_p:
            st.info(err_p)
        elif fig_p is not None:
            st.pyplot(fig_p)

    col_genre, col_insights = st.columns([1.15, 1])
    with col_genre:
        st.subheader("Genre Distribution")
        fig_g, _, err_g = build_genre_distribution_matplotlib(books)
        if err_g:
            st.info(err_g)
        elif fig_g is not None:
            st.pyplot(fig_g)

    with col_insights:
        st.subheader("Reading Insights")
        for obs in insights["observations"]:
            st.markdown(f"- {obs}")

    st.subheader("Recent Reading Activity")
    recent = manager.filter_books(sort_by="date_desc")[:8]
    rows = [
        {
            "Title": b.title,
            "Author": b.author,
            "Genre": b.genre,
            "Pages": b.pages,
            "Status": b.status,
            "Completion Date": b.completion_date or "In Progress",
            "Rating": f"{b.rating:.1f}" if b.rating is not None else "-",
        }
        for b in recent
    ]
    st.dataframe(rows, use_container_width=True, hide_index=True)


def render_add_book(manager: BookManager) -> None:
    st.title("Add a Book")
    st.caption("Record a new book with real-time validation and duplicate detection.")

    with st.form("add_book_form", clear_on_submit=False):
        col1, col2 = st.columns(2)
        with col1:
            title = st.text_input("Book Title *", placeholder="e.g., The Pragmatic Programmer")
            author = st.text_input("Author Name *", placeholder="e.g., David Thomas")
            genre = st.selectbox("Genre *", list(GENRES))
            pages_input = st.text_input("Total Pages *", value="320")
        with col2:
            status = st.selectbox("Reading Status *", list(READING_STATUSES))
            start_date_val = st.date_input("Start Date *", value=date.today())
            has_completion = st.checkbox("Include Completion Date", value=(status == "Completed"))
            completion_date_val = st.date_input("Completion Date", value=date.today())
            rating_input = st.text_input(
                f"Personal Rating ({manager.settings.rating_min:g} - {manager.settings.rating_max:g}, optional)",
                value="4.5",
            )

        notes = st.text_area("Optional Notes", placeholder="Key takeaways, themes, or reading context...")
        allow_dup = st.checkbox("Allow duplicate title + author if intentionally re-reading", value=False)
        submitted = st.form_submit_button("Save Book Record", type="primary")

    if submitted:
        payload = {
            "title": title,
            "author": author,
            "genre": genre,
            "pages": pages_input,
            "status": status,
            "start_date": start_date_val.strftime("%Y-%m-%d"),
            "completion_date": completion_date_val.strftime("%Y-%m-%d") if (has_completion or status == "Completed") else "",
            "rating": rating_input,
            "notes": notes,
        }
        ok, errors, created = manager.add_book(payload, allow_duplicate=allow_dup)
        if not ok:
            for err in errors:
                st.error(err)
        elif created is not None:
            st.success(f"Saved '{created.title}' by {created.author} ({created.pages:,} pages) to local storage.")


def render_my_library(manager: BookManager) -> None:
    st.title("My Library")
    st.caption("Browse, sort, inspect, edit, and delete stored reading records.")

    books = manager.books
    if not books:
        st.info("No books in your library yet. Visit 'Add a Book' or load the sample dataset from Settings.")
        return

    col_q, col_g, col_s, col_sort = st.columns([2, 1, 1, 1.2])
    query = col_q.text_input("Search title or author", placeholder="Filter by title, author, or notes...")
    genre = col_g.selectbox("Genre", ["All", *GENRES])
    status = col_s.selectbox("Status", ["All", *READING_STATUSES])
    sort_by = col_sort.selectbox(
        "Sort By",
        [
            ("date_desc", "Newest First"),
            ("date_asc", "Oldest First"),
            ("title_asc", "Title (A-Z)"),
            ("pages_desc", "Pages (High-Low)"),
            ("pages_asc", "Pages (Low-High)"),
            ("rating_desc", "Rating (High-Low)"),
        ],
        format_func=lambda opt: opt[1],
    )[0]

    years = sorted(
        {
            int((b.completion_date or b.start_date)[:4])
            for b in books
            if parse_iso_date(b.completion_date or b.start_date) is not None
        },
        reverse=True,
    )
    col_y, col_m, col_ps = st.columns(3)
    selected_year = col_y.selectbox("Year", ["All", *[str(y) for y in years]])
    selected_month = col_m.selectbox("Month", ["All", *[f"{m:02d}" for m in range(1, 13)]])
    page_size = col_ps.selectbox("Rows per Page", [10, 15, 25, 50], index=0)

    criteria = FilterCriteria(
        query=query,
        genre=genre,
        status=status,
        year=int(selected_year) if selected_year != "All" else None,
        month=int(selected_month) if selected_month != "All" else None,
    )
    filtered = manager.filter_books(criteria=criteria, sort_by=sort_by)

    total_pages = max(1, (len(filtered) + page_size - 1) // page_size)
    current_page = st.number_input("Page", min_value=1, max_value=total_pages, value=1, step=1)
    paginated = paginate_books(filtered, page=int(current_page), page_size=int(page_size))

    st.write(f"Showing **{len(paginated.items)}** of **{paginated.total_items}** matching books (Page {paginated.page}/{paginated.total_pages}).")

    table_rows = [
        {
            "ID": b.id,
            "Title": b.title,
            "Author": b.author,
            "Genre": b.genre,
            "Pages": b.pages,
            "Status": b.status,
            "Start": b.start_date,
            "Completed": b.completion_date or "-",
            "Rating": f"{b.rating:.1f}" if b.rating is not None else "-",
        }
        for b in paginated.items
    ]
    st.dataframe(table_rows, use_container_width=True, hide_index=True)

    if filtered:
        st.divider()
        selected_id = st.selectbox(
            "Select a Book to View Details, Edit, or Delete",
            options=[b.id for b in filtered],
            format_func=lambda bid: next(f"{b.title} — {b.author} ({b.status})" for b in filtered if b.id == bid),
        )
        selected_book = manager.get_by_id(selected_id)
        if selected_book:
            tab_view, tab_edit, tab_delete = st.tabs(["Book Details", "Edit Record", "Delete Record"])
            with tab_view:
                st.markdown(f"### {selected_book.title}")
                st.write(
                    f"**Author:** {selected_book.author}  |  **Genre:** {selected_book.genre}  |  "
                    f"**Pages:** {selected_book.pages:,}  |  **Status:** {selected_book.status}"
                )
                st.write(
                    f"**Start Date:** {selected_book.start_date}  |  "
                    f"**Completion Date:** {selected_book.completion_date or 'N/A'}  |  "
                    f"**Rating:** {selected_book.rating if selected_book.rating is not None else 'Unrated'}"
                )
                if selected_book.notes:
                    st.info(selected_book.notes)

            with tab_edit:
                with st.form(f"edit_form_{selected_book.id}"):
                    ec1, ec2 = st.columns(2)
                    with ec1:
                        e_title = st.text_input("Title", value=selected_book.title)
                        e_author = st.text_input("Author", value=selected_book.author)
                        e_genre = st.selectbox("Genre", list(GENRES), index=list(GENRES).index(selected_book.genre) if selected_book.genre in GENRES else 0)
                        e_pages = st.text_input("Pages", value=str(selected_book.pages))
                    with ec2:
                        e_status = st.selectbox("Status", list(READING_STATUSES), index=list(READING_STATUSES).index(selected_book.status) if selected_book.status in READING_STATUSES else 0)
                        e_start = st.text_input("Start Date (YYYY-MM-DD)", value=selected_book.start_date)
                        e_comp = st.text_input("Completion Date (YYYY-MM-DD)", value=selected_book.completion_date or "")
                        e_rating = st.text_input("Rating", value="" if selected_book.rating is None else str(selected_book.rating))
                    e_notes = st.text_area("Notes", value=selected_book.notes)
                    if st.form_submit_button("Update Book", type="primary"):
                        ok, errs, _ = manager.update_book(
                            selected_book.id,
                            {
                                "title": e_title,
                                "author": e_author,
                                "genre": e_genre,
                                "pages": e_pages,
                                "status": e_status,
                                "start_date": e_start,
                                "completion_date": e_comp,
                                "rating": e_rating,
                                "notes": e_notes,
                            },
                        )
                        if not ok:
                            for err in errs:
                                st.error(err)
                        else:
                            st.success("Book record updated.")
                            st.rerun()

            with tab_delete:
                st.warning(f"Deleting '{selected_book.title}' removes it permanently from {manager.books_path.name}.")
                confirm = st.checkbox("Confirm permanent deletion", key=f"del_confirm_{selected_book.id}")
                if st.button("Delete Book", type="primary", disabled=not confirm, key=f"del_btn_{selected_book.id}"):
                    ok, msg = manager.delete_book(selected_book.id)
                    if ok:
                        st.success(msg)
                        st.rerun()
                    else:
                        st.error(msg)


def render_analytics(manager: BookManager) -> None:
    st.title("Reading Analytics")
    st.caption("Multi-year trends, monthly pace, genre share, and reading status composition.")

    books = manager.books
    if not books:
        st.info("No stored data to analyze yet. Add books or load the sample dataset first.")
        return

    kpis = compute_dashboard_kpis(books)
    insights = compute_reading_insights(books)
    monthly = compute_monthly_series(books)
    yearly = compute_yearly_comparison(books)
    genres = compute_genre_distribution(books, completed_only=True)
    statuses = compute_status_distribution(books)

    a1, a2, a3, a4 = st.columns(4)
    a1.metric("Completed Books", f"{kpis['total_books_read']}")
    a2.metric("Total Pages Read", f"{kpis['total_pages_read']:,}")
    a3.metric("Avg Pages / Book", f"{kpis['average_pages']}")
    a4.metric("Avg Books / Active Month", f"{insights['avg_books_per_active_month']}")

    deps = dependency_status()
    if not deps["matplotlib"]:
        st.warning("Matplotlib is not installed; displaying tabular analytics fallback.")

    ch1, ch2 = st.columns(2)
    with ch1:
        st.subheader("1. Monthly Books Completed")
        fig1, _, err1 = build_monthly_books_matplotlib(books)
        if err1:
            st.info(err1)
        elif fig1:
            st.pyplot(fig1)

    with ch2:
        st.subheader("2. Monthly Pages Read")
        fig2, _, err2 = build_monthly_pages_matplotlib(books)
        if err2:
            st.info(err2)
        elif fig2:
            st.pyplot(fig2)

    ch3, ch4 = st.columns(2)
    with ch3:
        st.subheader("3. Genre Distribution")
        fig3, _, err3 = build_genre_distribution_matplotlib(books)
        if err3:
            st.info(err3)
        elif fig3:
            st.pyplot(fig3)

    with ch4:
        st.subheader("4. Yearly Reading Comparison")
        fig4, _, err4 = build_yearly_comparison_matplotlib(books)
        if err4:
            st.info(err4)
        elif fig4:
            st.pyplot(fig4)

    st.subheader("5. Reading Status Distribution")
    fig5, _, err5 = build_status_distribution_matplotlib(books)
    if err5:
        st.info(err5)
    elif fig5:
        st.pyplot(fig5)

    if deps["plotly"]:
        st.subheader("Interactive Monthly Activity (Plotly)")
        p_fig, p_err = build_plotly_monthly_activity(books)
        if p_fig:
            st.plotly_chart(p_fig, use_container_width=True)
        elif p_err:
            st.info(p_err)

    with st.expander("Detailed Statistical Tables"):
        st.write("**Yearly Summary**")
        st.dataframe(yearly, use_container_width=True, hide_index=True)
        st.write("**Genre Summary**")
        st.dataframe(genres, use_container_width=True, hide_index=True)
        st.write("**Status Summary**")
        st.dataframe(statuses, use_container_width=True, hide_index=True)
        st.write("**Monthly Totals**")
        st.dataframe(monthly, use_container_width=True, hide_index=True)


def render_search_filter(manager: BookManager) -> None:
    st.title("Search & Filter")
    st.caption("Combine text search, genre, status, completion date window, and page range filters.")

    if "sf_query" not in st.session_state:
        st.session_state["sf_query"] = ""

    with st.form("search_filter_form"):
        c1, c2, c3 = st.columns(3)
        query = c1.text_input("Title or Author Keyword", key="sf_query")
        genre = c2.selectbox("Genre", ["All", *GENRES], key="sf_genre")
        status = c3.selectbox("Reading Status", ["All", *READING_STATUSES], key="sf_status")

        c4, c5, c6, c7 = st.columns(4)
        comp_from = c4.text_input("Completed From (YYYY-MM-DD)", key="sf_from")
        comp_to = c5.text_input("Completed To (YYYY-MM-DD)", key="sf_to")
        min_pages = c6.number_input("Min Pages", min_value=0, value=0, step=50, key="sf_min_p")
        max_pages = c7.number_input("Max Pages (0 = no cap)", min_value=0, value=0, step=100, key="sf_max_p")

        b1, b2 = st.columns([1, 4])
        apply_btn = b1.form_submit_button("Apply Filters", type="primary")
        clear_btn = b2.form_submit_button("Clear Filters")

    if clear_btn:
        for key in ("sf_query", "sf_from", "sf_to"):
            st.session_state[key] = ""
        st.session_state["sf_genre"] = "All"
        st.session_state["sf_status"] = "All"
        st.session_state["sf_min_p"] = 0
        st.session_state["sf_max_p"] = 0
        st.rerun()

    criteria = FilterCriteria(
        query=query,
        genre=genre,
        status=status,
        completion_date_from=comp_from or None,
        completion_date_to=comp_to or None,
        min_pages=int(min_pages) if min_pages > 0 else None,
        max_pages=int(max_pages) if max_pages > 0 else None,
    )
    matches = manager.filter_books(criteria=criteria, sort_by="date_desc")
    total_pages = sum(b.pages for b in matches)
    st.write(f"Found **{len(matches)}** matching record(s) totaling **{total_pages:,}** pages.")
    if matches:
        st.dataframe(
            [
                {
                    "Title": b.title,
                    "Author": b.author,
                    "Genre": b.genre,
                    "Pages": b.pages,
                    "Status": b.status,
                    "Start Date": b.start_date,
                    "Completion Date": b.completion_date or "-",
                    "Rating": f"{b.rating:.1f}" if b.rating is not None else "-",
                }
                for b in matches
            ],
            use_container_width=True,
            hide_index=True,
        )
    else:
        st.info("No records matched the selected criteria.")


def render_import_dataset(manager: BookManager) -> None:
    st.title("Import Dataset")
    st.caption("Bulk import book records from CSV with column validation, duplicate detection, and row-level diagnostics.")

    uploaded = st.file_uploader("Upload CSV File", type=["csv"])
    skip_dups = st.checkbox("Skip duplicate records (recommended)", value=True)

    if SAMPLE_CSV_PATH.exists():
        st.download_button(
            "Download Sample CSV Template",
            data=SAMPLE_CSV_PATH.read_text(encoding="utf-8"),
            file_name="sample_books.csv",
            mime="text/csv",
        )

    if uploaded is not None and st.button("Run CSV Import", type="primary"):
        try:
            csv_text = uploaded.getvalue().decode("utf-8-sig")
        except UnicodeDecodeError:
            st.error("Unable to decode uploaded CSV as UTF-8.")
            return
        header_ok, header_err, summary = import_csv_content(csv_text, manager, skip_duplicates=skip_dups)
        if not header_ok:
            st.error(header_err or "Invalid CSV file.")
            return

        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Total Rows", summary.total_rows)
        m2.metric("Imported", summary.imported_count)
        m3.metric("Duplicates Skipped", summary.duplicate_count)
        m4.metric("Invalid Rows", summary.failed_count)

        if summary.imported_count > 0:
            st.success(f"Successfully imported {summary.imported_count} book(s).")
        if summary.errors:
            st.subheader("Row-by-Row Import Notices")
            st.dataframe(
                [
                    {"Row": e.row_number, "Title": e.title, "Reason": e.reason}
                    for e in summary.errors
                ],
                use_container_width=True,
                hide_index=True,
            )


def render_export_reports(manager: BookManager) -> None:
    st.title("Export Reports")
    st.caption("Download structured data, executive summaries, audit reports, and chart PNGs.")

    scope = st.radio("Export Scope", ["All Stored Books", "Completed Books Only"], horizontal=True)
    books = manager.books if scope == "All Stored Books" else [b for b in manager.books if b.status == "Completed"]

    st.write(f"Selected dataset contains **{len(books)}** record(s).")

    c1, c2, c3, c4 = st.columns(4)
    c1.download_button(
        "Download CSV",
        data=export_books_to_csv(books),
        file_name="book_reading_statistics.csv",
        mime="text/csv",
    )
    c2.download_button(
        "Download JSON",
        data=export_books_to_json(books),
        file_name="book_reading_statistics.json",
        mime="application/json",
    )
    c3.download_button(
        "Download Markdown",
        data=export_markdown_report(books),
        file_name="reading_summary_report.md",
        mime="text/markdown",
    )
    c4.download_button(
        "Download Audit TXT",
        data=export_plain_text_audit(books),
        file_name="reading_audit_report.txt",
        mime="text/plain",
    )

    st.divider()
    st.subheader("Export Matplotlib Charts as PNG")
    chart_builders = [
        ("Monthly Books Completed", "monthly_books.png", build_monthly_books_matplotlib),
        ("Monthly Pages Read", "monthly_pages.png", build_monthly_pages_matplotlib),
        ("Genre Distribution", "genre_distribution.png", build_genre_distribution_matplotlib),
        ("Yearly Comparison", "yearly_comparison.png", build_yearly_comparison_matplotlib),
    ]
    cols = st.columns(2)
    for idx, (label, filename, builder) in enumerate(chart_builders):
        with cols[idx % 2]:
            _, png_bytes, err = builder(books)
            if png_bytes:
                st.download_button(
                    f"Download {label} (PNG)",
                    data=png_bytes,
                    file_name=filename,
                    mime="image/png",
                )
            else:
                st.info(f"{label}: {err}")


def render_settings(manager: BookManager) -> None:
    st.title("Settings & Storage Management")
    st.caption("Configure reading goals, warning thresholds, and local database controls.")

    s = manager.settings
    with st.form("settings_form"):
        c1, c2 = st.columns(2)
        monthly_books = c1.number_input("Monthly Book Target", min_value=1, max_value=50, value=s.monthly_book_target)
        monthly_pages = c2.number_input("Monthly Page Target", min_value=50, max_value=10000, value=s.monthly_page_target, step=50)
        high_pages = c1.number_input("High Page Count Warning Threshold", min_value=100, max_value=5000, value=s.high_page_threshold, step=50)
        page_size = c2.number_input("Default Library Page Size", min_value=5, max_value=100, value=s.default_page_size)
        strict_dup = st.checkbox("Strict Duplicate Prevention (block matching title + author)", value=s.strict_duplicate_check)
        if st.form_submit_button("Save Settings", type="primary"):
            updated = AppSettings(
                monthly_book_target=int(monthly_books),
                monthly_page_target=int(monthly_pages),
                high_page_threshold=int(high_pages),
                rating_min=s.rating_min,
                rating_max=s.rating_max,
                strict_duplicate_check=bool(strict_dup),
                default_page_size=int(page_size),
            )
            save_settings(updated, DEFAULT_SETTINGS_PATH)
            st.success("Settings saved.")
            st.rerun()

    st.divider()
    st.subheader("Database & Demo Data Controls")
    st.write(f"Primary JSON Database: `{DEFAULT_BOOKS_PATH}` ({len(manager.books)} records)")
    d1, d2 = st.columns(2)
    with d1:
        if st.button("Load Sample Dataset (Merge Non-Duplicates)"):
            added, skipped = manager.load_demo_dataset(replace_existing=False)
            st.success(f"Added {added} sample books ({skipped} duplicates skipped).")
            st.rerun()
    with d2:
        confirm_clear = st.checkbox("Confirm clearing all stored books")
        if st.button("Clear All Books (Empty Database)", disabled=not confirm_clear):
            manager.clear_all_books()
            st.success("Database cleared.")
            st.rerun()


def main() -> None:
    st.set_page_config(
        page_title="Book Reading Statistics",
        page_icon="📚",
        layout="wide",
        initial_sidebar_state="expanded",
    )
    load_custom_css()
    manager = get_manager()

    with st.sidebar:
        st.markdown("## Book Reading Statistics")
        st.caption("Data & Visualization Workspace")
        default_idx = 0
        if "nav_page" in st.session_state and st.session_state["nav_page"] in NAV_PAGES:
            default_idx = NAV_PAGES.index(st.session_state["nav_page"])
        page = st.radio("Navigation", NAV_PAGES, index=default_idx, label_visibility="collapsed")
        st.session_state["nav_page"] = page
        st.divider()
        st.caption(f"Stored books: {len(manager.books)}")

    render_warnings_banner(manager)

    if page == "Dashboard":
        render_dashboard(manager)
    elif page == "Add a Book":
        render_add_book(manager)
    elif page == "My Library":
        render_my_library(manager)
    elif page == "Reading Analytics":
        render_analytics(manager)
    elif page == "Search & Filter":
        render_search_filter(manager)
    elif page == "Import Dataset":
        render_import_dataset(manager)
    elif page == "Export Reports":
        render_export_reports(manager)
    elif page == "Settings":
        render_settings(manager)


if __name__ == "__main__":
    main()
