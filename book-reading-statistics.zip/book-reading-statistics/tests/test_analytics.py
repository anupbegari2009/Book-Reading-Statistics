"""Tests for analytics KPIs, monthly aggregation, genre distribution, and warnings."""

from __future__ import annotations

import sys
import unittest
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from modules.analytics import (
    compute_dashboard_kpis,
    compute_genre_distribution,
    compute_monthly_series,
    compute_reading_insights,
    compute_yearly_comparison,
    detect_threshold_warnings,
)
from modules.models import AppSettings, BookRecord


class TestAnalytics(unittest.TestCase):
    def setUp(self) -> None:
        self.books = [
            BookRecord("1", "Book A", "Author 1", "Science", 300, "Completed", "2026-01-01", "2026-01-15", 4.5),
            BookRecord("2", "Book B", "Author 2", "Science", 500, "Completed", "2026-01-16", "2026-01-29", 5.0),
            BookRecord("3", "Book C", "Author 3", "Fiction", 400, "Completed", "2026-11-01", "2026-11-12", 4.0),
            BookRecord("4", "Book D", "Author 4", "History", 1350, "Currently Reading", "2026-11-10", None, None),
        ]

    def test_empty_database_produces_zeroed_safe_metrics(self) -> None:
        kpis = compute_dashboard_kpis([], reference_date=date(2026, 11, 25))
        self.assertEqual(kpis["total_books_read"], 0)
        self.assertEqual(kpis["total_pages_read"], 0)
        self.assertEqual(kpis["average_pages"], 0.0)
        insights = compute_reading_insights([], reference_date=date(2026, 11, 25))
        self.assertFalse(insights["has_data"])

    def test_kpis_and_monthly_calculations(self) -> None:
        kpis = compute_dashboard_kpis(self.books, reference_date=date(2026, 11, 25))
        self.assertEqual(kpis["total_books_read"], 3)
        self.assertEqual(kpis["total_pages_read"], 1200)
        self.assertEqual(kpis["average_pages"], 400.0)
        self.assertEqual(kpis["books_this_month"], 1)
        self.assertEqual(kpis["pages_this_month"], 400)
        self.assertEqual(kpis["books_this_year"], 3)
        self.assertEqual(kpis["genres_explored"], 2)

        monthly = compute_monthly_series(self.books)
        self.assertEqual(len(monthly), 2)
        self.assertEqual(monthly[0]["month_key"], "2026-01")
        self.assertEqual(monthly[0]["books"], 2)
        self.assertEqual(monthly[0]["pages"], 800)

    def test_genre_and_yearly_aggregation(self) -> None:
        genres = compute_genre_distribution(self.books, completed_only=True)
        self.assertEqual(genres[0]["genre"], "Science")
        self.assertEqual(genres[0]["count"], 2)
        self.assertEqual(genres[0]["pages"], 800)
        self.assertAlmostEqual(genres[0]["percentage"], 66.7, places=1)

        yearly = compute_yearly_comparison(self.books)
        self.assertEqual(len(yearly), 1)
        self.assertEqual(yearly[0]["year"], 2026)
        self.assertEqual(yearly[0]["books"], 3)

    def test_threshold_warnings_detect_high_page_count(self) -> None:
        warnings = detect_threshold_warnings(
            self.books,
            settings=AppSettings(high_page_threshold=1200, monthly_book_target=2),
            reference_date=date(2026, 11, 25),
        )
        codes = {w.code for w in warnings}
        self.assertIn("HIGH_PAGE_COUNT", codes)
        self.assertIn("MONTHLY_BOOK_TARGET", codes)


if __name__ == "__main__":
    unittest.main()
