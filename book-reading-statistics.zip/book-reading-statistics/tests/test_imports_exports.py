"""Tests for CSV bulk import (including malformed rows) and multi-format exports."""

from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from modules.book_manager import BookManager
from modules.exports import (
    export_books_to_csv,
    export_books_to_json,
    export_markdown_report,
    export_plain_text_audit,
)
from modules.imports import import_csv_content
from modules.models import AppSettings


class TestImportsAndExports(unittest.TestCase):
    def test_csv_import_handles_valid_duplicate_and_malformed_rows(self) -> None:
        csv_text = (
            "title,author,genre,pages,status,start_date,completion_date,rating,notes\n"
            "Valid Book,Jane Doe,Science,310,Completed,2026-01-01,2026-01-20,4.5,Great read\n"
            "Valid Book,Jane Doe,Science,310,Completed,2026-01-01,2026-01-20,4.5,Duplicate\n"
            ",Missing Title,Fiction,200,Planned,2026-02-01,,,\n"
            "Bad Pages,John Doe,Fiction,-20,Planned,2026-02-01,,,\n"
            "Bad Date,John Doe,Fiction,200,Completed,2026-05-10,2026-05-01,4.0,\n"
        )
        with tempfile.TemporaryDirectory() as tmp:
            manager = BookManager(books_path=Path(tmp) / "books.json", settings=AppSettings())
            header_ok, header_err, summary = import_csv_content(csv_text, manager, skip_duplicates=True)

            self.assertTrue(header_ok, header_err)
            self.assertEqual(summary.total_rows, 5)
            self.assertEqual(summary.imported_count, 1)
            self.assertEqual(summary.duplicate_count, 1)
            self.assertEqual(summary.failed_count, 3)
            self.assertEqual(len(manager.books), 1)

    def test_exports_reflect_live_records(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            manager = BookManager(books_path=Path(tmp) / "books.json", settings=AppSettings())
            manager.add_book(
                {
                    "title": "Piranesi",
                    "author": "Susanna Clarke",
                    "genre": "Fiction",
                    "pages": 245,
                    "status": "Completed",
                    "start_date": "2026-09-01",
                    "completion_date": "2026-09-10",
                    "rating": 4.9,
                }
            )
            csv_out = export_books_to_csv(manager.books)
            self.assertIn("Piranesi", csv_out)

            json_out = json.loads(export_books_to_json(manager.books))
            self.assertEqual(json_out["record_count"], 1)

            md_out = export_markdown_report(manager.books)
            self.assertIn("| Piranesi | Susanna Clarke |", md_out)

            txt_out = export_plain_text_audit(manager.books)
            self.assertIn("BOOK READING STATISTICS AUDIT REPORT", txt_out)
            self.assertIn("Piranesi", txt_out)


if __name__ == "__main__":
    unittest.main()
