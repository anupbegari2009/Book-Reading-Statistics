"""Tests for BookManager CRUD, filtering, sorting, and pagination."""

from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from modules.book_manager import BookManager, FilterCriteria, paginate_books
from modules.models import AppSettings


class TestBookManager(unittest.TestCase):
    def test_add_edit_delete_and_persist(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "books.json"
            manager = BookManager(books_path=db_path, settings=AppSettings())

            ok, errs, created = manager.add_book(
                {
                    "title": "Range",
                    "author": "David Epstein",
                    "genre": "Non-Fiction",
                    "pages": 339,
                    "status": "Completed",
                    "start_date": "2026-07-01",
                    "completion_date": "2026-07-15",
                    "rating": 4.5,
                }
            )
            self.assertTrue(ok, errs)
            assert created is not None

            # Update record
            ok_u, errs_u, updated = manager.update_book(created.id, {"pages": 350, "rating": 4.9})
            self.assertTrue(ok_u, errs_u)
            assert updated is not None
            self.assertEqual(updated.pages, 350)

            # Reload from disk to verify persistence across restarts
            restarted = BookManager(books_path=db_path, settings=AppSettings())
            self.assertEqual(len(restarted.books), 1)
            self.assertEqual(restarted.books[0].pages, 350)

            # Delete record
            ok_d, _ = restarted.delete_book(created.id)
            self.assertTrue(ok_d)
            self.assertEqual(len(restarted.books), 0)

    def test_filter_and_pagination(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "books.json"
            manager = BookManager(books_path=db_path, settings=AppSettings())
            for i in range(15):
                manager.add_book(
                    {
                        "title": f"Book {i:02d}",
                        "author": "Author X" if i % 2 == 0 else "Author Y",
                        "genre": "Technology" if i < 5 else "Fiction",
                        "pages": 100 + i * 20,
                        "status": "Completed",
                        "start_date": "2026-01-01",
                        "completion_date": f"2026-02-{i + 1:02d}",
                        "rating": 4.0,
                    }
                )

            tech_books = manager.filter_books(FilterCriteria(genre="Technology", min_pages=120))
            self.assertEqual(len(tech_books), 4)

            page2 = paginate_books(manager.books, page=2, page_size=10)
            self.assertEqual(page2.total_pages, 2)
            self.assertEqual(len(page2.items), 5)


if __name__ == "__main__":
    unittest.main()
