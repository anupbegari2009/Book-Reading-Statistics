"""Tests for book input validation, date checking, and duplicate detection."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from modules.models import AppSettings, BookRecord
from modules.validation import validate_book_payload


class TestValidation(unittest.TestCase):
    def setUp(self) -> None:
        self.existing = [
            BookRecord(
                id="bk-1",
                title="Dune",
                author="Frank Herbert",
                genre="Fantasy",
                pages=688,
                status="Completed",
                start_date="2026-01-01",
                completion_date="2026-01-20",
                rating=4.8,
            )
        ]
        self.settings = AppSettings()

    def test_valid_completed_book(self) -> None:
        ok, errors, cleaned = validate_book_payload(
            {
                "title": "Clean Code",
                "author": "Robert C. Martin",
                "genre": "Technology",
                "pages": 464,
                "status": "Completed",
                "start_date": "2026-02-01",
                "completion_date": "2026-02-15",
                "rating": 4.5,
            },
            existing_books=self.existing,
            settings=self.settings,
        )
        self.assertTrue(ok)
        self.assertEqual(errors, [])
        self.assertIsNotNone(cleaned)
        assert cleaned is not None
        self.assertEqual(cleaned["pages"], 464)

    def test_reject_blank_title_and_author(self) -> None:
        ok, errors, _ = validate_book_payload(
            {
                "title": "   ",
                "author": "",
                "genre": "Fiction",
                "pages": 200,
                "status": "Planned",
                "start_date": "2026-03-01",
            },
            settings=self.settings,
        )
        self.assertFalse(ok)
        self.assertTrue(any("title" in e.lower() for e in errors))
        self.assertTrue(any("author" in e.lower() for e in errors))

    def test_reject_negative_and_non_numeric_pages(self) -> None:
        for bad_pages in (-50, 0, "abc", 12.5):
            ok, errors, _ = validate_book_payload(
                {
                    "title": "Test Book",
                    "author": "Test Author",
                    "genre": "Science",
                    "pages": bad_pages,
                    "status": "Planned",
                    "start_date": "2026-03-01",
                },
                settings=self.settings,
            )
            self.assertFalse(ok, f"Expected failure for pages={bad_pages!r}")
            self.assertTrue(any("page" in e.lower() for e in errors))

    def test_reject_invalid_dates_and_completion_before_start(self) -> None:
        ok_fmt, errs_fmt, _ = validate_book_payload(
            {
                "title": "Date Check",
                "author": "Author",
                "genre": "History",
                "pages": 150,
                "status": "Completed",
                "start_date": "2026-99-99",
                "completion_date": "2026-05-01",
            }
        )
        self.assertFalse(ok_fmt)
        self.assertTrue(any("start date" in e.lower() for e in errs_fmt))

        ok_order, errs_order, _ = validate_book_payload(
            {
                "title": "Date Order",
                "author": "Author",
                "genre": "History",
                "pages": 150,
                "status": "Completed",
                "start_date": "2026-05-10",
                "completion_date": "2026-05-01",
            }
        )
        self.assertFalse(ok_order)
        self.assertTrue(any("precede" in e.lower() for e in errs_order))

    def test_reject_out_of_range_rating(self) -> None:
        ok, errors, _ = validate_book_payload(
            {
                "title": "Rated Book",
                "author": "Author",
                "genre": "Fiction",
                "pages": 250,
                "status": "Currently Reading",
                "start_date": "2026-05-01",
                "rating": 6.5,
            },
            settings=self.settings,
        )
        self.assertFalse(ok)
        self.assertTrue(any("rating" in e.lower() for e in errors))

    def test_detect_duplicate_case_insensitive(self) -> None:
        ok, errors, _ = validate_book_payload(
            {
                "title": "  dune ",
                "author": "FRANK HERBERT",
                "genre": "Fantasy",
                "pages": 688,
                "status": "Completed",
                "start_date": "2026-05-01",
                "completion_date": "2026-05-20",
            },
            existing_books=self.existing,
            settings=self.settings,
        )
        self.assertFalse(ok)
        self.assertTrue(any("duplicate" in e.lower() for e in errors))


if __name__ == "__main__":
    unittest.main()
