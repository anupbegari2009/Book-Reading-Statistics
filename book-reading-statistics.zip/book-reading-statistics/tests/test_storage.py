"""Tests for JSON persistence, missing file creation, and corrupted JSON recovery."""

from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from modules.models import BookRecord
from modules.storage import load_books, save_books


class TestStorage(unittest.TestCase):
    def test_missing_file_is_created_safely(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            books_path = Path(tmp) / "nested" / "books.json"
            result = load_books(books_path)
            self.assertEqual(result.books, [])
            self.assertTrue(books_path.exists())

    def test_save_and_reload_preserves_records(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            books_path = Path(tmp) / "books.json"
            sample = [
                BookRecord(
                    id="bk-test",
                    title="Deep Work",
                    author="Cal Newport",
                    genre="Self-Help",
                    pages=296,
                    status="Completed",
                    start_date="2026-03-01",
                    completion_date="2026-03-14",
                    rating=4.5,
                    notes="Focus strategies.",
                )
            ]
            save_books(sample, books_path)
            reloaded = load_books(books_path)
            self.assertEqual(len(reloaded.books), 1)
            self.assertEqual(reloaded.books[0].title, "Deep Work")
            self.assertEqual(reloaded.books[0].pages, 296)
            self.assertTrue((Path(tmp) / "books.csv").exists())

    def test_corrupted_json_backs_up_and_recovers(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            books_path = Path(tmp) / "books.json"
            books_path.write_text("{not valid json!!", encoding="utf-8")

            result = load_books(books_path)
            self.assertEqual(result.books, [])
            self.assertTrue(any("corrupted json" in w.lower() for w in result.warnings))

            backups = list(Path(tmp).glob("books.corrupted_*.json"))
            self.assertEqual(len(backups), 1)
            # Recovered file is now valid JSON
            self.assertEqual(json.loads(books_path.read_text(encoding="utf-8")), [])


if __name__ == "__main__":
    unittest.main()
