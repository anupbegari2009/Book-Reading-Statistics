"""Test package for Book Reading Statistics."""
