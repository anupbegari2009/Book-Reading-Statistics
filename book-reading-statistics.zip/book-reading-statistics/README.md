# Book Reading Statistics (Project #94 — DataSpark Challenge)

A modular Python & web analytics application for tracking books read, page velocity, genre distribution, reading trends, CSV bulk imports, and multi-format executive reports using persistent local JSON/CSV storage.

## Problem Statement

Manual reading logs in spreadsheets or notes frequently suffer from inconsistent dates, invalid page counts, duplicate entries, and lack of automated aggregation across months, years, and genres. **Book Reading Statistics** eliminates tracking errors with strict input validation, automated KPI & trend calculations, threshold warnings, and clean visualizations that work completely offline.

## Objectives & Features

- **Overview Dashboard**: Live KPIs (Total Books Read, Total Pages Read, Average Pages/Book, Genres Explored, This Month, This Year), monthly bar & line charts, genre donut chart, recent activity table, and automated reading insights.
- **Add a Book**: Validated record entry supporting 12 genres, 3 reading statuses (`Completed`, `Currently Reading`, `Planned`), date ordering enforcement, rating bounds, and duplicate detection.
- **My Library**: Searchable, filterable, sortable, paginated library table with detail inspection, inline editing, and deletion confirmation.
- **Reading Analytics**: Monthly books completed, monthly pages read, genre distribution, yearly comparison, and status breakdown.
- **Search & Filter**: Combined multi-criteria filtering by keyword, genre, status, completion date window, and page range.
- **Import Dataset**: Fault-tolerant CSV uploader with header validation, row-by-row error diagnostics, and duplicate skipping.
- **Export Reports**: Export filtered or complete datasets as CSV, JSON, Markdown executive summary, Plain Text audit report, and Matplotlib PNG charts.
- **Settings & Threshold Warnings**: Configurable monthly targets, high-page warning thresholds, demo dataset loader, and corrupted JSON recovery.

## Technology Stack

- **Frontend**: Streamlit (Python) + Live Full-Stack Web UI (React + TypeScript + Express)
- **Backend**: Python 3.11+ (`dataclasses`, `datetime`, `math`, `csv`, `json`, `pathlib`)
- **Visualizations**: Matplotlib & Plotly (with graceful missing-dependency fallbacks)
- **Storage**: Local JSON (`data/books.json`, `data/settings.json`) and CSV interchange (`data/books.csv`)
- **Testing**: `pytest` & Python `unittest`

## Project Structure

```text
book-reading-statistics/
├── app.py                     # Streamlit entry point
├── requirements.txt
├── README.md
├── .gitignore
├── assets/
│   └── styles.css
├── data/
│   ├── books.json             # Primary persistent database
│   ├── settings.json          # Persisted user targets & thresholds
│   ├── sample_books.json      # 40 realistic sample & boundary records
│   └── sample_books.csv       # Sample CSV import/interchange dataset
├── modules/
│   ├── __init__.py
│   ├── models.py              # Dataclasses & constants
│   ├── storage.py             # Atomic JSON/CSV persistence & corruption recovery
│   ├── validation.py          # Input, date, rating, & duplicate validation
│   ├── book_manager.py        # CRUD, filtering, sorting, pagination
│   ├── analytics.py           # KPIs, trends, insights, threshold warnings
│   ├── visualizations.py      # Matplotlib & Plotly builders + PNG export
│   ├── imports.py             # Bulk CSV importer with row-level error tracking
│   └── exports.py             # CSV, JSON, Markdown, Plain Text report generators
└── tests/
    ├── test_validation.py
    ├── test_storage.py
    ├── test_analytics.py
    ├── test_book_manager.py
    └── test_imports_exports.py
```

## Installation & Launch (Streamlit / Python)

```bash
cd book-reading-statistics
python -m venv .venv
```

Activate the virtual environment:

- **Windows**: `.venv\Scripts\activate`
- **macOS / Linux**: `source .venv/bin/activate`

Install dependencies and launch Streamlit:

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Running Automated Tests

Using `unittest` (no extra packages required):

```bash
python3 -m unittest discover -s tests -v
```

Using `pytest`:

```bash
pytest -v
```

## Data Storage Explanation

- `data/books.json` is the primary persistent store and is created automatically if missing.
- Existing valid records are **never** overwritten on startup.
- If `books.json` becomes corrupted or fails schema validation, the storage layer automatically preserves a timestamped backup (`books.corrupted_*.json`) and recovers cleanly without crashing.
- Every modification atomically updates `data/books.json` and mirrors `data/books.csv`.

## Live Demo Workflow

1. Launch the application and review the **Dashboard** KPIs, charts, and insights.
2. Open **Add a Book**, submit an invalid record (e.g., blank title or negative pages) to verify validation, then submit a valid book.
3. Navigate to **My Library** to locate, inspect, edit, or paginate through the newly saved record.
4. Open **Reading Analytics** to confirm updated monthly, yearly, and genre visualizations.
5. Use **Search & Filter** to combine genre, status, and page filters.
6. Visit **Export Reports** to download a CSV, Markdown summary, or chart PNG.
7. Restart the application and verify that the added book persists across restarts.
