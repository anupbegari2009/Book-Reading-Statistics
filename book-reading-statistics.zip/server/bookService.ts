import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import {
  AnalyticsPayload,
  AppSettings,
  BookRecord,
  DashboardKPIs,
  GENRES,
  GenreSlice,
  ImportRowError,
  ImportSummary,
  MonthlyPoint,
  READING_STATUSES,
  ReadingInsights,
  ReadingStatus,
  StatusSlice,
  WarningItem,
  YearlyPoint,
} from '../src/types';

const PROJECT_DATA_DIR = path.resolve(process.cwd(), 'book-reading-statistics', 'data');
export const BOOKS_JSON_PATH = path.join(PROJECT_DATA_DIR, 'books.json');
export const BOOKS_CSV_PATH = path.join(PROJECT_DATA_DIR, 'books.csv');
export const SETTINGS_JSON_PATH = path.join(PROJECT_DATA_DIR, 'settings.json');
export const SAMPLE_JSON_PATH = path.join(PROJECT_DATA_DIR, 'sample_books.json');
export const SAMPLE_CSV_PATH = path.join(PROJECT_DATA_DIR, 'sample_books.csv');

const DEFAULT_SETTINGS: AppSettings = {
  monthly_book_target: 2,
  monthly_page_target: 700,
  high_page_threshold: 1200,
  rating_min: 1.0,
  rating_max: 5.0,
  strict_duplicate_check: true,
  default_page_size: 12,
};

const CSV_COLUMNS = [
  'id',
  'title',
  'author',
  'genre',
  'pages',
  'status',
  'start_date',
  'completion_date',
  'rating',
  'notes',
  'is_sample',
] as const;

let lastStartupWarnings: string[] = [];

function ensureDir(filePath: string): void {
  fs.mkdirSync(path.dirname(filePath), {recursive: true});
}

function isValidIsoDate(value: unknown): value is string {
  if (typeof value !== 'string') return false;
  const trimmed = value.trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) return false;
  const [y, m, d] = trimmed.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return (
    dt.getUTCFullYear() === y &&
    dt.getUTCMonth() === m - 1 &&
    dt.getUTCDate() === d
  );
}

function normalizeKey(title: string, author: string): string {
  const t = title.trim().toLowerCase().replace(/\s+/g, ' ');
  const a = author.trim().toLowerCase().replace(/\s+/g, ' ');
  return `${t}:::${a}`;
}

export function loadSettings(): AppSettings {
  ensureDir(SETTINGS_JSON_PATH);
  if (!fs.existsSync(SETTINGS_JSON_PATH)) {
    saveSettings(DEFAULT_SETTINGS);
    return {...DEFAULT_SETTINGS};
  }
  try {
    const raw = JSON.parse(fs.readFileSync(SETTINGS_JSON_PATH, 'utf-8'));
    if (!raw || typeof raw !== 'object') return {...DEFAULT_SETTINGS};
    const rMin = Number(raw.rating_min ?? DEFAULT_SETTINGS.rating_min);
    const rMax = Number(raw.rating_max ?? DEFAULT_SETTINGS.rating_max);
    return {
      monthly_book_target: Math.max(1, Math.round(Number(raw.monthly_book_target) || DEFAULT_SETTINGS.monthly_book_target)),
      monthly_page_target: Math.max(50, Math.round(Number(raw.monthly_page_target) || DEFAULT_SETTINGS.monthly_page_target)),
      high_page_threshold: Math.max(100, Math.round(Number(raw.high_page_threshold) || DEFAULT_SETTINGS.high_page_threshold)),
      rating_min: Number.isFinite(rMin) && rMin < rMax ? rMin : DEFAULT_SETTINGS.rating_min,
      rating_max: Number.isFinite(rMax) && rMin < rMax ? rMax : DEFAULT_SETTINGS.rating_max,
      strict_duplicate_check: Boolean(raw.strict_duplicate_check ?? DEFAULT_SETTINGS.strict_duplicate_check),
      default_page_size: Math.max(5, Math.min(100, Math.round(Number(raw.default_page_size) || DEFAULT_SETTINGS.default_page_size))),
    };
  } catch {
    return {...DEFAULT_SETTINGS};
  }
}

export function saveSettings(settings: AppSettings): AppSettings {
  ensureDir(SETTINGS_JSON_PATH);
  const sanitized: AppSettings = {
    monthly_book_target: Math.max(1, Math.round(Number(settings.monthly_book_target) || 2)),
    monthly_page_target: Math.max(50, Math.round(Number(settings.monthly_page_target) || 700)),
    high_page_threshold: Math.max(100, Math.round(Number(settings.high_page_threshold) || 1200)),
    rating_min: Number(settings.rating_min) || 1.0,
    rating_max: Number(settings.rating_max) || 5.0,
    strict_duplicate_check: Boolean(settings.strict_duplicate_check),
    default_page_size: Math.max(5, Math.min(100, Math.round(Number(settings.default_page_size) || 12))),
  };
  if (sanitized.rating_min >= sanitized.rating_max) {
    sanitized.rating_min = 1.0;
    sanitized.rating_max = 5.0;
  }
  fs.writeFileSync(SETTINGS_JSON_PATH, JSON.stringify(sanitized, null, 2), 'utf-8');
  return sanitized;
}

function backupCorruptedFile(filePath: string): string {
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const parsed = path.parse(filePath);
  const backupName = `${parsed.name}.corrupted_${stamp}${parsed.ext}`;
  const backupPath = path.join(parsed.dir, backupName);
  fs.copyFileSync(filePath, backupPath);
  return backupName;
}

export function loadBooks(): {books: BookRecord[]; warnings: string[]} {
  ensureDir(BOOKS_JSON_PATH);
  const warnings: string[] = [];

  if (!fs.existsSync(BOOKS_JSON_PATH)) {
    saveBooks([]);
    lastStartupWarnings = [];
    return {books: [], warnings};
  }

  let rawText = '';
  try {
    rawText = fs.readFileSync(BOOKS_JSON_PATH, 'utf-8');
  } catch (err) {
    warnings.push(`Unable to read books.json (${String(err)}).`);
    lastStartupWarnings = warnings;
    return {books: [], warnings};
  }

  if (!rawText.trim()) {
    warnings.push('Storage file was empty; initialized an empty book list.');
    saveBooks([]);
    lastStartupWarnings = warnings;
    return {books: [], warnings};
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(rawText);
  } catch (err) {
    const backupName = backupCorruptedFile(BOOKS_JSON_PATH);
    warnings.push(
      `Corrupted JSON detected (${err instanceof Error ? err.message : 'parse error'}). Backed up damaged file to '${backupName}' and recovered cleanly.`,
    );
    saveBooks([]);
    lastStartupWarnings = warnings;
    return {books: [], warnings};
  }

  if (!Array.isArray(parsed)) {
    const backupName = backupCorruptedFile(BOOKS_JSON_PATH);
    warnings.push(
      `Invalid storage schema (expected a JSON array). Backed up file to '${backupName}' and recovered cleanly.`,
    );
    saveBooks([]);
    lastStartupWarnings = warnings;
    return {books: [], warnings};
  }

  const books: BookRecord[] = [];
  parsed.forEach((item, idx) => {
    if (!item || typeof item !== 'object') {
      warnings.push(`Skipped malformed entry #${idx + 1}.`);
      return;
    }
    const rec = item as Record<string, unknown>;
    const title = String(rec.title ?? '').trim();
    const author = String(rec.author ?? '').trim();
    if (!title || !author) {
      warnings.push(`Skipped record #${idx + 1} missing title or author.`);
      return;
    }
    books.push({
      id: String(rec.id ?? `bk-${idx + 1}`).trim(),
      title,
      author,
      genre: String(rec.genre ?? 'Other').trim() || 'Other',
      pages: Math.max(1, Math.round(Number(rec.pages) || 1)),
      status: (READING_STATUSES.includes(rec.status as ReadingStatus)
        ? rec.status
        : 'Planned') as ReadingStatus,
      start_date: String(rec.start_date ?? '').trim(),
      completion_date:
        rec.completion_date && String(rec.completion_date).trim()
          ? String(rec.completion_date).trim()
          : null,
      rating:
        rec.rating === null || rec.rating === undefined || String(rec.rating).trim() === ''
          ? null
          : Math.round(Number(rec.rating) * 10) / 10,
      notes: String(rec.notes ?? '').trim(),
      is_sample: Boolean(rec.is_sample),
    });
  });

  lastStartupWarnings = warnings;
  return {books, warnings};
}

function csvEscape(val: unknown): string {
  const s = val === null || val === undefined ? '' : String(val);
  if (/[",\n\r]/.test(s)) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

export function exportBooksToCsv(books: BookRecord[]): string {
  const header = CSV_COLUMNS.join(',');
  const rows = books.map((b) =>
    [
      b.id,
      b.title,
      b.author,
      b.genre,
      b.pages,
      b.status,
      b.start_date,
      b.completion_date ?? '',
      b.rating ?? '',
      b.notes,
      b.is_sample ? 'true' : 'false',
    ]
      .map(csvEscape)
      .join(','),
  );
  return [header, ...rows].join('\n') + '\n';
}

export function saveBooks(books: BookRecord[]): void {
  ensureDir(BOOKS_JSON_PATH);
  const tmpPath = `${BOOKS_JSON_PATH}.tmp`;
  fs.writeFileSync(tmpPath, JSON.stringify(books, null, 2), 'utf-8');
  fs.renameSync(tmpPath, BOOKS_JSON_PATH);
  try {
    fs.writeFileSync(BOOKS_CSV_PATH, exportBooksToCsv(books), 'utf-8');
  } catch {
    // CSV mirror failure never breaks primary JSON persistence
  }
}

export function validateBookPayload(
  payload: Record<string, unknown>,
  existingBooks: BookRecord[],
  settings: AppSettings,
  options: {excludeId?: string; allowDuplicate?: boolean} = {},
): {ok: boolean; errors: string[]; cleaned?: Omit<BookRecord, 'id'> & {id?: string}} {
  const errors: string[] = [];

  const title = String(payload.title ?? '').trim();
  const author = String(payload.author ?? '').trim();
  let genre = String(payload.genre ?? '').trim();
  let status = String(payload.status ?? '').trim();
  const notes = String(payload.notes ?? '').trim();
  const is_sample = Boolean(payload.is_sample);

  if (!title) errors.push('Book title cannot be blank.');
  if (!author) errors.push('Author name cannot be blank.');

  if (!genre) {
    errors.push('Genre is required.');
  } else {
    const matched = GENRES.find((g) => g.toLowerCase() === genre.toLowerCase());
    if (matched) genre = matched;
    else errors.push(`Unsupported genre '${genre}'.`);
  }

  if (!status) {
    errors.push('Reading status is required.');
  } else {
    const matched = READING_STATUSES.find((s) => s.toLowerCase() === status.toLowerCase());
    if (matched) status = matched;
    else errors.push(`Invalid reading status '${status}'.`);
  }

  let pages = 0;
  const rawPages = payload.pages;
  if (rawPages === undefined || rawPages === null || String(rawPages).trim() === '') {
    errors.push('Page count is required and must be a positive integer.');
  } else if (typeof rawPages === 'boolean') {
    errors.push('Page count must be a valid positive integer.');
  } else {
    const num = Number(String(rawPages).trim());
    if (!Number.isFinite(num) || !Number.isInteger(num) || num <= 0) {
      errors.push('Page count must be a positive whole integer greater than zero.');
    } else {
      pages = num;
    }
  }

  const startDate = String(payload.start_date ?? '').trim();
  if (!startDate) {
    errors.push('Start date is required (YYYY-MM-DD).');
  } else if (!isValidIsoDate(startDate)) {
    errors.push(`Invalid start date '${startDate}'. Expected YYYY-MM-DD.`);
  }

  const rawCompletion = String(payload.completion_date ?? '').trim();
  let completionDate: string | null = null;
  if (rawCompletion) {
    if (!isValidIsoDate(rawCompletion)) {
      errors.push(`Invalid completion date '${rawCompletion}'. Expected YYYY-MM-DD.`);
    } else {
      completionDate = rawCompletion;
    }
  } else if (status === 'Completed') {
    errors.push("Completion date is required when reading status is 'Completed'.");
  }

  if (isValidIsoDate(startDate) && completionDate && completionDate < startDate) {
    errors.push('Completion date cannot precede the start date.');
  }

  let rating: number | null = null;
  const rawRating = payload.rating;
  if (rawRating !== undefined && rawRating !== null && String(rawRating).trim() !== '') {
    if (typeof rawRating === 'boolean') {
      errors.push('Rating must be a numeric value.');
    } else {
      const r = Number(String(rawRating).trim());
      if (!Number.isFinite(r)) {
        errors.push('Rating must be a numeric value.');
      } else if (r < settings.rating_min || r > settings.rating_max) {
        errors.push(`Rating must be between ${settings.rating_min} and ${settings.rating_max}.`);
      } else {
        rating = Math.round(r * 10) / 10;
      }
    }
  }

  if (!options.allowDuplicate && title && author) {
    const target = normalizeKey(title, author);
    const dup = existingBooks.find(
      (b) => b.id !== options.excludeId && normalizeKey(b.title, b.author) === target,
    );
    if (dup && settings.strict_duplicate_check) {
      errors.push(
        `Duplicate record detected: '${dup.title}' by ${dup.author} already exists in your library.`,
      );
    }
  }

  if (errors.length > 0) {
    return {ok: false, errors};
  }

  return {
    ok: true,
    errors: [],
    cleaned: {
      id: payload.id ? String(payload.id).trim() : undefined,
      title,
      author,
      genre,
      pages,
      status: status as ReadingStatus,
      start_date: startDate,
      completion_date: completionDate,
      rating,
      notes,
      is_sample,
    },
  };
}

export function addBookRecord(
  payload: Record<string, unknown>,
  allowDuplicate = false,
): {ok: boolean; errors: string[]; book?: BookRecord} {
  const {books} = loadBooks();
  const settings = loadSettings();
  const check = validateBookPayload(payload, books, settings, {allowDuplicate});
  if (!check.ok || !check.cleaned) {
    return {ok: false, errors: check.errors};
  }
  let id = check.cleaned.id || `bk-${crypto.randomBytes(4).toString('hex')}`;
  while (books.some((b) => b.id === id)) {
    id = `bk-${crypto.randomBytes(4).toString('hex')}`;
  }
  const created: BookRecord = {...check.cleaned, id};
  books.push(created);
  saveBooks(books);
  return {ok: true, errors: [], book: created};
}

export function updateBookRecord(
  id: string,
  payload: Record<string, unknown>,
  allowDuplicate = false,
): {ok: boolean; errors: string[]; book?: BookRecord} {
  const {books} = loadBooks();
  const settings = loadSettings();
  const idx = books.findIndex((b) => b.id === id);
  if (idx === -1) {
    return {ok: false, errors: [`Book '${id}' not found.`]};
  }
  const merged = {...books[idx], ...payload, id};
  const check = validateBookPayload(merged, books, settings, {excludeId: id, allowDuplicate});
  if (!check.ok || !check.cleaned) {
    return {ok: false, errors: check.errors};
  }
  const updated: BookRecord = {...check.cleaned, id};
  books[idx] = updated;
  saveBooks(books);
  return {ok: true, errors: [], book: updated};
}

export function deleteBookRecord(id: string): {ok: boolean; message: string} {
  const {books} = loadBooks();
  const next = books.filter((b) => b.id !== id);
  if (next.length === books.length) {
    return {ok: false, message: `Book '${id}' was not found.`};
  }
  saveBooks(next);
  return {ok: true, message: 'Book record deleted.'};
}

export function clearAllBooks(): void {
  saveBooks([]);
}

export function loadSampleBooksIntoDb(replace = false): {added: number; skipped: number} {
  if (!fs.existsSync(SAMPLE_JSON_PATH)) {
    return {added: 0, skipped: 0};
  }
  const samples = JSON.parse(fs.readFileSync(SAMPLE_JSON_PATH, 'utf-8')) as BookRecord[];
  if (replace) {
    const tagged = samples.map((s) => ({...s, is_sample: true}));
    saveBooks(tagged);
    return {added: tagged.length, skipped: 0};
  }
  const {books} = loadBooks();
  const existingKeys = new Set(books.map((b) => normalizeKey(b.title, b.author)));
  let added = 0;
  let skipped = 0;
  for (const s of samples) {
    const key = normalizeKey(s.title, s.author);
    if (existingKeys.has(key)) {
      skipped++;
      continue;
    }
    books.push({...s, is_sample: true});
    existingKeys.add(key);
    added++;
  }
  if (added > 0) saveBooks(books);
  return {added, skipped};
}

// Robust RFC4180-compatible CSV parser
function parseCsvRows(csvText: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let inQuotes = false;
  const text = csvText.replace(/^\uFEFF/, '');

  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (inQuotes) {
      if (ch === '"') {
        if (text[i + 1] === '"') {
          cell += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        cell += ch;
      }
    } else {
      if (ch === '"') {
        inQuotes = true;
      } else if (ch === ',') {
        row.push(cell);
        cell = '';
      } else if (ch === '\r') {
        if (text[i + 1] === '\n') i++;
        row.push(cell);
        rows.push(row);
        row = [];
        cell = '';
      } else if (ch === '\n') {
        row.push(cell);
        rows.push(row);
        row = [];
        cell = '';
      } else {
        cell += ch;
      }
    }
  }
  if (cell.length > 0 || row.length > 0) {
    row.push(cell);
    rows.push(row);
  }
  return rows.filter((r) => r.some((c) => c.trim() !== ''));
}

const HEADER_ALIASES: Record<string, string> = {
  book_title: 'title',
  'book title': 'title',
  title: 'title',
  author_name: 'author',
  'author name': 'author',
  author: 'author',
  category: 'genre',
  genre: 'genre',
  total_pages: 'pages',
  'total pages': 'pages',
  page_count: 'pages',
  pages: 'pages',
  reading_status: 'status',
  'reading status': 'status',
  status: 'status',
  start_date: 'start_date',
  'start date': 'start_date',
  completion_date: 'completion_date',
  'completion date': 'completion_date',
  end_date: 'completion_date',
  rating: 'rating',
  personal_rating: 'rating',
  notes: 'notes',
  id: 'id',
  is_sample: 'is_sample',
};

const REQUIRED_CSV_COLUMNS = ['title', 'author', 'genre', 'pages', 'status', 'start_date'];

export function importCsvText(
  csvText: string,
  skipDuplicates = true,
): {headerOk: boolean; headerError?: string; summary: ImportSummary} {
  if (!csvText || !csvText.trim()) {
    return {
      headerOk: false,
      headerError: 'Uploaded CSV file is empty.',
      summary: {total_rows: 0, imported_count: 0, duplicate_count: 0, failed_count: 0, errors: []},
    };
  }

  const parsed = parseCsvRows(csvText);
  if (parsed.length === 0) {
    return {
      headerOk: false,
      headerError: 'CSV file contains no header row.',
      summary: {total_rows: 0, imported_count: 0, duplicate_count: 0, failed_count: 0, errors: []},
    };
  }

  const rawHeaders = parsed[0].map((h) => h.trim());
  const canonicalHeaders = rawHeaders.map(
    (h) => HEADER_ALIASES[h.toLowerCase()] ?? h.toLowerCase().replace(/\s+/g, '_'),
  );
  const missing = REQUIRED_CSV_COLUMNS.filter((col) => !canonicalHeaders.includes(col));
  if (missing.length > 0) {
    return {
      headerOk: false,
      headerError: `Missing required CSV column(s): ${missing.join(', ')}.`,
      summary: {total_rows: 0, imported_count: 0, duplicate_count: 0, failed_count: 0, errors: []},
    };
  }

  const {books} = loadBooks();
  const settings = loadSettings();
  const errors: ImportRowError[] = [];
  let importedCount = 0;
  let duplicateCount = 0;
  let failedCount = 0;

  for (let i = 1; i < parsed.length; i++) {
    const rowCells = parsed[i];
    const rowObj: Record<string, unknown> = {};
    canonicalHeaders.forEach((key, colIdx) => {
      rowObj[key] = (rowCells[colIdx] ?? '').trim();
    });
    if ('is_sample' in rowObj) {
      rowObj.is_sample = ['true', '1', 'yes'].includes(String(rowObj.is_sample).toLowerCase());
    }

    const rowTitle = String(rowObj.title || '').trim() || '(Untitled Row)';
    const rowAuthor = String(rowObj.author || '').trim();

    if (rowTitle !== '(Untitled Row)' && rowAuthor && skipDuplicates) {
      const target = normalizeKey(rowTitle, rowAuthor);
      const dup = books.find((b) => normalizeKey(b.title, b.author) === target);
      if (dup) {
        duplicateCount++;
        errors.push({
          row_number: i + 1,
          title: rowTitle,
          reason: `Duplicate skipped: '${dup.title}' by ${dup.author} already exists.`,
        });
        continue;
      }
    }

    const check = validateBookPayload(rowObj, books, settings, {allowDuplicate: !skipDuplicates});
    if (!check.ok || !check.cleaned) {
      failedCount++;
      errors.push({
        row_number: i + 1,
        title: rowTitle,
        reason: check.errors.join('; '),
      });
      continue;
    }

    let id = check.cleaned.id || `bk-${crypto.randomBytes(4).toString('hex')}`;
    while (books.some((b) => b.id === id)) {
      id = `bk-${crypto.randomBytes(4).toString('hex')}`;
    }
    books.push({...check.cleaned, id});
    importedCount++;
  }

  if (importedCount > 0) {
    saveBooks(books);
  }

  return {
    headerOk: true,
    summary: {
      total_rows: parsed.length - 1,
      imported_count: importedCount,
      duplicate_count: duplicateCount,
      failed_count: failedCount,
      errors,
    },
  };
}

export function computeAnalytics(books: BookRecord[], settings: AppSettings): AnalyticsPayload {
  const now = new Date();
  const refYear = now.getFullYear();
  const refMonth = now.getMonth() + 1;
  const refMonthLabel = now.toLocaleDateString('en-US', {month: 'long', year: 'numeric'});

  const completed = books.filter((b) => b.status === 'Completed');
  const currentlyReading = books.filter((b) => b.status === 'Currently Reading');
  const planned = books.filter((b) => b.status === 'Planned');

  const totalBooksRead = completed.length;
  const totalPagesRead = completed.reduce((acc, b) => acc + b.pages, 0);
  const averagePages = totalBooksRead > 0 ? Math.round((totalPagesRead / totalBooksRead) * 10) / 10 : 0;

  const rated = completed.filter((b) => b.rating !== null).map((b) => b.rating as number);
  const averageRating =
    rated.length > 0 ? Math.round((rated.reduce((a, b) => a + b, 0) / rated.length) * 100) / 100 : null;

  const genresExplored = new Set((completed.length > 0 ? completed : books).map((b) => b.genre)).size;

  let booksThisMonth = 0;
  let pagesThisMonth = 0;
  let booksThisYear = 0;
  let pagesThisYear = 0;

  const monthBuckets = new Map<string, {books: number; pages: number}>();
  const yearBuckets = new Map<number, {books: number; pages: number}>();

  for (const b of completed) {
    if (!b.completion_date || !isValidIsoDate(b.completion_date)) continue;
    const [yr, mo] = b.completion_date.split('-').map(Number);
    if (yr === refYear) {
      booksThisYear++;
      pagesThisYear += b.pages;
      if (mo === refMonth) {
        booksThisMonth++;
        pagesThisMonth += b.pages;
      }
    }
    const ym = `${yr}-${String(mo).padStart(2, '0')}`;
    const mEntry = monthBuckets.get(ym) ?? {books: 0, pages: 0};
    mEntry.books += 1;
    mEntry.pages += b.pages;
    monthBuckets.set(ym, mEntry);

    const yEntry = yearBuckets.get(yr) ?? {books: 0, pages: 0};
    yEntry.books += 1;
    yEntry.pages += b.pages;
    yearBuckets.set(yr, yEntry);
  }

  const kpis: DashboardKPIs = {
    total_stored: books.length,
    total_books_read: totalBooksRead,
    currently_reading_count: currentlyReading.length,
    planned_count: planned.length,
    total_pages_read: totalPagesRead,
    average_pages: averagePages,
    average_rating: averageRating,
    genres_explored: genresExplored,
    books_this_month: booksThisMonth,
    pages_this_month: pagesThisMonth,
    books_this_year: booksThisYear,
    pages_this_year: pagesThisYear,
    reference_year: refYear,
    reference_month_label: refMonthLabel,
  };

  const monthly: MonthlyPoint[] = Array.from(monthBuckets.keys())
    .sort()
    .map((ym) => {
      const [y, m] = ym.split('-').map(Number);
      const dt = new Date(Date.UTC(y, m - 1, 1));
      const label = dt.toLocaleDateString('en-US', {month: 'short', year: 'numeric', timeZone: 'UTC'});
      const val = monthBuckets.get(ym)!;
      return {month_key: ym, label, books: val.books, pages: val.pages};
    });

  const yearly: YearlyPoint[] = Array.from(yearBuckets.keys())
    .sort((a, b) => a - b)
    .map((yr) => {
      const val = yearBuckets.get(yr)!;
      return {
        year: yr,
        books: val.books,
        pages: val.pages,
        avg_pages: val.books > 0 ? Math.round((val.pages / val.books) * 10) / 10 : 0,
      };
    });

  const genreCounts = new Map<string, {count: number; pages: number}>();
  for (const b of completed) {
    const entry = genreCounts.get(b.genre) ?? {count: 0, pages: 0};
    entry.count += 1;
    entry.pages += b.pages;
    genreCounts.set(b.genre, entry);
  }
  const genres: GenreSlice[] = Array.from(genreCounts.entries())
    .sort((a, b) => b[1].count - a[1].count || b[1].pages - a[1].pages)
    .map(([genre, val]) => ({
      genre,
      count: val.count,
      pages: val.pages,
      percentage: totalBooksRead > 0 ? Math.round((val.count / totalBooksRead) * 1000) / 10 : 0,
    }));

  const statuses: StatusSlice[] =
    books.length === 0
      ? []
      : READING_STATUSES.map((status) => {
          const count = books.filter((b) => b.status === status).length;
          return {
            status,
            count,
            percentage: Math.round((count / books.length) * 1000) / 10,
          };
        });

  let insights: ReadingInsights;
  if (totalBooksRead === 0) {
    insights = {
      has_data: false,
      most_read_genre: null,
      most_productive_month: null,
      highest_reading_month_pages: null,
      avg_books_per_active_month: 0,
      avg_pages_per_active_month: 0,
      page_std_dev: 0,
      longest_book: null,
      observations: [
        'No completed books recorded yet. Add a completed book or load the sample dataset to generate reading insights.',
      ],
    };
  } else {
    const mostReadGenre = genres[0] ?? null;
    const mostProductive =
      monthly.length > 0
        ? monthly.reduce((best, cur) =>
            cur.books > best.books || (cur.books === best.books && cur.pages > best.pages) ? cur : best,
          )
        : null;
    const highestPagesMonth =
      monthly.length > 0
        ? monthly.reduce((best, cur) => (cur.pages > best.pages ? cur : best))
        : null;
    const activeMonths = monthly.length;
    const avgBooksPerActiveMonth =
      activeMonths > 0 ? Math.round((totalBooksRead / activeMonths) * 100) / 100 : 0;
    const avgPagesPerActiveMonth =
      activeMonths > 0 ? Math.round((totalPagesRead / activeMonths) * 10) / 10 : 0;

    const meanP = totalPagesRead / totalBooksRead;
    const variance =
      completed.reduce((sum, b) => sum + (b.pages - meanP) ** 2, 0) / totalBooksRead;
    const pageStdDev = Math.round(Math.sqrt(variance) * 10) / 10;
    const longestBook = completed.reduce((max, cur) => (cur.pages > max.pages ? cur : max));

    const observations: string[] = [];
    if (mostReadGenre) {
      observations.push(
        `Most-read genre is ${mostReadGenre.genre} with ${mostReadGenre.count} completed books (${mostReadGenre.percentage}% of completions, ${mostReadGenre.pages.toLocaleString()} pages).`,
      );
    }
    if (mostProductive) {
      observations.push(
        `Most productive month was ${mostProductive.label} with ${mostProductive.books} books and ${mostProductive.pages.toLocaleString()} pages completed.`,
      );
    }
    observations.push(
      `You have completed ${booksThisYear} books (${pagesThisYear.toLocaleString()} pages) in ${refYear} and average ${avgBooksPerActiveMonth} books per active reading month.`,
    );
    observations.push(
      `Longest completed work is '${longestBook.title}' by ${longestBook.author} at ${longestBook.pages.toLocaleString()} pages (spread SD: ${pageStdDev} pages).`,
    );

    insights = {
      has_data: true,
      most_read_genre: mostReadGenre,
      most_productive_month: mostProductive,
      highest_reading_month_pages: highestPagesMonth,
      avg_books_per_active_month: avgBooksPerActiveMonth,
      avg_pages_per_active_month: avgPagesPerActiveMonth,
      page_std_dev: pageStdDev,
      longest_book: longestBook,
      observations,
    };
  }

  // Automated Threshold Warnings
  const warnings: WarningItem[] = [];
  const seen = new Set<string>();
  for (const book of books) {
    if (book.pages > settings.high_page_threshold) {
      warnings.push({
        severity: 'warning',
        code: 'HIGH_PAGE_COUNT',
        message: `'${book.title}' has ${book.pages.toLocaleString()} pages (above ${settings.high_page_threshold.toLocaleString()}-page threshold).`,
        book_id: book.id,
        book_title: book.title,
      });
    }
    if (!isValidIsoDate(book.start_date)) {
      warnings.push({
        severity: 'error',
        code: 'INVALID_START_DATE',
        message: `'${book.title}' has an invalid start date '${book.start_date}'.`,
        book_id: book.id,
        book_title: book.title,
      });
    }
    if (book.completion_date && !isValidIsoDate(book.completion_date)) {
      warnings.push({
        severity: 'error',
        code: 'INVALID_COMPLETION_DATE',
        message: `'${book.title}' has an invalid completion date '${book.completion_date}'.`,
        book_id: book.id,
        book_title: book.title,
      });
    }
    if (
      isValidIsoDate(book.start_date) &&
      book.completion_date &&
      isValidIsoDate(book.completion_date) &&
      book.completion_date < book.start_date
    ) {
      warnings.push({
        severity: 'error',
        code: 'DATE_ORDER_CONFLICT',
        message: `'${book.title}' completion date precedes start date.`,
        book_id: book.id,
        book_title: book.title,
      });
    }
    if (book.status === 'Completed') {
      if (!book.completion_date) {
        warnings.push({
          severity: 'warning',
          code: 'MISSING_COMPLETION_DATE',
          message: `Completed book '${book.title}' is missing a completion date.`,
          book_id: book.id,
          book_title: book.title,
        });
      }
      if (book.rating === null) {
        warnings.push({
          severity: 'info',
          code: 'MISSING_RATING',
          message: `Completed book '${book.title}' has no personal rating recorded.`,
          book_id: book.id,
          book_title: book.title,
        });
      }
    }
    const key = normalizeKey(book.title, book.author);
    if (seen.has(key)) {
      warnings.push({
        severity: 'warning',
        code: 'DUPLICATE_BOOK',
        message: `Possible duplicate entry for '${book.title}' by ${book.author}.`,
        book_id: book.id,
        book_title: book.title,
      });
    } else {
      seen.add(key);
    }
  }

  if (books.length > 0 && booksThisMonth < settings.monthly_book_target) {
    warnings.push({
      severity: 'info',
      code: 'MONTHLY_BOOK_TARGET',
      message: `${refMonthLabel} progress: ${booksThisMonth} of ${settings.monthly_book_target} target books completed (${settings.monthly_book_target - booksThisMonth} remaining).`,
    });
  }
  if (books.length > 0 && pagesThisMonth < settings.monthly_page_target) {
    warnings.push({
      severity: 'info',
      code: 'MONTHLY_PAGE_TARGET',
      message: `${refMonthLabel} page goal: ${pagesThisMonth.toLocaleString()} of ${settings.monthly_page_target.toLocaleString()} pages read (${(settings.monthly_page_target - pagesThisMonth).toLocaleString()} remaining).`,
    });
  }

  return {
    kpis,
    monthly,
    yearly,
    genres,
    statuses,
    insights,
    warnings,
    startup_warnings: lastStartupWarnings,
  };
}

export function generateMarkdownReport(books: BookRecord[], settings: AppSettings): string {
  const analytics = computeAnalytics(books, settings);
  const {kpis, insights, genres, yearly, monthly} = analytics;
  const now = new Date().toISOString().slice(0, 16).replace('T', ' ');

  const lines: string[] = [
    '# Book Reading Statistics — Executive Summary',
    '',
    `Generated: ${now}`,
    '',
    '## Key Performance Indicators',
    '',
    `- **Total Stored Books:** ${kpis.total_stored}`,
    `- **Total Completed Books:** ${kpis.total_books_read}`,
    `- **Currently Reading:** ${kpis.currently_reading_count}`,
    `- **Planned:** ${kpis.planned_count}`,
    `- **Total Pages Read (Completed):** ${kpis.total_pages_read.toLocaleString()}`,
    `- **Average Pages per Completed Book:** ${kpis.average_pages}`,
    `- **Genres Explored:** ${kpis.genres_explored}`,
    `- **This Month (${kpis.reference_month_label}):** ${kpis.books_this_month} books (${kpis.pages_this_month.toLocaleString()} pages)`,
    `- **This Year (${kpis.reference_year}):** ${kpis.books_this_year} books (${kpis.pages_this_year.toLocaleString()} pages)`,
    '',
    '## Reading Insights',
    '',
    ...insights.observations.map((o) => `- ${o}`),
    '',
    '## Genre Distribution (Completed Books)',
    '',
  ];

  if (genres.length > 0) {
    lines.push('| Genre | Books | Pages | Share |');
    lines.push('| --- | ---: | ---: | ---: |');
    genres.forEach((g) => {
      lines.push(`| ${g.genre} | ${g.count} | ${g.pages.toLocaleString()} | ${g.percentage}% |`);
    });
  } else {
    lines.push('_No completed books recorded yet._');
  }

  lines.push('', '## Yearly Comparison', '');
  if (yearly.length > 0) {
    lines.push('| Year | Completed Books | Total Pages | Avg Pages/Book |');
    lines.push('| ---: | ---: | ---: | ---: |');
    yearly.forEach((y) => {
      lines.push(`| ${y.year} | ${y.books} | ${y.pages.toLocaleString()} | ${y.avg_pages} |`);
    });
  } else {
    lines.push('_No yearly completion data available._');
  }

  lines.push('', '## Recent Monthly Activity (Last 12 Months)', '');
  if (monthly.length > 0) {
    lines.push('| Month | Books Completed | Pages Read |');
    lines.push('| --- | ---: | ---: |');
    monthly.slice(-12).forEach((m) => {
      lines.push(`| ${m.label} | ${m.books} | ${m.pages.toLocaleString()} |`);
    });
  } else {
    lines.push('_No monthly reading activity available._');
  }

  lines.push('', '## Library Records', '');
  if (books.length > 0) {
    lines.push('| Title | Author | Genre | Pages | Status | Completion Date | Rating |');
    lines.push('| --- | --- | --- | ---: | --- | --- | ---: |');
    books.forEach((b) => {
      lines.push(
        `| ${b.title} | ${b.author} | ${b.genre} | ${b.pages.toLocaleString()} | ${b.status} | ${b.completion_date ?? '-'} | ${b.rating !== null ? b.rating.toFixed(1) : '-'} |`,
      );
    });
  } else {
    lines.push('_The library is currently empty._');
  }

  return lines.join('\n') + '\n';
}

export function generatePlainTextAudit(books: BookRecord[], settings: AppSettings): string {
  const analytics = computeAnalytics(books, settings);
  const {kpis, insights, genres} = analytics;
  const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
  const div = '='.repeat(72);
  const sub = '-'.repeat(72);

  const lines: string[] = [
    div,
    'BOOK READING STATISTICS — AUDIT REPORT',
    `Generated: ${now}`,
    div,
    '',
    'SUMMARY METRICS',
    sub,
    `Total Stored Records      : ${kpis.total_stored}`,
    `Completed Books           : ${kpis.total_books_read}`,
    `Currently Reading         : ${kpis.currently_reading_count}`,
    `Planned                   : ${kpis.planned_count}`,
    `Total Pages Completed     : ${kpis.total_pages_read.toLocaleString()}`,
    `Average Pages / Book      : ${kpis.average_pages}`,
    `Average Rating            : ${kpis.average_rating !== null ? kpis.average_rating.toFixed(2) : 'N/A'}`,
    `Genres Explored           : ${kpis.genres_explored}`,
    `This Month                : ${kpis.books_this_month} books / ${kpis.pages_this_month.toLocaleString()} pages`,
    `This Year                 : ${kpis.books_this_year} books / ${kpis.pages_this_year.toLocaleString()} pages`,
    '',
    'ANALYTICAL OBSERVATIONS',
    sub,
    ...insights.observations.map((o, i) => `${i + 1}. ${o}`),
    '',
    'GENRE BREAKDOWN',
    sub,
  ];

  if (genres.length > 0) {
    genres.forEach((g) => {
      lines.push(
        `${g.genre.padEnd(16)} | ${String(g.count).padStart(3)} books | ${g.pages.toLocaleString().padStart(7)} pages | ${g.percentage.toFixed(1).padStart(5)}%`,
      );
    });
  } else {
    lines.push('No completed records available.');
  }

  lines.push('', 'RECORD LEDGER', sub);
  if (books.length > 0) {
    books.forEach((b, idx) => {
      const rating = b.rating !== null ? `${b.rating.toFixed(1)}/5` : 'Unrated';
      lines.push(
        `[${String(idx + 1).padStart(3, '0')}] ${b.title} — ${b.author} (${b.genre}) | ${b.pages}p | ${b.status} | Completed: ${b.completion_date ?? 'N/A'} | Rating: ${rating}`,
      );
    });
  } else {
    lines.push('No book records found.');
  }

  lines.push('', div, 'END OF AUDIT REPORT', div);
  return lines.join('\n') + '\n';
}
