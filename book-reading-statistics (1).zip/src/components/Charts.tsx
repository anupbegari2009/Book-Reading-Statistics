import React, {useRef, useState} from 'react';
import {Download} from 'lucide-react';
import {GenreSlice, MonthlyPoint, StatusSlice, YearlyPoint} from '../types';
import {downloadSvgAsPng} from '../utils/exportHelpers';

const CHART_COLORS = [
  '#6366F1', // Primary Indigo
  '#8B5CF6', // Secondary Violet
  '#10B981', // Success Emerald
  '#F59E0B', // Warning Amber
  '#3B82F6', // Blue
  '#EC4899', // Rose
  '#14B8A6', // Teal
  '#64748B', // Slate
  '#0EA5E9', // Sky
  '#F97316', // Orange
];

interface ChartCardProps {
  title: string;
  subtitle?: string;
  filename: string;
  svgRef: React.RefObject<SVGSVGElement | null>;
  hasData: boolean;
  emptyText: string;
  children: React.ReactNode;
}

function ChartCard({
  title,
  subtitle,
  filename,
  svgRef,
  hasData,
  emptyText,
  children,
}: ChartCardProps) {
  const [exporting, setExporting] = useState(false);

  const handleDownload = async () => {
    setExporting(true);
    await downloadSvgAsPng(svgRef.current, filename, title);
    setExporting(false);
  };

  return (
    <div className="bg-white border border-[#E5E7EB] rounded-xl p-5 shadow-[0_1px_2px_rgba(17,24,39,0.04)] flex flex-col">
      <div className="flex items-start justify-between gap-4 mb-4">
        <div>
          <h3 className="text-base font-semibold text-[#111827] tracking-tight">{title}</h3>
          {subtitle && <p className="text-xs text-[#64748B] mt-0.5">{subtitle}</p>}
        </div>
        {hasData && (
          <button
            type="button"
            onClick={handleDownload}
            disabled={exporting}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-[#111827] bg-[#F5F7FB] border border-[#E5E7EB] rounded-lg hover:bg-slate-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-50"
            title={`Download ${title} as PNG`}
          >
            <Download className="w-3.5 h-3.5 text-[#64748B]" />
            <span>{exporting ? 'Exporting' : 'PNG'}</span>
          </button>
        )}
      </div>
      {hasData ? (
        children
      ) : (
        <div className="flex-1 min-h-[220px] flex items-center justify-center border border-dashed border-[#E5E7EB] rounded-lg bg-[#F5F7FB]/60 px-4 text-center">
          <p className="text-sm text-[#64748B]">{emptyText}</p>
        </div>
      )}
    </div>
  );
}

export function MonthlyBooksBarChart({
  data,
  limit = 12,
}: {
  data: MonthlyPoint[];
  limit?: number;
}) {
  const svgRef = useRef<SVGSVGElement | null>(null);
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);
  const slice = data.slice(-limit);

  const W = 620;
  const H = 250;
  const padL = 40;
  const padR = 16;
  const padT = 20;
  const padB = 48;
  const plotW = W - padL - padR;
  const plotH = H - padT - padB;
  const maxVal = Math.max(1, ...slice.map((d) => d.books));
  const yTicks = Array.from({length: Math.min(maxVal + 1, 6)}, (_, i) =>
    Math.round((maxVal * i) / Math.min(maxVal, 5)),
  );
  const uniqueTicks = Array.from(new Set(yTicks));

  return (
    <ChartCard
      title="Monthly Reading Activity"
      subtitle={slice.length > 0 ? `Books completed across last ${slice.length} active months` : undefined}
      filename="monthly_books_completed.png"
      svgRef={svgRef}
      hasData={slice.length > 0}
      emptyText="Complete a book with a completion date to display monthly activity."
    >
      <div className="relative">
        <svg ref={svgRef} viewBox={`0 0 ${W} ${H}`} className="w-full h-auto overflow-visible">
          {uniqueTicks.map((t) => {
            const y = padT + plotH - (t / maxVal) * plotH;
            return (
              <g key={t}>
                <line x1={padL} x2={W - padR} y1={y} y2={y} stroke="#E5E7EB" strokeDasharray="3 3" />
                <text
                  x={padL - 8}
                  y={y + 4}
                  textAnchor="end"
                  fontSize="11"
                  fill="#64748B"
                  fontFamily="IBM Plex Mono, monospace"
                >
                  {t}
                </text>
              </g>
            );
          })}
          {slice.map((point, idx) => {
            const slotW = plotW / slice.length;
            const barW = Math.min(36, slotW * 0.56);
            const x = padL + idx * slotW + (slotW - barW) / 2;
            const barH = (point.books / maxVal) * plotH;
            const y = padT + plotH - barH;
            const isHovered = hoveredIdx === idx;
            return (
              <g
                key={point.month_key}
                onMouseEnter={() => setHoveredIdx(idx)}
                onMouseLeave={() => setHoveredIdx(null)}
                className="cursor-pointer"
              >
                <rect
                  x={x}
                  y={y}
                  width={barW}
                  height={Math.max(2, barH)}
                  rx={4}
                  fill={isHovered ? '#8B5CF6' : '#6366F1'}
                />
                <text
                  x={x + barW / 2}
                  y={y - 6}
                  textAnchor="middle"
                  fontSize="11"
                  fontWeight="600"
                  fill="#111827"
                  fontFamily="IBM Plex Mono, monospace"
                >
                  {point.books}
                </text>
                <text
                  x={x + barW / 2}
                  y={padT + plotH + 16}
                  textAnchor="end"
                  transform={`rotate(-28 ${x + barW / 2} ${padT + plotH + 16})`}
                  fontSize="10.5"
                  fill="#64748B"
                  fontFamily="Inter, sans-serif"
                >
                  {point.label}
                </text>
              </g>
            );
          })}
        </svg>
        {hoveredIdx !== null && slice[hoveredIdx] && (
          <div className="mt-2 px-3 py-1.5 bg-[#111827] text-white text-xs rounded-lg inline-flex items-center gap-3 font-mono">
            <span>{slice[hoveredIdx].label}</span>
            <span>·</span>
            <span>{slice[hoveredIdx].books} books</span>
            <span>·</span>
            <span>{slice[hoveredIdx].pages.toLocaleString()} pages</span>
          </div>
        )}
      </div>
    </ChartCard>
  );
}

export function MonthlyPagesLineChart({
  data,
  limit = 12,
}: {
  data: MonthlyPoint[];
  limit?: number;
}) {
  const svgRef = useRef<SVGSVGElement | null>(null);
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);
  const slice = data.slice(-limit);

  const W = 620;
  const H = 250;
  const padL = 52;
  const padR = 20;
  const padT = 20;
  const padB = 48;
  const plotW = W - padL - padR;
  const plotH = H - padT - padB;
  const maxPages = Math.max(100, ...slice.map((d) => d.pages));
  const tickCount = 4;
  const ticks = Array.from({length: tickCount + 1}, (_, i) => Math.round((maxPages * i) / tickCount));

  const coords = slice.map((d, idx) => {
    const x =
      slice.length === 1
        ? padL + plotW / 2
        : padL + (idx / (slice.length - 1)) * plotW;
    const y = padT + plotH - (d.pages / maxPages) * plotH;
    return {x, y, point: d};
  });

  const linePath = coords.map((c, i) => `${i === 0 ? 'M' : 'L'} ${c.x} ${c.y}`).join(' ');
  const areaPath =
    coords.length > 0
      ? `${linePath} L ${coords[coords.length - 1].x} ${padT + plotH} L ${coords[0].x} ${padT + plotH} Z`
      : '';

  return (
    <ChartCard
      title="Reading Progress"
      subtitle={slice.length > 0 ? 'Monthly pages completed over time' : undefined}
      filename="pages_read_over_time.png"
      svgRef={svgRef}
      hasData={slice.length > 0}
      emptyText="Monthly page trends will appear once completed books are logged."
    >
      <div className="relative">
        <svg ref={svgRef} viewBox={`0 0 ${W} ${H}`} className="w-full h-auto overflow-visible">
          {ticks.map((t) => {
            const y = padT + plotH - (t / maxPages) * plotH;
            return (
              <g key={t}>
                <line x1={padL} x2={W - padR} y1={y} y2={y} stroke="#E5E7EB" strokeDasharray="3 3" />
                <text
                  x={padL - 8}
                  y={y + 4}
                  textAnchor="end"
                  fontSize="11"
                  fill="#64748B"
                  fontFamily="IBM Plex Mono, monospace"
                >
                  {t.toLocaleString()}
                </text>
              </g>
            );
          })}
          {areaPath && <path d={areaPath} fill="#8B5CF6" fillOpacity="0.12" />}
          {linePath && <path d={linePath} fill="none" stroke="#8B5CF6" strokeWidth="2.5" />}
          {coords.map((c, idx) => (
            <g
              key={c.point.month_key}
              onMouseEnter={() => setHoveredIdx(idx)}
              onMouseLeave={() => setHoveredIdx(null)}
              className="cursor-pointer"
            >
              <circle
                cx={c.x}
                cy={c.y}
                r={hoveredIdx === idx ? 6 : 4.5}
                fill={hoveredIdx === idx ? '#111827' : '#6366F1'}
                stroke="#FFFFFF"
                strokeWidth="1.5"
              />
              <text
                x={c.x}
                y={padT + plotH + 16}
                textAnchor="end"
                transform={`rotate(-28 ${c.x} ${padT + plotH + 16})`}
                fontSize="10.5"
                fill="#64748B"
                fontFamily="Inter, sans-serif"
              >
                {c.point.label}
              </text>
            </g>
          ))}
        </svg>
        {hoveredIdx !== null && slice[hoveredIdx] && (
          <div className="mt-2 px-3 py-1.5 bg-[#111827] text-white text-xs rounded-lg inline-flex items-center gap-3 font-mono">
            <span>{slice[hoveredIdx].label}</span>
            <span>·</span>
            <span>{slice[hoveredIdx].pages.toLocaleString()} pages</span>
            <span>·</span>
            <span>{slice[hoveredIdx].books} books</span>
          </div>
        )}
      </div>
    </ChartCard>
  );
}

export function GenreDonutChart({data}: {data: GenreSlice[]}) {
  const svgRef = useRef<SVGSVGElement | null>(null);
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  const total = data.reduce((sum, item) => sum + item.count, 0);
  const size = 230;
  const cx = size / 2;
  const cy = size / 2;
  const radius = 78;
  const strokeW = 32;
  const circumference = 2 * Math.PI * radius;

  let cumulative = 0;

  return (
    <ChartCard
      title="Genre Distribution"
      subtitle={total > 0 ? `Share across ${total} completed books` : undefined}
      filename="genre_distribution.png"
      svgRef={svgRef}
      hasData={data.length > 0}
      emptyText="Complete books across genres to visualize genre distribution."
    >
      <div className="grid grid-cols-1 md:grid-cols-[230px_1fr] gap-5 items-center">
        <svg ref={svgRef} viewBox={`0 0 ${size} ${size}`} className="w-[210px] h-[210px] mx-auto">
          {data.map((slice, idx) => {
            const fraction = total > 0 ? slice.count / total : 0;
            const dash = fraction * circumference;
            const offset = -cumulative * circumference;
            cumulative += fraction;
            const color = CHART_COLORS[idx % CHART_COLORS.length];
            const isHovered = hoveredIdx === idx;
            return (
              <circle
                key={slice.genre}
                cx={cx}
                cy={cy}
                r={radius}
                fill="none"
                stroke={color}
                strokeWidth={isHovered ? strokeW + 5 : strokeW}
                strokeDasharray={`${dash} ${circumference}`}
                strokeDashoffset={offset}
                transform={`rotate(-90 ${cx} ${cy})`}
                onMouseEnter={() => setHoveredIdx(idx)}
                onMouseLeave={() => setHoveredIdx(null)}
                className="cursor-pointer transition-all duration-150"
              />
            );
          })}
          <text
            x={cx}
            y={cy - 4}
            textAnchor="middle"
            fontSize="22"
            fontWeight="700"
            fill="#111827"
            fontFamily="IBM Plex Mono, monospace"
          >
            {hoveredIdx !== null && data[hoveredIdx] ? `${data[hoveredIdx].percentage}%` : total}
          </text>
          <text
            x={cx}
            y={cy + 16}
            textAnchor="middle"
            fontSize="11"
            fill="#64748B"
            fontFamily="Inter, sans-serif"
          >
            {hoveredIdx !== null && data[hoveredIdx] ? data[hoveredIdx].genre : 'Completed'}
          </text>
        </svg>

        <div className="divide-y divide-slate-100">
          {data.map((item, idx) => (
            <div
              key={item.genre}
              onMouseEnter={() => setHoveredIdx(idx)}
              onMouseLeave={() => setHoveredIdx(null)}
              className={`flex items-center justify-between py-1.5 px-2 rounded-md text-xs transition-colors cursor-pointer ${
                hoveredIdx === idx ? 'bg-[#F5F7FB]' : ''
              }`}
            >
              <div className="flex items-center gap-2 min-w-0">
                <span
                  className="w-2.5 h-2.5 rounded-sm shrink-0"
                  style={{backgroundColor: CHART_COLORS[idx % CHART_COLORS.length]}}
                />
                <span className="text-[#111827] font-medium truncate">{item.genre}</span>
              </div>
              <div className="flex items-center gap-3 font-mono text-[#64748B] shrink-0">
                <span>{item.count} bks</span>
                <span className="w-12 text-right font-semibold text-[#111827]">
                  {item.percentage}%
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </ChartCard>
  );
}

export function YearlyComparisonChart({data}: {data: YearlyPoint[]}) {
  const svgRef = useRef<SVGSVGElement | null>(null);
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  const W = 560;
  const H = 240;
  const padL = 48;
  const padR = 20;
  const padT = 20;
  const padB = 38;
  const plotW = W - padL - padR;
  const plotH = H - padT - padB;
  const maxPages = Math.max(100, ...data.map((d) => d.pages));

  return (
    <ChartCard
      title="Yearly Reading Comparison"
      subtitle="Annual completed books and page totals"
      filename="yearly_reading_comparison.png"
      svgRef={svgRef}
      hasData={data.length > 0}
      emptyText="Yearly comparison requires completed books with completion dates."
    >
      <div>
        <svg ref={svgRef} viewBox={`0 0 ${W} ${H}`} className="w-full h-auto overflow-visible">
          {[0, 0.25, 0.5, 0.75, 1].map((ratio) => {
            const val = Math.round(maxPages * ratio);
            const y = padT + plotH - ratio * plotH;
            return (
              <g key={ratio}>
                <line x1={padL} x2={W - padR} y1={y} y2={y} stroke="#E5E7EB" strokeDasharray="3 3" />
                <text
                  x={padL - 8}
                  y={y + 4}
                  textAnchor="end"
                  fontSize="11"
                  fill="#64748B"
                  fontFamily="IBM Plex Mono, monospace"
                >
                  {val.toLocaleString()}
                </text>
              </g>
            );
          })}
          {data.map((yr, idx) => {
            const slotW = plotW / data.length;
            const barW = Math.min(54, slotW * 0.45);
            const x = padL + idx * slotW + (slotW - barW) / 2;
            const barH = (yr.pages / maxPages) * plotH;
            const y = padT + plotH - barH;
            return (
              <g
                key={yr.year}
                onMouseEnter={() => setHoveredIdx(idx)}
                onMouseLeave={() => setHoveredIdx(null)}
                className="cursor-pointer"
              >
                <rect
                  x={x}
                  y={y}
                  width={barW}
                  height={Math.max(4, barH)}
                  rx={4}
                  fill={hoveredIdx === idx ? '#8B5CF6' : '#6366F1'}
                />
                <text
                  x={x + barW / 2}
                  y={y - 6}
                  textAnchor="middle"
                  fontSize="11"
                  fontWeight="600"
                  fill="#111827"
                  fontFamily="IBM Plex Mono, monospace"
                >
                  {yr.books} bks
                </text>
                <text
                  x={x + barW / 2}
                  y={padT + plotH + 18}
                  textAnchor="middle"
                  fontSize="12"
                  fontWeight="600"
                  fill="#64748B"
                  fontFamily="IBM Plex Mono, monospace"
                >
                  {yr.year}
                </text>
              </g>
            );
          })}
        </svg>
        {hoveredIdx !== null && data[hoveredIdx] && (
          <div className="mt-2 px-3 py-1.5 bg-[#111827] text-white text-xs rounded-lg inline-flex items-center gap-3 font-mono">
            <span>{data[hoveredIdx].year}</span>
            <span>·</span>
            <span>{data[hoveredIdx].books} completed</span>
            <span>·</span>
            <span>{data[hoveredIdx].pages.toLocaleString()} pages</span>
            <span>·</span>
            <span>Avg {data[hoveredIdx].avg_pages} p/book</span>
          </div>
        )}
      </div>
    </ChartCard>
  );
}

export function StatusDistributionChart({data}: {data: StatusSlice[]}) {
  const svgRef = useRef<SVGSVGElement | null>(null);
  const maxCount = Math.max(1, ...data.map((d) => d.count));

  const W = 540;
  const H = 175;
  const padL = 135;
  const padR = 72;
  const padT = 18;
  const rowH = 44;

  const statusColors: Record<string, string> = {
    Completed: '#10B981',
    'Currently Reading': '#6366F1',
    Planned: '#94A3B8',
  };

  return (
    <ChartCard
      title="Reading Status Distribution"
      subtitle="Share of library across Completed, Currently Reading, and Planned"
      filename="reading_status_distribution.png"
      svgRef={svgRef}
      hasData={data.length > 0}
      emptyText="Add books to your library to view status breakdown."
    >
      <svg ref={svgRef} viewBox={`0 0 ${W} ${H}`} className="w-full h-auto">
        {data.map((row, idx) => {
          const y = padT + idx * rowH;
          const barMaxW = W - padL - padR;
          const barW = (row.count / maxCount) * barMaxW;
          return (
            <g key={row.status}>
              <text
                x={padL - 12}
                y={y + 18}
                textAnchor="end"
                fontSize="12"
                fontWeight="500"
                fill="#111827"
                fontFamily="Inter, sans-serif"
              >
                {row.status}
              </text>
              <rect x={padL} y={y + 4} width={barMaxW} height={22} rx={4} fill="#F5F7FB" />
              <rect
                x={padL}
                y={y + 4}
                width={Math.max(row.count > 0 ? 6 : 0, barW)}
                height={22}
                rx={4}
                fill={statusColors[row.status] ?? '#6366F1'}
              />
              <text
                x={padL + barMaxW + 10}
                y={y + 19}
                fontSize="11.5"
                fontWeight="600"
                fill="#111827"
                fontFamily="IBM Plex Mono, monospace"
              >
                {row.count} ({row.percentage}%)
              </text>
            </g>
          );
        })}
      </svg>
    </ChartCard>
  );
}
