import React, {useState} from 'react';
import {AlertCircle, CheckCircle2, Download, FileSpreadsheet, Upload} from 'lucide-react';
import {AnalyticsPayload, AppSettings, BookRecord, ImportSummary} from '../types';
import {downloadTextFile} from '../utils/exportHelpers';
import {
  GenreDonutChart,
  MonthlyBooksBarChart,
  MonthlyPagesLineChart,
  YearlyComparisonChart,
} from './Charts';

export function ImportDatasetView({
  onImportCsv,
}: {
  onImportCsv: (
    csvText: string,
    skipDuplicates: boolean,
  ) => Promise<{ok: boolean; error?: string; summary?: ImportSummary}>;
}) {
  const [csvText, setCsvText] = useState('');
  const [fileInfo, setFileInfo] = useState<{name: string; sizeKb: number; lines: number} | null>(
    null,
  );
  const [skipDuplicates, setSkipDuplicates] = useState(true);
  const [loading, setLoading] = useState(false);
  const [headerError, setHeaderError] = useState<string | null>(null);
  const [summary, setSummary] = useState<ImportSummary | null>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const content = await file.text();
    setFileInfo({
      name: file.name,
      sizeKb: Math.max(0.1, Math.round((file.size / 1024) * 10) / 10),
      lines: Math.max(0, content.split(/\r?\n/).filter((l) => l.trim()).length - 1),
    });
    setCsvText(content);
    setHeaderError(null);
    setSummary(null);
  };

  const handleLoadTestCsvWithBadRow = () => {
    const sampleCsv = [
      'title,author,genre,pages,status,start_date,completion_date,rating,notes',
      'The Art of Statistics,David Spiegelhalter,Science,448,Completed,2026-11-01,2026-11-18,4.8,"Clear applied probability and inference."',
      ',Missing Title Example,Fiction,210,Planned,2026-11-10,,,"Should fail row validation cleanly"',
      'Negative Pages Example,Test Author,Technology,-120,Planned,2026-11-10,,,"Should fail negative pages check"',
      'Bad Date Order,Test Author,History,310,Completed,2026-11-20,2026-11-05,4.0,"Completion precedes start"',
    ].join('\n');
    setFileInfo({name: 'validation_demo.csv', sizeKb: 0.4, lines: 4});
    setCsvText(sampleCsv);
    setHeaderError(null);
    setSummary(null);
  };

  const handleRunImport = async () => {
    setLoading(true);
    setHeaderError(null);
    const res = await onImportCsv(csvText, skipDuplicates);
    setLoading(false);
    if (!res.ok) {
      setHeaderError(res.error || 'Import failed.');
    }
    if (res.summary) {
      setSummary(res.summary);
    }
  };

  return (
    <div className="max-w-4xl space-y-6">
      <div className="bg-white border border-[#E5E7EB] rounded-xl p-6 shadow-[0_1px_2px_rgba(17,24,39,0.04)] space-y-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h2 className="text-lg font-semibold text-[#111827] tracking-tight">
              Bulk CSV Dataset Import
            </h2>
            <p className="text-sm text-[#64748B] mt-1">
              Validates headers, checks every row independently, skips duplicates, and imports valid
              records safely.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <a
              href="/api/sample-csv"
              download="sample_books.csv"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#111827] bg-white border border-[#E5E7EB] rounded-lg hover:bg-slate-50"
            >
              <Download className="w-3.5 h-3.5 text-[#64748B]" />
              <span>Download Sample CSV</span>
            </a>
            <button
              type="button"
              onClick={handleLoadTestCsvWithBadRow}
              className="px-3 py-1.5 text-xs font-medium text-[#6366F1] bg-[#EEF2FF] border border-[#6366F1]/25 rounded-lg hover:bg-indigo-100/70 cursor-pointer"
            >
              Load Mixed Valid/Invalid CSV Demo
            </button>
          </div>
        </div>

        <div className="border border-dashed border-slate-300 rounded-xl p-6 bg-[#F5F7FB]">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-lg bg-white border border-[#E5E7EB] flex items-center justify-center text-[#6366F1] shrink-0">
                <FileSpreadsheet className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm font-medium text-[#111827]">
                  {fileInfo ? fileInfo.name : 'Choose a CSV file to upload'}
                </p>
                <p className="text-xs text-[#64748B] mt-0.5 font-mono">
                  {fileInfo
                    ? `${fileInfo.sizeKb} KB · ${fileInfo.lines} data row(s) detected`
                    : 'Required columns: title, author, genre, pages, status, start_date'}
                </p>
              </div>
            </div>
            <label className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-[#111827] rounded-lg hover:bg-slate-800 cursor-pointer whitespace-nowrap shrink-0">
              <Upload className="w-3.5 h-3.5" />
              <span>Select CSV File</span>
              <input type="file" accept=".csv,text/csv" onChange={handleFileChange} className="hidden" />
            </label>
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-[#111827] mb-1.5">
            CSV Payload Preview / Direct Paste
          </label>
          <textarea
            rows={6}
            value={csvText}
            onChange={(e) => setCsvText(e.target.value)}
            placeholder="Paste CSV content or select a .csv file above..."
            className="w-full px-3 py-2 text-xs font-mono border border-[#E5E7EB] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#6366F1]/20 focus:border-[#6366F1]"
          />
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
          <label className="flex items-center gap-2 text-xs text-[#64748B] cursor-pointer">
            <input
              type="checkbox"
              checked={skipDuplicates}
              onChange={(e) => setSkipDuplicates(e.target.checked)}
              className="rounded border-[#E5E7EB]"
            />
            <span>Skip duplicate records matching existing Title + Author</span>
          </label>

          <button
            type="button"
            disabled={!csvText.trim() || loading}
            onClick={handleRunImport}
            className="px-5 py-2 text-xs font-semibold text-white bg-[#6366F1] rounded-lg hover:bg-[#4F46E5] disabled:opacity-40 cursor-pointer"
          >
            {loading ? 'Importing...' : 'Validate & Import Rows'}
          </button>
        </div>

        {headerError && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-center gap-2 text-xs text-[#EF4444]">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{headerError}</span>
          </div>
        )}
      </div>

      {summary && (
        <div className="bg-white border border-[#E5E7EB] rounded-xl p-6 shadow-[0_1px_2px_rgba(17,24,39,0.04)] space-y-4">
          <div className="flex items-center gap-2 text-base font-semibold text-[#111827]">
            <CheckCircle2 className="w-5 h-5 text-[#10B981]" />
            <span>Import Execution Summary</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="border border-[#E5E7EB] rounded-lg p-3">
              <p className="text-xs text-[#64748B]">Total Rows Processed</p>
              <p className="text-2xl font-bold font-mono text-[#111827] mt-1">
                {summary.total_rows}
              </p>
            </div>
            <div className="border border-[#E5E7EB] rounded-lg p-3">
              <p className="text-xs text-[#64748B]">Successfully Imported</p>
              <p className="text-2xl font-bold font-mono text-[#10B981] mt-1">
                {summary.imported_count}
              </p>
            </div>
            <div className="border border-[#E5E7EB] rounded-lg p-3">
              <p className="text-xs text-[#64748B]">Duplicates Skipped</p>
              <p className="text-2xl font-bold font-mono text-[#F59E0B] mt-1">
                {summary.duplicate_count}
              </p>
            </div>
            <div className="border border-[#E5E7EB] rounded-lg p-3">
              <p className="text-xs text-[#64748B]">Invalid Rows Rejected</p>
              <p className="text-2xl font-bold font-mono text-[#EF4444] mt-1">
                {summary.failed_count}
              </p>
            </div>
          </div>

          {summary.errors.length > 0 && (
            <div className="border border-[#E5E7EB] rounded-lg overflow-hidden">
              <div className="px-4 py-2.5 bg-[#F5F7FB] border-b border-[#E5E7EB] text-xs font-medium text-[#111827]">
                Row-by-Row Validation &amp; Duplicate Report
              </div>
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-[#E5E7EB] text-[#64748B]">
                    <th className="py-2 px-4 w-20">Row #</th>
                    <th className="py-2 px-4">Title</th>
                    <th className="py-2 px-4">Reason</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {summary.errors.map((err, idx) => (
                    <tr key={idx}>
                      <td className="py-2 px-4 font-mono text-[#64748B]">{err.row_number}</td>
                      <td className="py-2 px-4 font-medium text-[#111827]">{err.title}</td>
                      <td className="py-2 px-4 text-[#EF4444]">{err.reason}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export function ExportReportsView({
  books,
  analytics,
}: {
  books: BookRecord[];
  analytics: AnalyticsPayload;
}) {
  const [scope, setScope] = useState<'all' | 'completed'>('all');
  const [previewFormat, setPreviewFormat] = useState<'markdown' | 'txt' | 'csv' | 'json'>('markdown');
  const [previewContent, setPreviewContent] = useState<string | null>(null);
  const [loadingPreview, setLoadingPreview] = useState(false);

  const scopedBooks =
    scope === 'all' ? books : books.filter((b) => b.status === 'Completed');

  const fetchAndDownload = async (
    format: 'csv' | 'json' | 'markdown' | 'txt',
    download: boolean,
  ) => {
    setLoadingPreview(true);
    const res = await fetch('/api/export/preview', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({scope, format}),
    });
    const data = await res.json();
    setLoadingPreview(false);
    const content = String(data.content ?? '');
    if (download) {
      const extMap = {csv: 'csv', json: 'json', markdown: 'md', txt: 'txt'};
      const mimeMap = {
        csv: 'text/csv',
        json: 'application/json',
        markdown: 'text/markdown',
        txt: 'text/plain',
      };
      downloadTextFile(
        content,
        `book_reading_statistics.${extMap[format]}`,
        mimeMap[format],
      );
    } else {
      setPreviewFormat(format);
      setPreviewContent(content);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white border border-[#E5E7EB] rounded-xl p-6 shadow-[0_1px_2px_rgba(17,24,39,0.04)] space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-semibold text-[#111827] tracking-tight">
              Export Reports &amp; Datasets
            </h2>
            <p className="text-sm text-[#64748B] mt-0.5">
              Download live reading records and executive analytics in CSV, JSON, Markdown, Plain
              Text, or PNG charts.
            </p>
          </div>

          <div className="flex items-center gap-1 p-1 bg-[#F5F7FB] border border-[#E5E7EB] rounded-lg text-xs">
            <button
              type="button"
              onClick={() => {
                setScope('all');
                setPreviewContent(null);
              }}
              className={`px-3 py-1.5 rounded-md font-medium cursor-pointer ${
                scope === 'all' ? 'bg-white text-[#111827] shadow-xs' : 'text-[#64748B]'
              }`}
            >
              All Books ({books.length})
            </button>
            <button
              type="button"
              onClick={() => {
                setScope('completed');
                setPreviewContent(null);
              }}
              className={`px-3 py-1.5 rounded-md font-medium cursor-pointer ${
                scope === 'completed' ? 'bg-white text-[#111827] shadow-xs' : 'text-[#64748B]'
              }`}
            >
              Completed Only ({books.filter((b) => b.status === 'Completed').length})
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            {
              fmt: 'csv' as const,
              title: 'CSV Dataset',
              desc: 'Standardized tabular columns for spreadsheets & BI tools.',
            },
            {
              fmt: 'json' as const,
              title: 'JSON Archive',
              desc: 'Structured book records with export timestamp metadata.',
            },
            {
              fmt: 'markdown' as const,
              title: 'Markdown Summary',
              desc: 'Executive summary with KPIs, genre tables, and observations.',
            },
            {
              fmt: 'txt' as const,
              title: 'Plain Text Audit',
              desc: 'Audit-style summary report and full numbered book ledger.',
            },
          ].map((item) => (
            <div
              key={item.fmt}
              className="border border-[#E5E7EB] rounded-xl p-4 flex flex-col justify-between gap-4 hover:border-slate-300 transition-colors"
            >
              <div>
                <h3 className="text-sm font-semibold text-[#111827]">{item.title}</h3>
                <p className="text-xs text-[#64748B] mt-1 leading-relaxed">{item.desc}</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => fetchAndDownload(item.fmt, true)}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-[#6366F1] rounded-lg hover:bg-[#4F46E5] cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download</span>
                </button>
                <button
                  type="button"
                  onClick={() => fetchAndDownload(item.fmt, false)}
                  className="px-3 py-1.5 text-xs font-medium text-[#111827] bg-[#F5F7FB] border border-[#E5E7EB] rounded-lg hover:bg-slate-100 cursor-pointer"
                >
                  Preview
                </button>
              </div>
            </div>
          ))}
        </div>

        {loadingPreview && <p className="text-xs text-[#64748B]">Generating report preview...</p>}
        {previewContent !== null && !loadingPreview && (
          <div className="border border-[#E5E7EB] rounded-xl overflow-hidden">
            <div className="flex items-center justify-between px-4 py-2.5 bg-[#F5F7FB] border-b border-[#E5E7EB] text-xs">
              <span className="font-mono font-medium text-[#111827]">
                Preview ({previewFormat.toUpperCase()} · {scopedBooks.length} records)
              </span>
              <button
                type="button"
                onClick={() => setPreviewContent(null)}
                className="text-[#64748B] hover:text-[#111827] cursor-pointer"
              >
                Close Preview
              </button>
            </div>
            <pre className="p-4 text-xs font-mono text-[#111827] bg-white max-h-80 overflow-auto whitespace-pre-wrap">
              {previewContent}
            </pre>
          </div>
        )}
      </div>

      {/* PNG Chart Exports */}
      <div>
        <h3 className="text-base font-semibold text-[#111827] mb-3">
          Export Charts as High-Resolution PNG
        </h3>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <MonthlyBooksBarChart data={analytics.monthly} />
          <MonthlyPagesLineChart data={analytics.monthly} />
          <GenreDonutChart data={analytics.genres} />
          <YearlyComparisonChart data={analytics.yearly} />
        </div>
      </div>
    </div>
  );
}

export function SettingsView({
  settings,
  storagePath,
  bookCount,
  onSaveSettings,
  onLoadSample,
  onClearDatabase,
}: {
  settings: AppSettings;
  storagePath: string;
  bookCount: number;
  onSaveSettings: (next: AppSettings) => Promise<void>;
  onLoadSample: (replace: boolean) => Promise<{added: number; skipped: number}>;
  onClearDatabase: () => void;
}) {
  const [monthlyBooks, setMonthlyBooks] = useState(settings.monthly_book_target);
  const [monthlyPages, setMonthlyPages] = useState(settings.monthly_page_target);
  const [highPageThreshold, setHighPageThreshold] = useState(settings.high_page_threshold);
  const [ratingMin, setRatingMin] = useState(settings.rating_min);
  const [ratingMax, setRatingMax] = useState(settings.rating_max);
  const [strictDup, setStrictDup] = useState(settings.strict_duplicate_check);
  const [pageSize, setPageSize] = useState(settings.default_page_size);
  const [statusNote, setStatusNote] = useState<string | null>(null);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSaveSettings({
      monthly_book_target: Number(monthlyBooks),
      monthly_page_target: Number(monthlyPages),
      high_page_threshold: Number(highPageThreshold),
      rating_min: Number(ratingMin),
      rating_max: Number(ratingMax),
      strict_duplicate_check: strictDup,
      default_page_size: Number(pageSize),
    });
    setStatusNote('Settings saved and thresholds recalculated.');
  };

  const handleLoadSample = async (replace: boolean) => {
    const res = await onLoadSample(replace);
    setStatusNote(
      replace
        ? `Replaced database with ${res.added} demonstration books.`
        : `Merged ${res.added} sample book(s) (${res.skipped} duplicate records skipped).`,
    );
  };

  return (
    <div className="max-w-3xl space-y-6">
      {statusNote && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl px-4 py-3 text-xs text-emerald-900 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-[#10B981] shrink-0" />
          <span>{statusNote}</span>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-6">
        {/* Reading Goals */}
        <div className="bg-white border border-[#E5E7EB] rounded-xl p-6 shadow-[0_1px_2px_rgba(17,24,39,0.04)] space-y-4">
          <div>
            <h2 className="text-base font-semibold text-[#111827]">Reading Goals</h2>
            <p className="text-xs text-[#64748B] mt-0.5">
              Monthly targets tracked on your dashboard and warning indicators.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-[#111827] mb-1.5">
                Monthly Book Target
              </label>
              <input
                type="number"
                min={1}
                max={50}
                value={monthlyBooks}
                onChange={(e) => setMonthlyBooks(Number(e.target.value))}
                className="w-full px-3 py-2 text-sm font-mono border border-[#E5E7EB] rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[#111827] mb-1.5">
                Monthly Page Target
              </label>
              <input
                type="number"
                min={50}
                step={50}
                value={monthlyPages}
                onChange={(e) => setMonthlyPages(Number(e.target.value))}
                className="w-full px-3 py-2 text-sm font-mono border border-[#E5E7EB] rounded-lg"
              />
            </div>
          </div>
        </div>

        {/* Warning Configuration */}
        <div className="bg-white border border-[#E5E7EB] rounded-xl p-6 shadow-[0_1px_2px_rgba(17,24,39,0.04)] space-y-4">
          <div>
            <h2 className="text-base font-semibold text-[#111827]">Warning Configuration</h2>
            <p className="text-xs text-[#64748B] mt-0.5">
              Thresholds for automated data quality notices and rating validation bounds.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-[#111827] mb-1.5">
                High Page Count Threshold
              </label>
              <input
                type="number"
                min={100}
                step={50}
                value={highPageThreshold}
                onChange={(e) => setHighPageThreshold(Number(e.target.value))}
                className="w-full px-3 py-2 text-sm font-mono border border-[#E5E7EB] rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[#111827] mb-1.5">
                Minimum Rating
              </label>
              <input
                type="number"
                step={0.5}
                value={ratingMin}
                onChange={(e) => setRatingMin(Number(e.target.value))}
                className="w-full px-3 py-2 text-sm font-mono border border-[#E5E7EB] rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[#111827] mb-1.5">
                Maximum Rating
              </label>
              <input
                type="number"
                step={0.5}
                value={ratingMax}
                onChange={(e) => setRatingMax(Number(e.target.value))}
                className="w-full px-3 py-2 text-sm font-mono border border-[#E5E7EB] rounded-lg"
              />
            </div>
          </div>
        </div>

        {/* Library Preferences */}
        <div className="bg-white border border-[#E5E7EB] rounded-xl p-6 shadow-[0_1px_2px_rgba(17,24,39,0.04)] space-y-4">
          <div>
            <h2 className="text-base font-semibold text-[#111827]">Library Preferences</h2>
            <p className="text-xs text-[#64748B] mt-0.5">
              Configure pagination defaults and duplicate record handling.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
            <div>
              <label className="block text-xs font-medium text-[#111827] mb-1.5">
                Default Library Page Size
              </label>
              <input
                type="number"
                min={5}
                max={100}
                value={pageSize}
                onChange={(e) => setPageSize(Number(e.target.value))}
                className="w-full px-3 py-2 text-sm font-mono border border-[#E5E7EB] rounded-lg"
              />
            </div>
            <label className="flex items-center gap-2 text-xs text-[#111827] cursor-pointer pt-4">
              <input
                type="checkbox"
                checked={strictDup}
                onChange={(e) => setStrictDup(e.target.checked)}
                className="rounded border-[#E5E7EB]"
              />
              <span>Enforce strict duplicate prevention (Title + Author)</span>
            </label>
          </div>

          <div className="flex justify-end pt-3 border-t border-[#E5E7EB]">
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold text-white bg-[#6366F1] rounded-lg hover:bg-[#4F46E5] cursor-pointer"
            >
              Save Settings
            </button>
          </div>
        </div>
      </form>

      {/* Storage */}
      <div className="bg-white border border-[#E5E7EB] rounded-xl p-6 shadow-[0_1px_2px_rgba(17,24,39,0.04)] space-y-4">
        <div>
          <h3 className="text-base font-semibold text-[#111827]">Storage &amp; Database</h3>
          <p className="text-xs text-[#64748B] mt-1 font-mono">
            Path: {storagePath} · Stored Records: {bookCount}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={() => handleLoadSample(false)}
            className="px-4 py-2 text-xs font-medium text-[#111827] bg-white border border-[#E5E7EB] rounded-lg hover:bg-slate-50 cursor-pointer"
          >
            Merge Sample Dataset (Skip Duplicates)
          </button>

          <a
            href="/api/database/raw"
            download="books.json"
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-[#111827] bg-white border border-[#E5E7EB] rounded-lg hover:bg-slate-50"
          >
            <Download className="w-3.5 h-3.5 text-[#64748B]" />
            <span>Backup Raw JSON</span>
          </a>

          <button
            type="button"
            onClick={onClearDatabase}
            className="px-4 py-2 text-xs font-medium text-[#EF4444] bg-red-50 border border-red-200 rounded-lg hover:bg-red-100 cursor-pointer"
          >
            Clear All Books (Empty Database)
          </button>
        </div>
      </div>
    </div>
  );
}
