import React, {useState} from 'react';
import {AlertTriangle, X} from 'lucide-react';
import {
  AppSettings,
  BookRecord,
  GENRES,
  READING_STATUSES,
  ReadingStatus,
  WarningItem,
} from '../types';

export function BookDetailModal({
  book,
  warnings,
  onClose,
  onEdit,
  onDelete,
}: {
  book: BookRecord;
  warnings: WarningItem[];
  onClose: () => void;
  onEdit: () => void;
  onDelete: () => void;
}) {
  const bookWarnings = warnings.filter((w) => w.book_id === book.id);

  let daysSpan: number | null = null;
  if (book.start_date && book.completion_date) {
    const startMs = Date.parse(book.start_date);
    const endMs = Date.parse(book.completion_date);
    if (!Number.isNaN(startMs) && !Number.isNaN(endMs) && endMs >= startMs) {
      daysSpan = Math.max(1, Math.round((endMs - startMs) / 86400000) + 1);
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 flex items-center justify-center p-4">
      <div className="bg-white border border-slate-200 rounded-lg max-w-xl w-full shadow-lg overflow-hidden">
        <div className="flex items-start justify-between gap-4 px-6 py-4 border-b border-slate-200">
          <div>
            <p className="text-xs font-mono text-slate-500">
              {book.id} · {book.genre} · {book.status}
            </p>
            <h2 className="text-xl font-semibold text-slate-900 font-display mt-1">{book.title}</h2>
            <p className="text-sm text-slate-600 mt-0.5">by {book.author}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-md cursor-pointer"
            aria-label="Close details"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pb-4 border-b border-slate-100">
            <div>
              <p className="text-xs text-slate-500">Total Pages</p>
              <p className="text-base font-semibold text-slate-900 font-mono mt-0.5">
                {book.pages.toLocaleString()}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Personal Rating</p>
              <p className="text-base font-semibold text-slate-900 font-mono mt-0.5">
                {book.rating !== null ? `${book.rating.toFixed(1)} / 5.0` : 'Unrated'}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Start Date</p>
              <p className="text-sm font-medium text-slate-900 font-mono mt-1">{book.start_date}</p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Completion Date</p>
              <p className="text-sm font-medium text-slate-900 font-mono mt-1">
                {book.completion_date ?? 'In Progress'}
              </p>
            </div>
          </div>

          {daysSpan !== null && (
            <p className="text-xs text-slate-600 font-mono">
              Reading duration: {daysSpan} day{daysSpan === 1 ? '' : 's'} (
              {Math.round(book.pages / daysSpan)} pages/day avg)
            </p>
          )}

          <div>
            <p className="text-xs font-medium text-slate-500 mb-1">Reading Notes</p>
            <p className="text-sm text-slate-700 leading-relaxed bg-slate-50 border border-slate-200 rounded-md p-3">
              {book.notes || 'No notes recorded for this book.'}
            </p>
          </div>

          {bookWarnings.length > 0 && (
            <div className="space-y-1.5">
              {bookWarnings.map((w, i) => (
                <div
                  key={i}
                  className="flex items-start gap-2 text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded-md px-3 py-2"
                >
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{w.message}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="flex items-center justify-between gap-3 px-6 py-4 bg-[#F5F7FB] border-t border-[#E5E7EB]">
          <button
            type="button"
            onClick={onDelete}
            className="px-3 py-2 text-xs font-medium text-[#EF4444] hover:bg-red-50 border border-red-200 rounded-lg transition-colors cursor-pointer"
          >
            Delete Record
          </button>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-[#111827] bg-white border border-[#E5E7EB] rounded-lg hover:bg-slate-50 cursor-pointer"
            >
              Close
            </button>
            <button
              type="button"
              onClick={onEdit}
              className="px-4 py-2 text-xs font-semibold text-white bg-[#6366F1] rounded-lg hover:bg-[#4F46E5] cursor-pointer"
            >
              Edit Record
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export function EditBookModal({
  book,
  settings,
  onClose,
  onSave,
}: {
  book: BookRecord;
  settings: AppSettings;
  onClose: () => void;
  onSave: (id: string, payload: Record<string, unknown>) => Promise<string[]>;
}) {
  const [title, setTitle] = useState(book.title);
  const [author, setAuthor] = useState(book.author);
  const [genre, setGenre] = useState(book.genre);
  const [pages, setPages] = useState(String(book.pages));
  const [status, setStatus] = useState<ReadingStatus>(book.status);
  const [startDate, setStartDate] = useState(book.start_date);
  const [completionDate, setCompletionDate] = useState(book.completion_date ?? '');
  const [rating, setRating] = useState(book.rating !== null ? String(book.rating) : '');
  const [notes, setNotes] = useState(book.notes);
  const [errors, setErrors] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const errs = await onSave(book.id, {
      title,
      author,
      genre,
      pages,
      status,
      start_date: startDate,
      completion_date: completionDate,
      rating,
      notes,
    });
    setSaving(false);
    if (errs.length > 0) {
      setErrors(errs);
    } else {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 flex items-center justify-center p-4">
      <form
        onSubmit={handleSubmit}
        className="bg-white border border-slate-200 rounded-lg max-w-2xl w-full shadow-lg overflow-hidden"
      >
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
          <h2 className="text-lg font-semibold text-slate-900 font-display">Edit Book Record</h2>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-md cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {errors.length > 0 && (
            <div className="bg-red-50 border border-red-200 rounded-md p-3 text-xs text-red-800 space-y-1">
              {errors.map((err, i) => (
                <p key={i}>• {err}</p>
              ))}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Book Title *</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-900/20 focus:border-blue-900"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Author Name *</label>
              <input
                type="text"
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-900/20 focus:border-blue-900"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Genre *</label>
              <select
                value={genre}
                onChange={(e) => setGenre(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-blue-900/20 focus:border-blue-900"
              >
                {GENRES.map((g) => (
                  <option key={g} value={g}>
                    {g}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Total Pages *</label>
              <input
                type="text"
                value={pages}
                onChange={(e) => setPages(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-900/20 focus:border-blue-900"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Reading Status *
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as ReadingStatus)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-blue-900/20 focus:border-blue-900"
              >
                {READING_STATUSES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Personal Rating ({settings.rating_min}–{settings.rating_max})
              </label>
              <input
                type="text"
                value={rating}
                onChange={(e) => setRating(e.target.value)}
                placeholder="Optional (e.g. 4.5)"
                className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-900/20 focus:border-blue-900"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Start Date *</label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-900/20 focus:border-blue-900"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Completion Date {status === 'Completed' ? '*' : '(Optional)'}
              </label>
              <input
                type="date"
                value={completionDate}
                onChange={(e) => setCompletionDate(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-900/20 focus:border-blue-900"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Notes</label>
            <textarea
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-900/20 focus:border-blue-900"
            />
          </div>
        </div>

        <div className="flex items-center justify-end gap-2 px-6 py-4 bg-[#F5F7FB] border-t border-[#E5E7EB]">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-[#111827] bg-white border border-[#E5E7EB] rounded-lg hover:bg-slate-50 cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={saving}
            className="px-4 py-2 text-xs font-semibold text-white bg-[#6366F1] rounded-lg hover:bg-[#4F46E5] cursor-pointer disabled:opacity-50"
          >
            {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </form>
    </div>
  );
}

export function ConfirmDialog({
  title,
  message,
  confirmLabel,
  onConfirm,
  onCancel,
}: {
  title: string;
  message: string;
  confirmLabel: string;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 flex items-center justify-center p-4">
      <div className="bg-white border border-slate-200 rounded-lg max-w-md w-full shadow-lg p-6">
        <h3 className="text-base font-semibold text-slate-900 font-display">{title}</h3>
        <p className="text-sm text-slate-600 mt-2 leading-relaxed">{message}</p>
        <div className="flex items-center justify-end gap-2 mt-6">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-50 cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className="px-4 py-2 text-xs font-medium text-white bg-red-600 rounded-md hover:bg-red-700 cursor-pointer"
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
