import React, {useMemo, useState} from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Eye,
  LayoutGrid,
  List,
  Pencil,
  Search,
  Star,
  Trash2,
} from 'lucide-react';
import {AppSettings, BookRecord, GENRES, NavSection, READING_STATUSES} from '../types';

type SortOption =
  | 'date_desc'
  | 'date_asc'
  | 'title_asc'
  | 'title_desc'
  | 'pages_desc'
  | 'pages_asc'
  | 'rating_desc';

const GENRE_COVER_PALETTES: Record<string, [string, string, string]> = {
  Technology: ['#312E81', '#6366F1', '#A5B4FC'],
  Science: ['#064E3B', '#10B981', '#6EE7B7'],
  Fiction: ['#4C1D95', '#8B5CF6', '#C4B5FD'],
  Fantasy: ['#1E1B4B', '#7C3AED', '#DDD6FE'],
  History: ['#78350F', '#D97706', '#FDE68A'],
  Business: ['#1E3A8A', '#3B82F6', '#93C5FD'],
  Biography: ['#1E293B', '#475569', '#CBD5E1'],
  Mystery: ['#831843', '#EC4899', '#FBCFE8'],
  'Self-Help': ['#065F46', '#14B8A6', '#99F6E4'],
  'Non-Fiction': ['#0F172A', '#334155', '#94A3B8'],
  Education: ['#1D4ED8', '#60A5FA', '#BFDBFE'],
  Other: ['#374151', '#6B7280', '#D1D5DB'],
};

function AbstractBookCover({book}: {book: BookRecord}) {
  const [dark, mid, light] = GENRE_COVER_PALETTES[book.genre] ?? ['#1E1B4B', '#6366F1', '#C7D2FE'];
  let hash = 0;
  for (let i = 0; i < book.title.length; i++) {
    hash = (hash * 31 + book.title.charCodeAt(i)) % 1000;
  }
  const circleX = 180 + (hash % 60);
  const circleY = 25 + (hash % 45);
  const ringR = 44 + (hash % 24);

  return (
    <div
      className="relative h-36 p-4 flex flex-col justify-between overflow-hidden select-none"
      style={{background: `linear-gradient(135deg, ${dark} 0%, ${mid} 100%)`}}
    >
      <svg
        aria-hidden="true"
        viewBox="0 0 280 140"
        className="absolute inset-0 w-full h-full opacity-25 pointer-events-none"
      >
        <circle cx={circleX} cy={circleY} r={ringR} fill={light} />
        <circle cx={circleX - 42} cy={circleY + 60} r={ringR * 0.65} fill="none" stroke={light} strokeWidth="2" />
        <line x1="0" y1="115" x2="280" y2="85" stroke={light} strokeWidth="1" strokeOpacity="0.5" />
      </svg>

      <div className="relative z-10 flex items-center justify-between text-[11px] font-medium text-white/90">
        <span>{book.genre}</span>
        <span className="font-mono text-white/80">{book.pages.toLocaleString()}p</span>
      </div>

      <div className="relative z-10">
        <h4 className="text-sm font-bold text-white leading-snug line-clamp-2">{book.title}</h4>
        <p className="text-xs text-white/80 mt-0.5 truncate">{book.author}</p>
      </div>
    </div>
  );
}

export function LibraryView({
  books,
  settings,
  onSelectBook,
  onEditBook,
  onRequestDelete,
  onNavigate,
}: {
  books: BookRecord[];
  settings: AppSettings;
  onSelectBook: (book: BookRecord) => void;
  onEditBook: (book: BookRecord) => void;
  onRequestDelete: (book: BookRecord) => void;
  onNavigate: (section: NavSection) => void;
}) {
  const [query, setQuery] = useState('');
  const [genre, setGenre] = useState('All');
  const [status, setStatus] = useState('All');
  const [year, setYear] = useState('All');
  const [month, setMonth] = useState('All');
  const [sortBy, setSortBy] = useState<SortOption>('date_desc');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(settings.default_page_size || 12);

  const availableYears = useMemo(() => {
    const yrs = new Set<string>();
    books.forEach((b) => {
      const ref = b.completion_date || b.start_date;
      if (ref && /^\d{4}/.test(ref)) yrs.add(ref.slice(0, 4));
    });
    return Array.from(yrs).sort((a, b) => Number(b) - Number(a));
  }, [books]);

  const filtered = useMemo(() => {
    let list = [...books];
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      list = list.filter(
        (b) =>
          b.title.toLowerCase().includes(q) ||
          b.author.toLowerCase().includes(q) ||
          b.notes.toLowerCase().includes(q),
      );
    }
    if (genre !== 'All') list = list.filter((b) => b.genre === genre);
    if (status !== 'All') list = list.filter((b) => b.status === status);
    if (year !== 'All') {
      list = list.filter((b) => (b.completion_date || b.start_date).startsWith(`${year}-`));
    }
    if (month !== 'All') {
      list = list.filter((b) => (b.completion_date || b.start_date).slice(5, 7) === month);
    }

    list.sort((a, b) => {
      switch (sortBy) {
        case 'title_asc':
          return a.title.localeCompare(b.title);
        case 'title_desc':
          return b.title.localeCompare(a.title);
        case 'pages_desc':
          return b.pages - a.pages;
        case 'pages_asc':
          return a.pages - b.pages;
        case 'rating_desc':
          return (b.rating ?? -1) - (a.rating ?? -1);
        case 'date_asc':
          return (a.completion_date || a.start_date).localeCompare(
            b.completion_date || b.start_date,
          );
        case 'date_desc':
        default:
          return (b.completion_date || b.start_date).localeCompare(
            a.completion_date || a.start_date,
          );
      }
    });
    return list;
  }, [books, query, genre, status, year, month, sortBy]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const paginated = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  if (books.length === 0) {
    return (
      <div className="bg-white border border-[#E5E7EB] rounded-xl p-10 text-center max-w-xl mx-auto mt-6 shadow-[0_1px_2px_rgba(17,24,39,0.04)]">
        <h3 className="text-lg font-semibold text-[#111827]">No Stored Books</h3>
        <p className="text-sm text-[#64748B] mt-1.5">
          Your library is currently empty. Add a book or import a CSV dataset to populate this
          collection.
        </p>
        <button
          type="button"
          onClick={() => onNavigate('add-book')}
          className="mt-5 px-4 py-2 text-xs font-semibold text-white bg-[#6366F1] rounded-lg hover:bg-[#4F46E5] cursor-pointer"
        >
          Add a Book
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Filter & View Bar */}
      <div className="bg-white border border-[#E5E7EB] rounded-xl p-4 shadow-[0_1px_2px_rgba(17,24,39,0.04)] space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          <div className="md:col-span-4 relative">
            <Search className="w-4 h-4 text-[#64748B] absolute left-3 top-2.5" />
            <input
              type="text"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setPage(1);
              }}
              placeholder="Search title, author, or notes..."
              className="w-full pl-9 pr-3 py-2 text-sm border border-[#E5E7EB] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#6366F1]/20 focus:border-[#6366F1]"
            />
          </div>

          <div className="md:col-span-2">
            <select
              value={genre}
              onChange={(e) => {
                setGenre(e.target.value);
                setPage(1);
              }}
              className="w-full px-3 py-2 text-sm border border-[#E5E7EB] rounded-lg bg-white"
              aria-label="Filter by genre"
            >
              <option value="All">All Genres</option>
              {GENRES.map((g) => (
                <option key={g} value={g}>
                  {g}
                </option>
              ))}
            </select>
          </div>

          <div className="md:col-span-2">
            <select
              value={status}
              onChange={(e) => {
                setStatus(e.target.value);
                setPage(1);
              }}
              className="w-full px-3 py-2 text-sm border border-[#E5E7EB] rounded-lg bg-white"
              aria-label="Filter by status"
            >
              <option value="All">All Statuses</option>
              {READING_STATUSES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>

          <div className="md:col-span-2">
            <select
              value={year}
              onChange={(e) => {
                setYear(e.target.value);
                setPage(1);
              }}
              className="w-full px-3 py-2 text-sm border border-[#E5E7EB] rounded-lg bg-white"
              aria-label="Filter by year"
            >
              <option value="All">All Years</option>
              {availableYears.map((y) => (
                <option key={y} value={y}>
                  {y}
                </option>
              ))}
            </select>
          </div>

          <div className="md:col-span-2">
            <select
              value={month}
              onChange={(e) => {
                setMonth(e.target.value);
                setPage(1);
              }}
              className="w-full px-3 py-2 text-sm border border-[#E5E7EB] rounded-lg bg-white"
              aria-label="Filter by month"
            >
              <option value="All">All Months</option>
              {[
                '01 Jan',
                '02 Feb',
                '03 Mar',
                '04 Apr',
                '05 May',
                '06 Jun',
                '07 Jul',
                '08 Aug',
                '09 Sep',
                '10 Oct',
                '11 Nov',
                '12 Dec',
              ].map((label) => {
                const [val, name] = label.split(' ');
                return (
                  <option key={val} value={val}>
                    {name}
                  </option>
                );
              })}
            </select>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 text-xs text-[#64748B]">
          <div className="flex items-center gap-3">
            <span className="font-mono">
              Showing {paginated.length} of {filtered.length} books
            </span>
            {(query || genre !== 'All' || status !== 'All' || year !== 'All' || month !== 'All') && (
              <button
                type="button"
                onClick={() => {
                  setQuery('');
                  setGenre('All');
                  setStatus('All');
                  setYear('All');
                  setMonth('All');
                  setPage(1);
                }}
                className="text-[#6366F1] hover:underline font-medium cursor-pointer"
              >
                Reset Filters
              </button>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <label className="flex items-center gap-1.5">
              <span>Sort:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as SortOption)}
                className="px-2 py-1 border border-[#E5E7EB] rounded-md bg-white text-[#111827]"
              >
                <option value="date_desc">Date (Newest)</option>
                <option value="date_asc">Date (Oldest)</option>
                <option value="title_asc">Title (A–Z)</option>
                <option value="title_desc">Title (Z–A)</option>
                <option value="pages_desc">Pages (High–Low)</option>
                <option value="pages_asc">Pages (Low–High)</option>
                <option value="rating_desc">Rating (High–Low)</option>
              </select>
            </label>

            <label className="flex items-center gap-1.5">
              <span>Rows:</span>
              <select
                value={pageSize}
                onChange={(e) => {
                  setPageSize(Number(e.target.value));
                  setPage(1);
                }}
                className="px-2 py-1 border border-[#E5E7EB] rounded-md bg-white text-[#111827] font-mono"
              >
                {[9, 12, 18, 24, 50].map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            </label>

            <div className="inline-flex items-center p-0.5 bg-[#F5F7FB] border border-[#E5E7EB] rounded-lg">
              <button
                type="button"
                onClick={() => setViewMode('grid')}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                  viewMode === 'grid'
                    ? 'bg-white text-[#111827] shadow-xs'
                    : 'text-[#64748B] hover:text-[#111827]'
                }`}
                aria-label="Grid view"
              >
                <LayoutGrid className="w-3.5 h-3.5" />
                <span>Grid</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('list')}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                  viewMode === 'list'
                    ? 'bg-white text-[#111827] shadow-xs'
                    : 'text-[#64748B] hover:text-[#111827]'
                }`}
                aria-label="List view"
              >
                <List className="w-3.5 h-3.5" />
                <span>List</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Grid View */}
      {viewMode === 'grid' ? (
        <>
          {paginated.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {paginated.map((book) => (
                <div
                  key={book.id}
                  className="bg-white border border-[#E5E7EB] rounded-xl overflow-hidden shadow-[0_1px_2px_rgba(17,24,39,0.04)] hover:-translate-y-0.5 hover:shadow-md transition-all duration-150 flex flex-col"
                >
                  <div onClick={() => onSelectBook(book)} className="cursor-pointer">
                    <AbstractBookCover book={book} />
                  </div>
                  <div className="p-4 flex-1 flex flex-col justify-between gap-3">
                    <div className="space-y-1.5 text-xs text-[#64748B]">
                      <div className="flex items-center justify-between">
                        <span
                          className={`font-medium ${
                            book.status === 'Completed'
                              ? 'text-[#10B981]'
                              : book.status === 'Currently Reading'
                                ? 'text-[#6366F1]'
                                : 'text-[#64748B]'
                          }`}
                        >
                          {book.status}
                        </span>
                        <span className="inline-flex items-center gap-1 font-mono text-[#111827]">
                          <Star className="w-3.5 h-3.5 text-[#F59E0B] fill-[#F59E0B]" />
                          {book.rating !== null ? book.rating.toFixed(1) : '—'}
                        </span>
                      </div>
                      <div className="font-mono text-[#64748B]">
                        {book.completion_date
                          ? `Completed ${book.completion_date}`
                          : `Started ${book.start_date}`}
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                      <button
                        type="button"
                        onClick={() => onSelectBook(book)}
                        className="inline-flex items-center gap-1 text-xs font-medium text-[#6366F1] hover:text-[#4F46E5] cursor-pointer"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Details</span>
                      </button>
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => onEditBook(book)}
                          className="p-1.5 text-[#64748B] hover:text-[#6366F1] hover:bg-[#F5F7FB] rounded-md cursor-pointer"
                          title="Edit record"
                          aria-label={`Edit ${book.title}`}
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onRequestDelete(book)}
                          className="p-1.5 text-[#64748B] hover:text-[#EF4444] hover:bg-red-50 rounded-md cursor-pointer"
                          title="Delete record"
                          aria-label={`Delete ${book.title}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white border border-[#E5E7EB] rounded-xl p-8 text-center text-sm text-[#64748B]">
              No books match the current filters.
            </div>
          )}
        </>
      ) : (
        /* List View */
        <div className="bg-white border border-[#E5E7EB] rounded-xl overflow-hidden shadow-[0_1px_2px_rgba(17,24,39,0.04)]">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F5F7FB] text-xs font-medium text-[#64748B]">
                  <th className="py-2.5 px-4">Title</th>
                  <th className="py-2.5 px-4">Author</th>
                  <th className="py-2.5 px-4">Genre</th>
                  <th className="py-2.5 px-4 text-right">Pages</th>
                  <th className="py-2.5 px-4">Status</th>
                  <th className="py-2.5 px-4 text-right">Completed</th>
                  <th className="py-2.5 px-4 text-right">Rating</th>
                  <th className="py-2.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {paginated.map((book) => (
                  <tr key={book.id} className="hover:bg-[#F5F7FB]/80 transition-colors">
                    <td
                      onClick={() => onSelectBook(book)}
                      className="py-2.5 px-4 font-medium text-[#111827] cursor-pointer hover:text-[#6366F1]"
                    >
                      {book.title}
                    </td>
                    <td className="py-2.5 px-4 text-[#64748B]">{book.author}</td>
                    <td className="py-2.5 px-4 text-[#64748B]">{book.genre}</td>
                    <td className="py-2.5 px-4 text-right font-mono text-[#111827]">
                      {book.pages.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-4 text-xs font-medium">
                      <span
                        className={
                          book.status === 'Completed'
                            ? 'text-[#10B981]'
                            : book.status === 'Currently Reading'
                              ? 'text-[#6366F1]'
                              : 'text-[#64748B]'
                        }
                      >
                        {book.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono text-xs text-[#64748B]">
                      {book.completion_date ?? '-'}
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono text-xs text-[#111827]">
                      {book.rating !== null ? book.rating.toFixed(1) : '-'}
                    </td>
                    <td className="py-2.5 px-4 text-right">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => onSelectBook(book)}
                          className="p-1.5 text-[#64748B] hover:text-[#111827] hover:bg-[#F5F7FB] rounded cursor-pointer"
                          title="View details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onEditBook(book)}
                          className="p-1.5 text-[#64748B] hover:text-[#6366F1] hover:bg-[#F5F7FB] rounded cursor-pointer"
                          title="Edit record"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onRequestDelete(book)}
                          className="p-1.5 text-[#64748B] hover:text-[#EF4444] hover:bg-red-50 rounded cursor-pointer"
                          title="Delete record"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {paginated.length === 0 && (
                  <tr>
                    <td colSpan={8} className="py-8 text-center text-sm text-[#64748B]">
                      No books match the current filters.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Pagination Bar */}
      <div className="flex items-center justify-between px-4 py-3 bg-white border border-[#E5E7EB] rounded-xl text-xs text-[#64748B]">
        <span className="font-mono">
          Page {currentPage} of {totalPages}
        </span>
        <div className="flex items-center gap-2">
          <button
            type="button"
            disabled={currentPage <= 1}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            className="inline-flex items-center gap-1 px-3 py-1.5 bg-white border border-[#E5E7EB] rounded-lg hover:bg-slate-50 disabled:opacity-40 cursor-pointer text-[#111827]"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            <span>Previous</span>
          </button>
          <button
            type="button"
            disabled={currentPage >= totalPages}
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            className="inline-flex items-center gap-1 px-3 py-1.5 bg-white border border-[#E5E7EB] rounded-lg hover:bg-slate-50 disabled:opacity-40 cursor-pointer text-[#111827]"
          >
            <span>Next</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
