import React, {useState} from 'react';
import {
  AlertTriangle,
  BookCheck,
  Calendar,
  ChevronDown,
  ChevronUp,
  FileText,
  Flame,
  Info,
  Layers,
  PlusCircle,
  Ruler,
} from 'lucide-react';
import {AnalyticsPayload, AppSettings, BookRecord, NavSection} from '../types';
import {GenreDonutChart, MonthlyBooksBarChart, MonthlyPagesLineChart} from './Charts';

export function DashboardView({
  books,
  analytics,
  settings,
  onNavigate,
  onSelectBook,
  onLoadSample,
}: {
  books: BookRecord[];
  analytics: AnalyticsPayload;
  settings: AppSettings;
  onNavigate: (section: NavSection) => void;
  onSelectBook: (book: BookRecord) => void;
  onLoadSample: () => void;
}) {
  const [warningsExpanded, setWarningsExpanded] = useState(false);
  const {kpis, monthly, yearly, genres, insights, warnings, startup_warnings} = analytics;

  const todayFormatted = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  });

  const recentBooks = [...books]
    .sort((a, b) => (b.completion_date || b.start_date).localeCompare(a.completion_date || a.start_date))
    .slice(0, 7);

  // Real historical comparisons calculated from actual stored records (never invented)
  const prevMonth = monthly.length >= 2 ? monthly[monthly.length - 2] : null;
  const monthDiff = prevMonth ? kpis.books_this_month - prevMonth.books : null;

  const prevYear = yearly.length >= 2 ? yearly[yearly.length - 2] : null;
  const yearDiff = prevYear ? kpis.books_this_year - prevYear.books : null;

  if (books.length === 0) {
    return (
      <div className="space-y-6">
        {startup_warnings.length > 0 && (
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-900">
            {startup_warnings.map((w, i) => (
              <p key={i}>{w}</p>
            ))}
          </div>
        )}

        <div className="bg-white border border-[#E5E7EB] rounded-xl p-10 text-center max-w-2xl mx-auto mt-8 shadow-[0_1px_2px_rgba(17,24,39,0.04)]">
          <p className="text-xs font-medium text-[#6366F1] mb-2">{todayFormatted}</p>
          <h2 className="text-xl font-semibold text-[#111827]">Your Reading Library is Empty</h2>
          <p className="text-sm text-[#64748B] mt-2 leading-relaxed">
            Record your first book to populate monthly activity trends, page velocity metrics, and
            genre breakdowns, or load the bundled 40-book demonstration dataset.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3 mt-6">
            <button
              type="button"
              onClick={() => onNavigate('add-book')}
              className="px-4 py-2 text-sm font-semibold text-white bg-[#6366F1] rounded-lg hover:bg-[#4F46E5] transition-colors cursor-pointer"
            >
              Log First Book
            </button>
            <button
              type="button"
              onClick={onLoadSample}
              className="px-4 py-2 text-sm font-medium text-[#111827] bg-white border border-[#E5E7EB] rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
            >
              Load Sample Dataset (40 Books)
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Personalized Welcome Header */}
      <div className="bg-white border border-[#E5E7EB] rounded-xl px-6 py-5 shadow-[0_1px_2px_rgba(17,24,39,0.04)] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[#6366F1]">{todayFormatted}</p>
          <h2 className="text-2xl font-bold text-[#111827] tracking-tight mt-0.5">
            Welcome back to your Reading Analytics
          </h2>
          <p className="text-sm text-[#64748B] mt-1">
            Live overview of completed books, monthly page velocity, and genre distribution across{' '}
            <span className="font-mono font-medium text-[#111827]">{kpis.total_stored}</span> stored
            records.
          </p>
        </div>
        <button
          type="button"
          onClick={() => onNavigate('add-book')}
          className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-[#6366F1] rounded-lg hover:bg-[#4F46E5] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Log New Book</span>
        </button>
      </div>

      {startup_warnings.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-900 space-y-1">
          {startup_warnings.map((w, i) => (
            <p key={i}>{w}</p>
          ))}
        </div>
      )}

      {warnings.length > 0 && (
        <div className="bg-white border border-[#E5E7EB] rounded-xl shadow-[0_1px_2px_rgba(17,24,39,0.04)]">
          <button
            type="button"
            onClick={() => setWarningsExpanded((v) => !v)}
            className="w-full flex items-center justify-between px-5 py-3 text-left hover:bg-[#F5F7FB]/60 transition-colors rounded-xl cursor-pointer"
          >
            <div className="flex items-center gap-2.5 text-sm">
              <AlertTriangle className="w-4 h-4 text-[#F59E0B] shrink-0" />
              <span className="font-medium text-[#111827]">
                Active Threshold &amp; Data Quality Notices
              </span>
              <span className="text-slate-300">·</span>
              <span className="text-xs font-mono text-[#64748B]">{warnings.length} items</span>
            </div>
            {warningsExpanded ? (
              <ChevronUp className="w-4 h-4 text-[#64748B]" />
            ) : (
              <ChevronDown className="w-4 h-4 text-[#64748B]" />
            )}
          </button>
          {warningsExpanded && (
            <div className="border-t border-[#E5E7EB] divide-y divide-slate-100">
              {warnings.map((w, idx) => (
                <div key={idx} className="px-5 py-2.5 flex items-start gap-2.5 text-xs">
                  {w.severity === 'error' ? (
                    <AlertTriangle className="w-4 h-4 text-[#EF4444] shrink-0 mt-0.5" />
                  ) : w.severity === 'warning' ? (
                    <AlertTriangle className="w-4 h-4 text-[#F59E0B] shrink-0 mt-0.5" />
                  ) : (
                    <Info className="w-4 h-4 text-[#6366F1] shrink-0 mt-0.5" />
                  )}
                  <span className="font-mono text-[#64748B] shrink-0">{w.code}</span>
                  <span className="text-[#111827]">{w.message}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 6 Dynamic SaaS KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
        <div className="bg-white border border-[#E5E7EB] rounded-xl p-5 shadow-[0_1px_2px_rgba(17,24,39,0.04)] hover:-translate-y-0.5 hover:shadow-md transition-all duration-150">
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium text-[#64748B]">Total Books Read</p>
            <div className="w-8 h-8 rounded-lg bg-[#EEF2FF] text-[#6366F1] flex items-center justify-center">
              <BookCheck className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-bold text-[#111827] font-mono mt-2">
            {kpis.total_books_read}
          </p>
          <p className="text-xs text-[#64748B] mt-2">
            {kpis.currently_reading_count} currently reading · {kpis.planned_count} planned
          </p>
        </div>

        <div className="bg-white border border-[#E5E7EB] rounded-xl p-5 shadow-[0_1px_2px_rgba(17,24,39,0.04)] hover:-translate-y-0.5 hover:shadow-md transition-all duration-150">
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium text-[#64748B]">Total Pages Read</p>
            <div className="w-8 h-8 rounded-lg bg-[#F3E8FF] text-[#8B5CF6] flex items-center justify-center">
              <FileText className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-bold text-[#111827] font-mono mt-2">
            {kpis.total_pages_read.toLocaleString()}
          </p>
          <p className="text-xs text-[#64748B] mt-2">
            Across {kpis.total_books_read} completed books
          </p>
        </div>

        <div className="bg-white border border-[#E5E7EB] rounded-xl p-5 shadow-[0_1px_2px_rgba(17,24,39,0.04)] hover:-translate-y-0.5 hover:shadow-md transition-all duration-150">
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium text-[#64748B]">Average Pages per Book</p>
            <div className="w-8 h-8 rounded-lg bg-[#ECFDF5] text-[#10B981] flex items-center justify-center">
              <Ruler className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-bold text-[#111827] font-mono mt-2">
            {kpis.average_pages.toLocaleString()}
          </p>
          <p className="text-xs text-[#64748B] mt-2">
            Avg rating:{' '}
            {kpis.average_rating !== null ? `${kpis.average_rating.toFixed(2)} / 5.0` : 'Unrated'}
          </p>
        </div>

        <div className="bg-white border border-[#E5E7EB] rounded-xl p-5 shadow-[0_1px_2px_rgba(17,24,39,0.04)] hover:-translate-y-0.5 hover:shadow-md transition-all duration-150">
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium text-[#64748B]">Genres Explored</p>
            <div className="w-8 h-8 rounded-lg bg-[#EEF2FF] text-[#6366F1] flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-bold text-[#111827] font-mono mt-2">
            {kpis.genres_explored}
          </p>
          <p className="text-xs text-[#64748B] mt-2">
            {genres[0]
              ? `Top genre: ${genres[0].genre} (${genres[0].percentage}%)`
              : `${kpis.total_stored} total records`}
          </p>
        </div>

        <div className="bg-white border border-[#E5E7EB] rounded-xl p-5 shadow-[0_1px_2px_rgba(17,24,39,0.04)] hover:-translate-y-0.5 hover:shadow-md transition-all duration-150">
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium text-[#64748B]">
              Books This Month ({kpis.reference_month_label})
            </p>
            <div className="w-8 h-8 rounded-lg bg-[#FEF3C7] text-[#F59E0B] flex items-center justify-center">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-bold text-[#111827] font-mono mt-2">
            {kpis.books_this_month}
          </p>
          <p className="text-xs text-[#64748B] mt-2">
            {kpis.pages_this_month.toLocaleString()} pages · Target {settings.monthly_book_target}
            {prevMonth !== null && monthDiff !== null && (
              <span
                className={`ml-1.5 font-medium ${
                  monthDiff >= 0 ? 'text-[#10B981]' : 'text-[#64748B]'
                }`}
              >
                ({monthDiff >= 0 ? '+' : ''}
                {monthDiff} vs {prevMonth.label})
              </span>
            )}
          </p>
        </div>

        <div className="bg-white border border-[#E5E7EB] rounded-xl p-5 shadow-[0_1px_2px_rgba(17,24,39,0.04)] hover:-translate-y-0.5 hover:shadow-md transition-all duration-150">
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium text-[#64748B]">
              Reading Activity ({kpis.reference_year})
            </p>
            <div className="w-8 h-8 rounded-lg bg-[#ECFDF5] text-[#10B981] flex items-center justify-center">
              <Flame className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-bold text-[#111827] font-mono mt-2">
            {kpis.books_this_year}{' '}
            <span className="text-base font-normal text-[#64748B]">books</span>
          </p>
          <p className="text-xs text-[#64748B] mt-2">
            {kpis.pages_this_year.toLocaleString()} pages
            {prevYear !== null && yearDiff !== null && (
              <span
                className={`ml-1.5 font-medium ${
                  yearDiff >= 0 ? 'text-[#10B981]' : 'text-[#64748B]'
                }`}
              >
                ({yearDiff >= 0 ? '+' : ''}
                {yearDiff} vs {prevYear.year})
              </span>
            )}
          </p>
        </div>
      </div>

      {/* Charts A & B */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <MonthlyBooksBarChart data={monthly} limit={12} />
        <MonthlyPagesLineChart data={monthly} limit={12} />
      </div>

      {/* Chart C + Insights E */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7">
          <GenreDonutChart data={genres} />
        </div>
        <div className="lg:col-span-5 bg-white border border-[#E5E7EB] rounded-xl p-5 shadow-[0_1px_2px_rgba(17,24,39,0.04)] flex flex-col">
          <h3 className="text-base font-semibold text-[#111827] tracking-tight">
            Reading Insights
          </h3>
          <p className="text-xs text-[#64748B] mt-0.5 mb-4">
            Observations calculated directly from stored records
          </p>
          <ul className="space-y-3 text-sm text-slate-700 leading-relaxed flex-1">
            {insights.observations.map((obs, idx) => (
              <li key={idx} className="pb-3 border-b border-slate-100 last:border-b-0 last:pb-0">
                {obs}
              </li>
            ))}
          </ul>
          <div className="pt-4 mt-4 border-t border-[#E5E7EB] flex items-center justify-between text-xs">
            <span className="text-[#64748B]">Monthly Avg Pace</span>
            <span className="font-mono font-semibold text-[#111827]">
              {insights.avg_books_per_active_month} books ·{' '}
              {insights.avg_pages_per_active_month.toLocaleString()} pages/mo
            </span>
          </div>
        </div>
      </div>

      {/* D. Recent Reading Activity */}
      <div className="bg-white border border-[#E5E7EB] rounded-xl shadow-[0_1px_2px_rgba(17,24,39,0.04)] overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#E5E7EB]">
          <div>
            <h3 className="text-base font-semibold text-[#111827] tracking-tight">
              Recent Activity
            </h3>
            <p className="text-xs text-[#64748B] mt-0.5">
              Latest books recorded or completed; click any row to inspect details
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('library')}
            className="text-xs font-semibold text-[#6366F1] hover:text-[#4F46E5] whitespace-nowrap shrink-0 cursor-pointer"
          >
            View All Library
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F5F7FB] text-xs font-medium text-[#64748B]">
                <th className="py-2.5 px-5">Book Title</th>
                <th className="py-2.5 px-4">Author</th>
                <th className="py-2.5 px-4">Genre</th>
                <th className="py-2.5 px-4 text-right">Pages</th>
                <th className="py-2.5 px-4">Status</th>
                <th className="py-2.5 px-5 text-right">Completion Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {recentBooks.map((book) => (
                <tr
                  key={book.id}
                  onClick={() => onSelectBook(book)}
                  className="hover:bg-[#F5F7FB]/80 transition-colors cursor-pointer"
                >
                  <td className="py-2.5 px-5 font-medium text-[#111827]">{book.title}</td>
                  <td className="py-2.5 px-4 text-[#64748B]">{book.author}</td>
                  <td className="py-2.5 px-4 text-[#64748B]">{book.genre}</td>
                  <td className="py-2.5 px-4 text-right font-mono text-[#111827]">
                    {book.pages.toLocaleString()}
                  </td>
                  <td className="py-2.5 px-4 text-xs font-medium">
                    <span
                      className={
                        book.status === 'Completed'
                          ? 'text-[#10B981]'
                          : book.status === 'Currently Reading'
                            ? 'text-[#6366F1]'
                            : 'text-[#64748B]'
                      }
                    >
                      {book.status}
                    </span>
                  </td>
                  <td className="py-2.5 px-5 text-right font-mono text-xs text-[#64748B]">
                    {book.completion_date ?? 'In Progress'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
