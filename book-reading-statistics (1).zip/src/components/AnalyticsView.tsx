import React from 'react';
import {AnalyticsPayload, BookRecord, NavSection} from '../types';
import {
  GenreDonutChart,
  MonthlyBooksBarChart,
  MonthlyPagesLineChart,
  StatusDistributionChart,
  YearlyComparisonChart,
} from './Charts';

export function AnalyticsView({
  books,
  analytics,
  onNavigate,
}: {
  books: BookRecord[];
  analytics: AnalyticsPayload;
  onNavigate: (section: NavSection) => void;
}) {
  const {kpis, monthly, yearly, genres, statuses, insights} = analytics;

  if (books.length === 0) {
    return (
      <div className="bg-white border border-[#E5E7EB] rounded-xl p-10 text-center max-w-xl mx-auto mt-6 shadow-[0_1px_2px_rgba(17,24,39,0.04)]">
        <h3 className="text-lg font-semibold text-[#111827]">No Analytics Available Yet</h3>
        <p className="text-sm text-[#64748B] mt-1.5">
          Statistics and trend visualizations remain hidden when the database is empty to prevent
          misleading metrics. Add a book or load sample records to begin.
        </p>
        <button
          type="button"
          onClick={() => onNavigate('add-book')}
          className="mt-5 px-4 py-2 text-xs font-semibold text-white bg-[#6366F1] rounded-lg hover:bg-[#4F46E5] cursor-pointer"
        >
          Add a Book
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-white border border-[#E5E7EB] rounded-xl p-4 shadow-[0_1px_2px_rgba(17,24,39,0.04)]">
          <p className="text-xs text-[#64748B]">Completed Books</p>
          <p className="text-2xl font-bold text-[#111827] font-mono mt-1">
            {kpis.total_books_read}
          </p>
        </div>
        <div className="bg-white border border-[#E5E7EB] rounded-xl p-4 shadow-[0_1px_2px_rgba(17,24,39,0.04)]">
          <p className="text-xs text-[#64748B]">Total Pages Read</p>
          <p className="text-2xl font-bold text-[#111827] font-mono mt-1">
            {kpis.total_pages_read.toLocaleString()}
          </p>
        </div>
        <div className="bg-white border border-[#E5E7EB] rounded-xl p-4 shadow-[0_1px_2px_rgba(17,24,39,0.04)]">
          <p className="text-xs text-[#64748B]">Avg Pages / Book</p>
          <p className="text-2xl font-bold text-[#111827] font-mono mt-1">{kpis.average_pages}</p>
        </div>
        <div className="bg-white border border-[#E5E7EB] rounded-xl p-4 shadow-[0_1px_2px_rgba(17,24,39,0.04)]">
          <p className="text-xs text-[#64748B]">Avg Books / Active Month</p>
          <p className="text-2xl font-bold text-[#111827] font-mono mt-1">
            {insights.avg_books_per_active_month}
          </p>
        </div>
        <div className="bg-white border border-[#E5E7EB] rounded-xl p-4 shadow-[0_1px_2px_rgba(17,24,39,0.04)] col-span-2 lg:col-span-1">
          <p className="text-xs text-[#64748B]">Most Productive Month</p>
          <p className="text-lg font-bold text-[#111827] font-mono mt-1">
            {insights.most_productive_month ? `${insights.most_productive_month.label}` : 'N/A'}
          </p>
          {insights.most_productive_month && (
            <p className="text-xs text-[#64748B] font-mono">
              {insights.most_productive_month.books} bks ·{' '}
              {insights.most_productive_month.pages.toLocaleString()} p
            </p>
          )}
        </div>
      </div>

      {/* Charts 1 & 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <MonthlyBooksBarChart data={monthly} limit={24} />
        <MonthlyPagesLineChart data={monthly} limit={24} />
      </div>

      {/* Charts 3 & 4 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <GenreDonutChart data={genres} />
        <YearlyComparisonChart data={yearly} />
      </div>

      {/* Chart 5 + Yearly Breakdown Table */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <StatusDistributionChart data={statuses} />

        <div className="bg-white border border-[#E5E7EB] rounded-xl overflow-hidden shadow-[0_1px_2px_rgba(17,24,39,0.04)]">
          <div className="px-5 py-4 border-b border-[#E5E7EB]">
            <h3 className="text-base font-semibold text-[#111827] tracking-tight">
              Yearly Reading Totals
            </h3>
            <p className="text-xs text-[#64748B] mt-0.5">
              Completed books, cumulative pages, and average book length per year
            </p>
          </div>
          {yearly.length > 0 ? (
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F5F7FB] text-xs font-medium text-[#64748B]">
                  <th className="py-2.5 px-5">Year</th>
                  <th className="py-2.5 px-4 text-right">Completed</th>
                  <th className="py-2.5 px-4 text-right">Total Pages</th>
                  <th className="py-2.5 px-5 text-right">Avg Pages</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm font-mono">
                {yearly.map((y) => (
                  <tr key={y.year}>
                    <td className="py-2.5 px-5 font-semibold text-[#111827]">{y.year}</td>
                    <td className="py-2.5 px-4 text-right text-[#64748B]">{y.books}</td>
                    <td className="py-2.5 px-4 text-right text-[#111827]">
                      {y.pages.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-5 text-right text-[#64748B]">{y.avg_pages}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p className="p-6 text-sm text-[#64748B]">No completed yearly records yet.</p>
          )}
        </div>
      </div>
    </div>
  );
}
