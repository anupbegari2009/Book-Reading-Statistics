import React, {useMemo, useState} from 'react';
import {Search, X} from 'lucide-react';
import {BookRecord, GENRES, READING_STATUSES} from '../types';

export function SearchFilterView({
  books,
  onSelectBook,
  onExportSubsetCsv,
}: {
  books: BookRecord[];
  onSelectBook: (book: BookRecord) => void;
  onExportSubsetCsv: (subset: BookRecord[]) => void;
}) {
  const [titleQuery, setTitleQuery] = useState('');
  const [authorQuery, setAuthorQuery] = useState('');
  const [genre, setGenre] = useState('All');
  const [status, setStatus] = useState('All');
  const [compFrom, setCompFrom] = useState('');
  const [compTo, setCompTo] = useState('');
  const [minPages, setMinPages] = useState('');
  const [maxPages, setMaxPages] = useState('');

  const clearFilters = () => {
    setTitleQuery('');
    setAuthorQuery('');
    setGenre('All');
    setStatus('All');
    setCompFrom('');
    setCompTo('');
    setMinPages('');
    setMaxPages('');
  };

  const results = useMemo(() => {
    return books.filter((b) => {
      if (titleQuery.trim() && !b.title.toLowerCase().includes(titleQuery.trim().toLowerCase())) {
        return false;
      }
      if (authorQuery.trim() && !b.author.toLowerCase().includes(authorQuery.trim().toLowerCase())) {
        return false;
      }
      if (genre !== 'All' && b.genre !== genre) return false;
      if (status !== 'All' && b.status !== status) return false;
      if (compFrom && (!b.completion_date || b.completion_date < compFrom)) return false;
      if (compTo && (!b.completion_date || b.completion_date > compTo)) return false;
      if (minPages.trim() !== '' && !Number.isNaN(Number(minPages))) {
        if (b.pages < Number(minPages)) return false;
      }
      if (maxPages.trim() !== '' && !Number.isNaN(Number(maxPages))) {
        if (b.pages > Number(maxPages)) return false;
      }
      return true;
    });
  }, [books, titleQuery, authorQuery, genre, status, compFrom, compTo, minPages, maxPages]);

  const totalMatchingPages = results.reduce((sum, b) => sum + b.pages, 0);

  return (
    <div className="space-y-6">
      <div className="bg-white border border-[#E5E7EB] rounded-xl p-6 shadow-[0_1px_2px_rgba(17,24,39,0.04)]">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <h2 className="text-lg font-semibold text-[#111827] tracking-tight">
              Multi-Criteria Search &amp; Filter
            </h2>
            <p className="text-sm text-[#64748B] mt-0.5">
              Combine title, author, genre, reading status, completion date window, and page count
              ranges.
            </p>
          </div>
          <button
            type="button"
            onClick={clearFilters}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#111827] bg-[#F5F7FB] border border-[#E5E7EB] rounded-lg hover:bg-slate-100 cursor-pointer"
          >
            <X className="w-3.5 h-3.5 text-[#64748B]" />
            <span>Clear Filters</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-medium text-[#111827] mb-1.5">Book Title</label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-[#64748B] absolute left-3 top-2.5" />
              <input
                type="text"
                value={titleQuery}
                onChange={(e) => setTitleQuery(e.target.value)}
                placeholder="Search title..."
                className="w-full pl-8 pr-3 py-2 text-sm border border-[#E5E7EB] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#6366F1]/20 focus:border-[#6366F1]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-[#111827] mb-1.5">Author Name</label>
            <input
              type="text"
              value={authorQuery}
              onChange={(e) => setAuthorQuery(e.target.value)}
              placeholder="Search author..."
              className="w-full px-3 py-2 text-sm border border-[#E5E7EB] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#6366F1]/20 focus:border-[#6366F1]"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#111827] mb-1.5">Genre</label>
            <select
              value={genre}
              onChange={(e) => setGenre(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-[#E5E7EB] rounded-lg bg-white"
            >
              <option value="All">All Genres</option>
              {GENRES.map((g) => (
                <option key={g} value={g}>
                  {g}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-[#111827] mb-1.5">
              Reading Status
            </label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-[#E5E7EB] rounded-lg bg-white"
            >
              <option value="All">All Statuses</option>
              {READING_STATUSES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-[#111827] mb-1.5">
              Completed From
            </label>
            <input
              type="date"
              value={compFrom}
              onChange={(e) => setCompFrom(e.target.value)}
              className="w-full px-3 py-2 text-sm font-mono border border-[#E5E7EB] rounded-lg"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#111827] mb-1.5">Completed To</label>
            <input
              type="date"
              value={compTo}
              onChange={(e) => setCompTo(e.target.value)}
              className="w-full px-3 py-2 text-sm font-mono border border-[#E5E7EB] rounded-lg"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#111827] mb-1.5">Min Pages</label>
            <input
              type="number"
              min={0}
              value={minPages}
              onChange={(e) => setMinPages(e.target.value)}
              placeholder="e.g. 200"
              className="w-full px-3 py-2 text-sm font-mono border border-[#E5E7EB] rounded-lg"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#111827] mb-1.5">Max Pages</label>
            <input
              type="number"
              min={0}
              value={maxPages}
              onChange={(e) => setMaxPages(e.target.value)}
              placeholder="e.g. 600"
              className="w-full px-3 py-2 text-sm font-mono border border-[#E5E7EB] rounded-lg"
            />
          </div>
        </div>
      </div>

      <div className="bg-white border border-[#E5E7EB] rounded-xl overflow-hidden shadow-[0_1px_2px_rgba(17,24,39,0.04)]">
        <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3.5 border-b border-[#E5E7EB]">
          <div className="text-sm text-[#64748B]">
            Matched <span className="font-mono font-semibold text-[#111827]">{results.length}</span>{' '}
            record(s) ·{' '}
            <span className="font-mono font-semibold text-[#111827]">
              {totalMatchingPages.toLocaleString()}
            </span>{' '}
            total pages
          </div>
          {results.length > 0 && (
            <button
              type="button"
              onClick={() => onExportSubsetCsv(results)}
              className="px-3 py-1.5 text-xs font-semibold text-[#6366F1] bg-[#EEF2FF] border border-[#6366F1]/25 rounded-lg hover:bg-indigo-100/70 cursor-pointer"
            >
              Export Filtered CSV
            </button>
          )}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F5F7FB] text-xs font-medium text-[#64748B]">
                <th className="py-2.5 px-5">Title</th>
                <th className="py-2.5 px-4">Author</th>
                <th className="py-2.5 px-4">Genre</th>
                <th className="py-2.5 px-4 text-right">Pages</th>
                <th className="py-2.5 px-4">Status</th>
                <th className="py-2.5 px-4 text-right">Completed</th>
                <th className="py-2.5 px-5 text-right">Rating</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {results.map((b) => (
                <tr
                  key={b.id}
                  onClick={() => onSelectBook(b)}
                  className="hover:bg-[#F5F7FB]/80 transition-colors cursor-pointer"
                >
                  <td className="py-2.5 px-5 font-medium text-[#111827]">{b.title}</td>
                  <td className="py-2.5 px-4 text-[#64748B]">{b.author}</td>
                  <td className="py-2.5 px-4 text-[#64748B]">{b.genre}</td>
                  <td className="py-2.5 px-4 text-right font-mono text-[#111827]">
                    {b.pages.toLocaleString()}
                  </td>
                  <td className="py-2.5 px-4 text-xs font-medium text-[#111827]">{b.status}</td>
                  <td className="py-2.5 px-4 text-right font-mono text-xs text-[#64748B]">
                    {b.completion_date ?? '-'}
                  </td>
                  <td className="py-2.5 px-5 text-right font-mono text-xs text-[#111827]">
                    {b.rating !== null ? b.rating.toFixed(1) : '-'}
                  </td>
                </tr>
              ))}
              {results.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-sm text-[#64748B]">
                    No records matched the active search criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
