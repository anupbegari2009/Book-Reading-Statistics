"""Book Reading Statistics — Premium SaaS Analytics Workspace (Streamlit)."""

from __future__ import annotations

import hashlib
import html
from datetime import date, datetime
from pathlib import Path
from typing import Optional

import streamlit as st

from modules.analytics import (
    compute_dashboard_kpis,
    compute_genre_distribution,
    compute_monthly_series,
    compute_reading_insights,
    compute_status_distribution,
    compute_yearly_comparison,
    detect_threshold_warnings,
)
from modules.book_manager import BookManager, FilterCriteria, paginate_books
from modules.exports import (
    export_books_to_csv,
    export_books_to_json,
    export_markdown_report,
    export_plain_text_audit,
)
from modules.imports import import_csv_content
from modules.models import GENRES, READING_STATUSES, AppSettings, BookRecord
from modules.storage import (
    DEFAULT_BOOKS_PATH,
    DEFAULT_SETTINGS_PATH,
    SAMPLE_CSV_PATH,
    load_settings,
    save_settings,
)
from modules.validation import parse_iso_date
from modules.visualizations import (
    build_genre_distribution_matplotlib,
    build_monthly_books_matplotlib,
    build_monthly_pages_matplotlib,
    build_plotly_genre_donut,
    build_plotly_monthly_activity,
    build_plotly_monthly_pages,
    build_plotly_status_distribution,
    build_plotly_yearly_comparison,
    build_status_distribution_matplotlib,
    build_yearly_comparison_matplotlib,
    dependency_status,
)

APP_DIR = Path(__file__).resolve().parent
CSS_PATH = APP_DIR / "assets" / "styles.css"

NAV_ITEMS: list[tuple[str, str]] = [
    ("Dashboard", "📊  Dashboard"),
    ("Add a Book", "➕  Add a Book"),
    ("My Library", "📚  My Library"),
    ("Reading Analytics", "📈  Reading Analytics"),
    ("Search & Filter", "🔍  Search & Filter"),
    ("Import Dataset", "📥  Import Dataset"),
    ("Export Reports", "📤  Export Reports"),
    ("Settings", "⚙️  Settings"),
]

NAV_KEYS = [item[0] for item in NAV_ITEMS]
NAV_LABELS = {key: label for key, label in NAV_ITEMS}

GENRE_COVER_THEMES: dict[str, tuple[str, str]] = {
    "Technology": ("#312E81", "#6366F1"),
    "Science": ("#064E3B", "#10B981"),
    "Fiction": ("#4C1D95", "#8B5CF6"),
    "Fantasy": ("#1E1B4B", "#7C3AED"),
    "History": ("#78350F", "#D97706"),
    "Business": ("#1E3A8A", "#3B82F6"),
    "Biography": ("#334155", "#64748B"),
    "Mystery": ("#831843", "#EC4899"),
    "Self-Help": ("#065F46", "#14B8A6"),
    "Non-Fiction": ("#0F172A", "#475569"),
    "Education": ("#1D4ED8", "#60A5FA"),
    "Other": ("#374151", "#6B7280"),
}


def load_custom_css() -> None:
    if CSS_PATH.exists():
        st.markdown(f"<style>{CSS_PATH.read_text(encoding='utf-8')}</style>", unsafe_allow_html=True)


def get_manager() -> BookManager:
    settings = load_settings(DEFAULT_SETTINGS_PATH)
    return BookManager(books_path=DEFAULT_BOOKS_PATH, settings=settings)


def render_page_header(title: str, subtitle: str, show_quick_add: bool = False) -> None:
    today_label = datetime.now().strftime("%A, %B %d, %Y")
    col_h, col_btn = st.columns([4.5, 1.2]) if show_quick_add else (st.container(), None)
    with col_h:
        st.markdown(
            f"""
            <div class="saas-header">
                <div class="saas-header-date">{html.escape(today_label)}</div>
                <h1 class="saas-header-title">{html.escape(title)}</h1>
                <div class="saas-header-sub">{html.escape(subtitle)}</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    if show_quick_add and col_btn is not None:
        with col_btn:
            st.write("")
            if st.button("＋ Add Book", type="primary", use_container_width=True, key="header_quick_add"):
                st.session_state["nav_page"] = "Add a Book"
                st.rerun()


def render_kpi_card(label: str, value: str, meta: str, icon: str, delta_html: str = "") -> None:
    st.markdown(
        f"""
        <div class="kpi-card">
            <div class="kpi-card-top">
                <span class="kpi-label">{html.escape(label)}</span>
                <span class="kpi-icon-box">{icon}</span>
            </div>
            <div class="kpi-value">{html.escape(value)}</div>
            <div class="kpi-meta">{html.escape(meta)} {delta_html}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_warnings_banner(manager: BookManager) -> None:
    for msg in manager.startup_warnings:
        st.warning(msg)

    warnings = detect_threshold_warnings(manager.books, settings=manager.settings)
    if warnings:
        with st.expander(f"Active Threshold & Data Quality Notices ({len(warnings)})", expanded=False):
            for w in warnings:
                if w.severity == "error":
                    st.error(f"[{w.code}] {w.message}")
                elif w.severity == "warning":
                    st.warning(f"[{w.code}] {w.message}")
                else:
                    st.info(f"[{w.code}] {w.message}")


def render_chart_with_fallback(
    plotly_builder: Any,
    matplotlib_builder: Any,
    books: list[BookRecord],
    fallback_title: str,
) -> None:
    deps = dependency_status()
    if deps["plotly"]:
        p_fig, p_err = plotly_builder(books)
        if p_fig is not None:
            st.plotly_chart(p_fig, use_container_width=True)
            return
        if p_err:
            st.info(p_err)
            return

    if deps["matplotlib"]:
        m_fig, _, m_err = matplotlib_builder(books)
        if m_fig is not None:
            st.pyplot(m_fig)
            return
        if m_err:
            st.info(m_err)
            return

    st.info(f"{fallback_title}: Install `plotly` or `matplotlib` to render visual charts.")


def render_cover_card_html(book: BookRecord) -> str:
    c1, c2 = GENRE_COVER_THEMES.get(book.genre, ("#1E293B", "#6366F1"))
    digest = int(hashlib.md5(book.title.encode("utf-8")).hexdigest()[:4], 16)
    angle = 120 + (digest % 50)
    rating_txt = f"★ {book.rating:.1f}" if book.rating is not None else "Unrated"
    comp_txt = book.completion_date or book.status
    return f"""
    <div class="book-grid-card">
        <div class="book-cover-banner" style="background: linear-gradient({angle}deg, {c1}, {c2});">
            <div class="book-cover-genre">{html.escape(book.genre)} · {html.escape(book.status)}</div>
            <div class="book-cover-title">{html.escape(book.title)}</div>
        </div>
        <div class="book-grid-body">
            <div class="book-grid-author">{html.escape(book.author)}</div>
            <div class="book-grid-meta">{book.pages:,} pages · {html.escape(rating_txt)} · {html.escape(comp_txt)}</div>
        </div>
    </div>
    """


def render_dashboard(manager: BookManager) -> None:
    render_page_header(
        "Welcome back to your Reading Analytics",
        "Track completed books, page velocity, genre balance, and historical momentum from your local library.",
        show_quick_add=True,
    )

    books = manager.books
    kpis = compute_dashboard_kpis(books)
    insights = compute_reading_insights(books)
    monthly = compute_monthly_series(books)
    yearly = compute_yearly_comparison(books)

    if not books:
        st.markdown(
            """
            <div class="surface-card">
                <h3 class="surface-card-title">Your library is currently empty</h3>
                <p class="surface-card-sub">Log your first book or load the 40-book demonstration dataset to explore live analytics.</p>
            </div>
            """,
            unsafe_allow_html=True,
        )
        c1, c2 = st.columns(2)
        with c1:
            if st.button("Load Sample Dataset (40 Books)", type="primary", use_container_width=True):
                added, _ = manager.load_demo_dataset()
                st.success(f"Loaded {added} sample records.")
                st.rerun()
        with c2:
            if st.button("Add Your First Book", use_container_width=True):
                st.session_state["nav_page"] = "Add a Book"
                st.rerun()
        return

    # Real historical comparisons (only shown when real prior data exists)
    month_delta_html = ""
    if len(monthly) >= 2:
        prev_month = monthly[-2]
        diff = kpis["books_this_month"] - prev_month["books"]
        sign = "+" if diff > 0 else ""
        cls = "kpi-delta-pos" if diff >= 0 else "kpi-delta-neutral"
        month_delta_html = f'<span class="{cls}">({sign}{diff} vs {html.escape(prev_month["label"])})</span>'

    year_delta_html = ""
    if len(yearly) >= 2:
        prev_year = yearly[-2]
        diff_y = kpis["books_this_year"] - prev_year["books"]
        sign_y = "+" if diff_y > 0 else ""
        cls_y = "kpi-delta-pos" if diff_y >= 0 else "kpi-delta-neutral"
        year_delta_html = f'<span class="{cls_y}">({sign_y}{diff_y} vs {prev_year["year"]})</span>'

    r1c1, r1c2, r1c3 = st.columns(3)
    with r1c1:
        render_kpi_card(
            "Total Books Read",
            f"{kpis['total_books_read']}",
            f"{kpis['currently_reading_count']} reading · {kpis['planned_count']} planned",
            "📘",
        )
    with r1c2:
        render_kpi_card(
            "Total Pages Read",
            f"{kpis['total_pages_read']:,}",
            f"Across {kpis['total_books_read']} completed books",
            "📄",
        )
    with r1c3:
        rating_meta = (
            f"Avg rating {kpis['average_rating']:.2f} / 5.0"
            if kpis["average_rating"] is not None
            else "No ratings logged yet"
        )
        render_kpi_card(
            "Average Pages per Book",
            f"{kpis['average_pages']}",
            rating_meta,
            "📏",
        )

    r2c1, r2c2, r2c3 = st.columns(3)
    with r2c1:
        render_kpi_card(
            "Genres Explored",
            f"{kpis['genres_explored']}",
            f"{kpis['total_stored']} total records stored",
            "🏷️",
        )
    with r2c2:
        render_kpi_card(
            f"Books This Month ({kpis['reference_month_label']})",
            f"{kpis['books_this_month']}",
            f"{kpis['pages_this_month']:,} pages",
            "📅",
            month_delta_html,
        )
    with r2c3:
        render_kpi_card(
            f"Reading Activity ({kpis['reference_year']})",
            f"{kpis['books_this_year']} books",
            f"{kpis['pages_this_year']:,} pages",
            "⚡",
            year_delta_html,
        )

    col_left, col_right = st.columns(2)
    with col_left:
        st.markdown('<div class="surface-card">', unsafe_allow_html=True)
        render_chart_with_fallback(
            build_plotly_monthly_activity,
            build_monthly_books_matplotlib,
            books,
            "Monthly Reading Activity",
        )
        st.markdown("</div>", unsafe_allow_html=True)

    with col_right:
        st.markdown('<div class="surface-card">', unsafe_allow_html=True)
        render_chart_with_fallback(
            build_plotly_monthly_pages,
            build_monthly_pages_matplotlib,
            books,
            "Reading Progress",
        )
        st.markdown("</div>", unsafe_allow_html=True)

    col_genre, col_insights = st.columns([1.2, 1])
    with col_genre:
        st.markdown('<div class="surface-card">', unsafe_allow_html=True)
        render_chart_with_fallback(
            build_plotly_genre_donut,
            build_genre_distribution_matplotlib,
            books,
            "Genre Distribution",
        )
        st.markdown("</div>", unsafe_allow_html=True)

    with col_insights:
        items_html = "".join(f"<li style='margin-bottom:0.55rem;'>{html.escape(obs)}</li>" for obs in insights["observations"])
        st.markdown(
            f"""
            <div class="surface-card">
                <h3 class="surface-card-title">Reading Insights</h3>
                <p class="surface-card-sub">Observations computed directly from your local dataset</p>
                <ul style="padding-left:1.1rem; color:#334155; font-size:0.86rem; line-height:1.55;">
                    {items_html}
                </ul>
            </div>
            """,
            unsafe_allow_html=True,
        )

    st.markdown('<div class="surface-card"><h3 class="surface-card-title">Recent Reading Activity</h3><p class="surface-card-sub">Latest books logged or completed</p>', unsafe_allow_html=True)
    recent = manager.filter_books(sort_by="date_desc")[:8]
    rows = [
        {
            "Title": b.title,
            "Author": b.author,
            "Genre": b.genre,
            "Pages": b.pages,
            "Status": b.status,
            "Completion Date": b.completion_date or "In Progress",
            "Rating": f"{b.rating:.1f}" if b.rating is not None else "-",
        }
        for b in recent
    ]
    st.dataframe(rows, use_container_width=True, hide_index=True)
    st.markdown("</div>", unsafe_allow_html=True)


def render_add_book(manager: BookManager) -> None:
    render_page_header(
        "Add a Book",
        "Structured book entry with real-time validation, date checks, and duplicate detection.",
    )

    with st.form("add_book_form", clear_on_submit=False):
        st.markdown("#### 1. Book Identification")
        c1, c2 = st.columns(2)
        with c1:
            title = st.text_input("Book Title *", placeholder="e.g., Designing Data-Intensive Applications")
            genre = st.selectbox("Genre *", list(GENRES))
        with c2:
            author = st.text_input("Author Name *", placeholder="e.g., Martin Kleppmann")
            pages_input = st.text_input("Total Pages *", value="320")

        st.divider()
        st.markdown("#### 2. Reading Progress & Timeline")
        c3, c4 = st.columns(2)
        with c3:
            status = st.selectbox("Reading Status *", list(READING_STATUSES))
            start_date_val = st.date_input("Start Date *", value=date.today())
        with c4:
            has_completion = st.checkbox("Include Completion Date", value=(status == "Completed"))
            completion_date_val = st.date_input("Completion Date", value=date.today())

        st.divider()
        st.markdown("#### 3. Rating & Reflection")
        rating_input = st.text_input(
            f"Personal Rating ({manager.settings.rating_min:g} - {manager.settings.rating_max:g}, optional)",
            value="4.5",
        )
        notes = st.text_area("Optional Notes", placeholder="Key takeaways, themes, or reading context...")
        allow_dup = st.checkbox("Allow duplicate title + author if intentionally re-reading", value=False)
        submitted = st.form_submit_button("Save Book Record", type="primary")

    if submitted:
        payload = {
            "title": title,
            "author": author,
            "genre": genre,
            "pages": pages_input,
            "status": status,
            "start_date": start_date_val.strftime("%Y-%m-%d"),
            "completion_date": completion_date_val.strftime("%Y-%m-%d") if (has_completion or status == "Completed") else "",
            "rating": rating_input,
            "notes": notes,
        }
        ok, errors, created = manager.add_book(payload, allow_duplicate=allow_dup)
        if not ok:
            for err in errors:
                st.error(err)
        elif created is not None:
            st.success(f"Saved '{created.title}' by {created.author} ({created.pages:,} pages) to local storage.")


def render_my_library(manager: BookManager) -> None:
    render_page_header(
        "My Library",
        "Explore your collection in Grid or List view, inspect details, edit records, or delete with confirmation.",
    )

    books = manager.books
    if not books:
        st.info("No books in your library yet. Visit 'Add a Book' or load the sample dataset from Settings.")
        return

    col_q, col_g, col_s, col_sort, col_view = st.columns([2, 1, 1, 1.2, 1])
    query = col_q.text_input("Search title or author", placeholder="Filter by title, author, or notes...")
    genre = col_g.selectbox("Genre", ["All", *GENRES])
    status = col_s.selectbox("Status", ["All", *READING_STATUSES])
    sort_by = col_sort.selectbox(
        "Sort By",
        [
            ("date_desc", "Newest First"),
            ("date_asc", "Oldest First"),
            ("title_asc", "Title (A-Z)"),
            ("pages_desc", "Pages (High-Low)"),
            ("pages_asc", "Pages (Low-High)"),
            ("rating_desc", "Rating (High-Low)"),
        ],
        format_func=lambda opt: opt[1],
    )[0]
    view_mode = col_view.radio("View", ["Grid", "List"], horizontal=True)

    years = sorted(
        {
            int((b.completion_date or b.start_date)[:4])
            for b in books
            if parse_iso_date(b.completion_date or b.start_date) is not None
        },
        reverse=True,
    )
    col_y, col_m, col_ps = st.columns(3)
    selected_year = col_y.selectbox("Year", ["All", *[str(y) for y in years]])
    selected_month = col_m.selectbox("Month", ["All", *[f"{m:02d}" for m in range(1, 13)]])
    page_size = col_ps.selectbox("Items per Page", [9, 12, 18, 30], index=1)

    criteria = FilterCriteria(
        query=query,
        genre=genre,
        status=status,
        year=int(selected_year) if selected_year != "All" else None,
        month=int(selected_month) if selected_month != "All" else None,
    )
    filtered = manager.filter_books(criteria=criteria, sort_by=sort_by)

    total_pages = max(1, (len(filtered) + page_size - 1) // page_size)
    current_page = st.number_input("Page", min_value=1, max_value=total_pages, value=1, step=1)
    paginated = paginate_books(filtered, page=int(current_page), page_size=int(page_size))

    st.caption(f"Showing **{len(paginated.items)}** of **{paginated.total_items}** matching books (Page {paginated.page}/{paginated.total_pages}).")

    if view_mode == "Grid":
        cols_per_row = 3
        for idx in range(0, len(paginated.items), cols_per_row):
            row_books = paginated.items[idx : idx + cols_per_row]
            cols = st.columns(cols_per_row)
            for col_idx, b in enumerate(row_books):
                with cols[col_idx]:
                    st.markdown(render_cover_card_html(b), unsafe_allow_html=True)
                    if st.button("Inspect / Manage", key=f"select_card_{b.id}", use_container_width=True):
                        st.session_state["library_selected_id"] = b.id
    else:
        table_rows = [
            {
                "ID": b.id,
                "Title": b.title,
                "Author": b.author,
                "Genre": b.genre,
                "Pages": b.pages,
                "Status": b.status,
                "Start": b.start_date,
                "Completed": b.completion_date or "-",
                "Rating": f"{b.rating:.1f}" if b.rating is not None else "-",
            }
            for b in paginated.items
        ]
        st.dataframe(table_rows, use_container_width=True, hide_index=True)

    if filtered:
        st.divider()
        filtered_ids = [b.id for b in filtered]
        default_sel_idx = 0
        if st.session_state.get("library_selected_id") in filtered_ids:
            default_sel_idx = filtered_ids.index(st.session_state["library_selected_id"])

        selected_id = st.selectbox(
            "Selected Book Inspector (View Details, Edit, or Delete)",
            options=filtered_ids,
            index=default_sel_idx,
            format_func=lambda bid: next(f"{b.title} — {b.author} ({b.status})" for b in filtered if b.id == bid),
        )
        selected_book = manager.get_by_id(selected_id)
        if selected_book:
            tab_view, tab_edit, tab_delete = st.tabs(["Book Details", "Edit Record", "Delete Record"])
            with tab_view:
                st.markdown(f"### {selected_book.title}")
                st.write(
                    f"**Author:** {selected_book.author}  |  **Genre:** {selected_book.genre}  |  "
                    f"**Pages:** {selected_book.pages:,}  |  **Status:** {selected_book.status}"
                )
                st.write(
                    f"**Start Date:** {selected_book.start_date}  |  "
                    f"**Completion Date:** {selected_book.completion_date or 'N/A'}  |  "
                    f"**Rating:** {selected_book.rating if selected_book.rating is not None else 'Unrated'}"
                )
                if selected_book.notes:
                    st.info(selected_book.notes)

            with tab_edit:
                with st.form(f"edit_form_{selected_book.id}"):
                    ec1, ec2 = st.columns(2)
                    with ec1:
                        e_title = st.text_input("Title", value=selected_book.title)
                        e_author = st.text_input("Author", value=selected_book.author)
                        e_genre = st.selectbox(
                            "Genre",
                            list(GENRES),
                            index=list(GENRES).index(selected_book.genre) if selected_book.genre in GENRES else 0,
                        )
                        e_pages = st.text_input("Pages", value=str(selected_book.pages))
                    with ec2:
                        e_status = st.selectbox(
                            "Status",
                            list(READING_STATUSES),
                            index=list(READING_STATUSES).index(selected_book.status) if selected_book.status in READING_STATUSES else 0,
                        )
                        e_start = st.text_input("Start Date (YYYY-MM-DD)", value=selected_book.start_date)
                        e_comp = st.text_input("Completion Date (YYYY-MM-DD)", value=selected_book.completion_date or "")
                        e_rating = st.text_input("Rating", value="" if selected_book.rating is None else str(selected_book.rating))
                    e_notes = st.text_area("Notes", value=selected_book.notes)
                    if st.form_submit_button("Update Book", type="primary"):
                        ok, errs, _ = manager.update_book(
                            selected_book.id,
                            {
                                "title": e_title,
                                "author": e_author,
                                "genre": e_genre,
                                "pages": e_pages,
                                "status": e_status,
                                "start_date": e_start,
                                "completion_date": e_comp,
                                "rating": e_rating,
                                "notes": e_notes,
                            },
                        )
                        if not ok:
                            for err in errs:
                                st.error(err)
                        else:
                            st.success("Book record updated.")
                            st.rerun()

            with tab_delete:
                st.warning(f"Deleting '{selected_book.title}' removes it permanently from {manager.books_path.name}.")
                confirm = st.checkbox("Confirm permanent deletion", key=f"del_confirm_{selected_book.id}")
                if st.button("Delete Book", type="primary", disabled=not confirm, key=f"del_btn_{selected_book.id}"):
                    ok, msg = manager.delete_book(selected_book.id)
                    if ok:
                        st.success(msg)
                        st.rerun()
                    else:
                        st.error(msg)


def render_analytics(manager: BookManager) -> None:
    render_page_header(
        "Reading Analytics",
        "Deep-dive monthly performance, multi-year comparisons, genre composition, and reading status trends.",
    )

    books = manager.books
    if not books:
        st.info("No stored data to analyze yet. Add books or load the sample dataset first.")
        return

    kpis = compute_dashboard_kpis(books)
    insights = compute_reading_insights(books)
    monthly = compute_monthly_series(books)
    yearly = compute_yearly_comparison(books)
    genres = compute_genre_distribution(books, completed_only=True)
    statuses = compute_status_distribution(books)

    a1, a2, a3, a4 = st.columns(4)
    with a1:
        render_kpi_card("Completed Books", f"{kpis['total_books_read']}", "Finished titles", "📘")
    with a2:
        render_kpi_card("Total Pages Read", f"{kpis['total_pages_read']:,}", f"Avg {kpis['average_pages']} p/book", "📄")
    with a3:
        render_kpi_card("Avg Books / Month", f"{insights['avg_books_per_active_month']}", "Across active months", "📈")
    with a4:
        top_month = insights["most_productive_month"]["label"] if insights["most_productive_month"] else "N/A"
        render_kpi_card("Top Reading Month", top_month, "Highest completion volume", "🏆")

    ch1, ch2 = st.columns(2)
    with ch1:
        st.markdown('<div class="surface-card">', unsafe_allow_html=True)
        render_chart_with_fallback(
            lambda b: build_plotly_monthly_activity(b, limit=24),
            build_monthly_books_matplotlib,
            books,
            "Monthly Books Completed",
        )
        st.markdown("</div>", unsafe_allow_html=True)

    with ch2:
        st.markdown('<div class="surface-card">', unsafe_allow_html=True)
        render_chart_with_fallback(
            lambda b: build_plotly_monthly_pages(b, limit=24),
            build_monthly_pages_matplotlib,
            books,
            "Monthly Pages Read",
        )
        st.markdown("</div>", unsafe_allow_html=True)

    ch3, ch4 = st.columns(2)
    with ch3:
        st.markdown('<div class="surface-card">', unsafe_allow_html=True)
        render_chart_with_fallback(
            build_plotly_genre_donut,
            build_genre_distribution_matplotlib,
            books,
            "Genre Distribution",
        )
        st.markdown("</div>", unsafe_allow_html=True)

    with ch4:
        st.markdown('<div class="surface-card">', unsafe_allow_html=True)
        render_chart_with_fallback(
            build_plotly_yearly_comparison,
            build_yearly_comparison_matplotlib,
            books,
            "Yearly Reading Comparison",
        )
        st.markdown("</div>", unsafe_allow_html=True)

    st.markdown('<div class="surface-card">', unsafe_allow_html=True)
    render_chart_with_fallback(
        build_plotly_status_distribution,
        build_status_distribution_matplotlib,
        books,
        "Reading Status Distribution",
    )
    st.markdown("</div>", unsafe_allow_html=True)

    with st.expander("Detailed Statistical Tables"):
        st.write("**Yearly Summary**")
        st.dataframe(yearly, use_container_width=True, hide_index=True)
        st.write("**Genre Summary**")
        st.dataframe(genres, use_container_width=True, hide_index=True)
        st.write("**Status Summary**")
        st.dataframe(statuses, use_container_width=True, hide_index=True)
        st.write("**Monthly Totals**")
        st.dataframe(monthly, use_container_width=True, hide_index=True)


def render_search_filter(manager: BookManager) -> None:
    render_page_header(
        "Search & Filter",
        "Combine title, author, genre, status, completion date window, and page count filters.",
    )

    if "sf_query" not in st.session_state:
        st.session_state["sf_query"] = ""

    with st.form("search_filter_form"):
        c1, c2, c3 = st.columns(3)
        query = c1.text_input("Title or Author Keyword", key="sf_query")
        genre = c2.selectbox("Genre", ["All", *GENRES], key="sf_genre")
        status = c3.selectbox("Reading Status", ["All", *READING_STATUSES], key="sf_status")

        c4, c5, c6, c7 = st.columns(4)
        comp_from = c4.text_input("Completed From (YYYY-MM-DD)", key="sf_from")
        comp_to = c5.text_input("Completed To (YYYY-MM-DD)", key="sf_to")
        min_pages = c6.number_input("Min Pages", min_value=0, value=0, step=50, key="sf_min_p")
        max_pages = c7.number_input("Max Pages (0 = no cap)", min_value=0, value=0, step=100, key="sf_max_p")

        b1, b2 = st.columns([1, 4])
        b1.form_submit_button("Apply Filters", type="primary")
        clear_btn = b2.form_submit_button("Clear Filters")

    if clear_btn:
        for key in ("sf_query", "sf_from", "sf_to"):
            st.session_state[key] = ""
        st.session_state["sf_genre"] = "All"
        st.session_state["sf_status"] = "All"
        st.session_state["sf_min_p"] = 0
        st.session_state["sf_max_p"] = 0
        st.rerun()

    criteria = FilterCriteria(
        query=query,
        genre=genre,
        status=status,
        completion_date_from=comp_from or None,
        completion_date_to=comp_to or None,
        min_pages=int(min_pages) if min_pages > 0 else None,
        max_pages=int(max_pages) if max_pages > 0 else None,
    )
    matches = manager.filter_books(criteria=criteria, sort_by="date_desc")
    total_pages = sum(b.pages for b in matches)
    st.write(f"Found **{len(matches)}** matching record(s) totaling **{total_pages:,}** pages.")
    if matches:
        st.dataframe(
            [
                {
                    "Title": b.title,
                    "Author": b.author,
                    "Genre": b.genre,
                    "Pages": b.pages,
                    "Status": b.status,
                    "Start Date": b.start_date,
                    "Completion Date": b.completion_date or "-",
                    "Rating": f"{b.rating:.1f}" if b.rating is not None else "-",
                }
                for b in matches
            ],
            use_container_width=True,
            hide_index=True,
        )
    else:
        st.info("No records matched the selected criteria.")


def render_import_dataset(manager: BookManager) -> None:
    render_page_header(
        "Import Dataset",
        "Drag-and-drop CSV upload with schema checks, duplicate detection, and row-level diagnostics.",
    )

    uploaded = st.file_uploader("Upload CSV File", type=["csv"])
    skip_dups = st.checkbox("Skip duplicate records (recommended)", value=True)

    if uploaded is not None:
        size_kb = round(len(uploaded.getvalue()) / 1024, 1)
        st.info(f"File ready: **{uploaded.name}** ({size_kb} KB)")

    if SAMPLE_CSV_PATH.exists():
        st.download_button(
            "Download Sample CSV Template",
            data=SAMPLE_CSV_PATH.read_text(encoding="utf-8"),
            file_name="sample_books.csv",
            mime="text/csv",
        )

    if uploaded is not None and st.button("Run CSV Import", type="primary"):
        try:
            csv_text = uploaded.getvalue().decode("utf-8-sig")
        except UnicodeDecodeError:
            st.error("Unable to decode uploaded CSV as UTF-8.")
            return
        header_ok, header_err, summary = import_csv_content(csv_text, manager, skip_duplicates=skip_dups)
        if not header_ok:
            st.error(header_err or "Invalid CSV file.")
            return

        m1, m2, m3, m4 = st.columns(4)
        with m1:
            render_kpi_card("Total Rows", str(summary.total_rows), "Processed", "📄")
        with m2:
            render_kpi_card("Imported", str(summary.imported_count), "Added to library", "✅")
        with m3:
            render_kpi_card("Duplicates Skipped", str(summary.duplicate_count), "Already existed", "⚠️")
        with m4:
            render_kpi_card("Failed Rows", str(summary.failed_count), "Validation errors", "❌")

        if summary.imported_count > 0:
            st.success(f"Successfully imported {summary.imported_count} book(s).")
        if summary.errors:
            st.subheader("Row-by-Row Import Notices")
            st.dataframe(
                [{"Row": e.row_number, "Title": e.title, "Reason": e.reason} for e in summary.errors],
                use_container_width=True,
                hide_index=True,
            )


def render_export_reports(manager: BookManager) -> None:
    render_page_header(
        "Export Reports",
        "Generate structured datasets, Markdown executive briefs, audit reports, and chart PNGs.",
    )

    scope = st.radio("Export Scope", ["All Stored Books", "Completed Books Only"], horizontal=True)
    books = manager.books if scope == "All Stored Books" else [b for b in manager.books if b.status == "Completed"]

    st.caption(f"Selected dataset contains **{len(books)}** record(s).")

    c1, c2, c3, c4 = st.columns(4)
    c1.download_button(
        "Download CSV",
        data=export_books_to_csv(books),
        file_name="book_reading_statistics.csv",
        mime="text/csv",
        use_container_width=True,
    )
    c2.download_button(
        "Download JSON",
        data=export_books_to_json(books),
        file_name="book_reading_statistics.json",
        mime="application/json",
        use_container_width=True,
    )
    c3.download_button(
        "Download Markdown",
        data=export_markdown_report(books),
        file_name="reading_summary_report.md",
        mime="text/markdown",
        use_container_width=True,
    )
    c4.download_button(
        "Download Audit TXT",
        data=export_plain_text_audit(books),
        file_name="reading_audit_report.txt",
        mime="text/plain",
        use_container_width=True,
    )

    st.divider()
    st.subheader("Export Charts as PNG")
    chart_builders = [
        ("Monthly Books Completed", "monthly_books.png", build_monthly_books_matplotlib),
        ("Monthly Pages Read", "monthly_pages.png", build_monthly_pages_matplotlib),
        ("Genre Distribution", "genre_distribution.png", build_genre_distribution_matplotlib),
        ("Yearly Comparison", "yearly_comparison.png", build_yearly_comparison_matplotlib),
    ]
    cols = st.columns(2)
    for idx, (label, filename, builder) in enumerate(chart_builders):
        with cols[idx % 2]:
            _, png_bytes, err = builder(books)
            if png_bytes:
                st.download_button(
                    f"Download {label} (PNG)",
                    data=png_bytes,
                    file_name=filename,
                    mime="image/png",
                    use_container_width=True,
                )
            else:
                st.info(f"{label}: {err}")


def render_settings(manager: BookManager) -> None:
    render_page_header(
        "Settings",
        "Configure reading goals, warning thresholds, library behavior, and local storage management.",
    )

    s = manager.settings
    with st.form("settings_form"):
        st.markdown("#### Reading Goals")
        g1, g2 = st.columns(2)
        monthly_books = g1.number_input("Monthly Book Target", min_value=1, max_value=50, value=s.monthly_book_target)
        monthly_pages = g2.number_input("Monthly Page Target", min_value=50, max_value=10000, value=s.monthly_page_target, step=50)

        st.divider()
        st.markdown("#### Warning Configuration")
        high_pages = st.number_input("High Page Count Warning Threshold", min_value=100, max_value=5000, value=s.high_page_threshold, step=50)

        st.divider()
        st.markdown("#### Library Preferences")
        l1, l2 = st.columns(2)
        page_size = l1.number_input("Default Library Page Size", min_value=5, max_value=100, value=s.default_page_size)
        strict_dup = l2.checkbox("Strict Duplicate Prevention (block matching title + author)", value=s.strict_duplicate_check)

        if st.form_submit_button("Save Settings", type="primary"):
            updated = AppSettings(
                monthly_book_target=int(monthly_books),
                monthly_page_target=int(monthly_pages),
                high_page_threshold=int(high_pages),
                rating_min=s.rating_min,
                rating_max=s.rating_max,
                strict_duplicate_check=bool(strict_dup),
                default_page_size=int(page_size),
            )
            save_settings(updated, DEFAULT_SETTINGS_PATH)
            st.success("Settings saved.")
            st.rerun()

    st.markdown(
        f"""
        <div class="surface-card">
            <h3 class="surface-card-title">Storage &amp; Database Controls</h3>
            <p class="surface-card-sub">Database path: <code>{html.escape(str(DEFAULT_BOOKS_PATH))}</code> · Active records: <strong>{len(manager.books)}</strong></p>
        </div>
        """,
        unsafe_allow_html=True,
    )
    d1, d2 = st.columns(2)
    with d1:
        if st.button("Load Sample Dataset (Merge Non-Duplicates)", use_container_width=True):
            added, skipped = manager.load_demo_dataset(replace_existing=False)
            st.success(f"Added {added} sample books ({skipped} duplicates skipped).")
            st.rerun()
    with d2:
        confirm_clear = st.checkbox("Confirm clearing all stored books")
        if st.button("Clear All Books (Empty Database)", disabled=not confirm_clear, use_container_width=True):
            manager.clear_all_books()
            st.success("Database cleared.")
            st.rerun()


def main() -> None:
    st.set_page_config(
        page_title="Book Reading Statistics",
        page_icon="📚",
        layout="wide",
        initial_sidebar_state="expanded",
    )
    load_custom_css()
    manager = get_manager()

    with st.sidebar:
        st.markdown(
            """
            <div class="sidebar-brand">
                <div class="sidebar-brand-title">📚 Book Reading Statistics</div>
                <div class="sidebar-brand-sub">Personal Reading Analytics</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        st.markdown('<div class="sidebar-section-label">Workspace</div>', unsafe_allow_html=True)

        current_key = st.session_state.get("nav_page", "Dashboard")
        if current_key not in NAV_KEYS:
            current_key = "Dashboard"
        default_idx = NAV_KEYS.index(current_key)

        selected_label = st.radio(
            "Navigation",
            [NAV_LABELS[k] for k in NAV_KEYS],
            index=default_idx,
            label_visibility="collapsed",
        )
        page = next(k for k, lbl in NAV_LABELS.items() if lbl == selected_label)
        st.session_state["nav_page"] = page

        completed_count = sum(1 for b in manager.books if b.status == "Completed")
        st.markdown(
            f"""
            <div class="sidebar-footer-card">
                <div class="sidebar-footer-row">
                    <span>Stored Books</span>
                    <span class="sidebar-footer-val">{len(manager.books)}</span>
                </div>
                <div class="sidebar-footer-row">
                    <span>Completed</span>
                    <span class="sidebar-footer-val">{completed_count}</span>
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    render_warnings_banner(manager)

    if page == "Dashboard":
        render_dashboard(manager)
    elif page == "Add a Book":
        render_add_book(manager)
    elif page == "My Library":
        render_my_library(manager)
    elif page == "Reading Analytics":
        render_analytics(manager)
    elif page == "Search & Filter":
        render_search_filter(manager)
    elif page == "Import Dataset":
        render_import_dataset(manager)
    elif page == "Export Reports":
        render_export_reports(manager)
    elif page == "Settings":
        render_settings(manager)


if __name__ == "__main__":
    main()
