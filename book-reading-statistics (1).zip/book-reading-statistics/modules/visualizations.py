"""Interactive Plotly and Matplotlib chart builders with graceful missing-dependency fallbacks."""

from __future__ import annotations

import io
from typing import Any, Optional

from .analytics import (
    compute_genre_distribution,
    compute_monthly_series,
    compute_status_distribution,
    compute_yearly_comparison,
)
from .models import BookRecord

try:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    MATPLOTLIB_AVAILABLE = True
except ImportError:
    plt = None  # type: ignore[assignment]
    MATPLOTLIB_AVAILABLE = False

try:
    import plotly.graph_objects as go

    PLOTLY_AVAILABLE = True
except ImportError:
    go = None  # type: ignore[assignment]
    PLOTLY_AVAILABLE = False

SAAS_PALETTE = [
    "#6366F1",  # Primary Indigo
    "#8B5CF6",  # Secondary Violet
    "#10B981",  # Emerald
    "#F59E0B",  # Amber
    "#3B82F6",  # Blue
    "#EC4899",  # Rose
    "#14B8A6",  # Teal
    "#64748B",  # Slate
    "#0EA5E9",  # Sky
    "#F97316",  # Orange
]


def dependency_status() -> dict[str, bool]:
    """Report availability of optional plotting libraries."""
    return {
        "matplotlib": MATPLOTLIB_AVAILABLE,
        "plotly": PLOTLY_AVAILABLE,
    }


def _fig_to_png_bytes(fig: Any) -> bytes:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=180, bbox_inches="tight", facecolor="#FFFFFF")
    plt.close(fig)
    buf.seek(0)
    return buf.getvalue()


def _apply_plotly_saas_theme(fig: Any, title: str, height: int = 340) -> Any:
    fig.update_layout(
        title=dict(text=title, font=dict(family="Inter, sans-serif", size=15, color="#111827"), x=0.01),
        font=dict(family="Inter, sans-serif", size=12, color="#64748B"),
        plot_bgcolor="#FFFFFF",
        paper_bgcolor="#FFFFFF",
        height=height,
        margin=dict(l=44, r=20, t=48, b=44),
        hoverlabel=dict(bgcolor="#111827", font_color="#FFFFFF", font_family="Inter, sans-serif"),
    )
    fig.update_xaxes(showgrid=False, linecolor="#E5E7EB", tickfont=dict(color="#64748B"))
    fig.update_yaxes(gridcolor="#F1F5F9", zerolinecolor="#E5E7EB", tickfont=dict(color="#64748B"))
    return fig


def build_monthly_books_matplotlib(books: list[BookRecord]) -> tuple[Optional[Any], Optional[bytes], Optional[str]]:
    """Build Matplotlib bar chart of monthly books completed and return (fig, png_bytes, error)."""
    if not MATPLOTLIB_AVAILABLE:
        return None, None, "Matplotlib is not installed. Run `pip install matplotlib` to render static PNG charts."
    series = compute_monthly_series(books)
    if not series:
        return None, None, "No completed books with valid completion dates to plot."

    recent = series[-12:]
    labels = [row["label"] for row in recent]
    values = [row["books"] for row in recent]

    fig, ax = plt.subplots(figsize=(8.5, 4.2))
    bars = ax.bar(labels, values, color="#6366F1", width=0.56)
    ax.set_title("Monthly Books Completed", fontsize=12, fontweight="bold", color="#111827", pad=12)
    ax.set_ylabel("Books Completed", fontsize=10, color="#64748B")
    ax.yaxis.get_major_locator().set_params(integer=True)
    ax.grid(axis="y", linestyle="--", alpha=0.45, color="#E5E7EB")
    ax.set_axisbelow(True)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color("#E5E7EB")
    ax.spines["bottom"].set_color("#E5E7EB")
    plt.xticks(rotation=30, ha="right", fontsize=8.5, color="#64748B")

    for bar in bars:
        height = bar.get_height()
        ax.annotate(
            f"{int(height)}",
            xy=(bar.get_x() + bar.get_width() / 2, height),
            xytext=(0, 4),
            textcoords="offset points",
            ha="center",
            fontsize=8.5,
            color="#111827",
        )

    png_bytes = _fig_to_png_bytes(fig)
    return fig, png_bytes, None


def build_monthly_pages_matplotlib(books: list[BookRecord]) -> tuple[Optional[Any], Optional[bytes], Optional[str]]:
    """Build Matplotlib line chart of monthly pages read."""
    if not MATPLOTLIB_AVAILABLE:
        return None, None, "Matplotlib is not installed. Run `pip install matplotlib` to render static PNG charts."
    series = compute_monthly_series(books)
    if not series:
        return None, None, "No completed books with valid completion dates to plot."

    recent = series[-12:]
    labels = [row["label"] for row in recent]
    pages = [row["pages"] for row in recent]

    fig, ax = plt.subplots(figsize=(8.5, 4.2))
    ax.plot(labels, pages, marker="o", linewidth=2.4, color="#8B5CF6", markersize=6)
    ax.fill_between(range(len(labels)), pages, color="#8B5CF6", alpha=0.12)
    ax.set_title("Pages Read Over Time", fontsize=12, fontweight="bold", color="#111827", pad=12)
    ax.set_ylabel("Pages Read", fontsize=10, color="#64748B")
    ax.grid(axis="y", linestyle="--", alpha=0.45, color="#E5E7EB")
    ax.set_axisbelow(True)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color("#E5E7EB")
    ax.spines["bottom"].set_color("#E5E7EB")
    plt.xticks(rotation=30, ha="right", fontsize=8.5, color="#64748B")

    png_bytes = _fig_to_png_bytes(fig)
    return fig, png_bytes, None


def build_genre_distribution_matplotlib(books: list[BookRecord]) -> tuple[Optional[Any], Optional[bytes], Optional[str]]:
    """Build Matplotlib donut chart of genre distribution."""
    if not MATPLOTLIB_AVAILABLE:
        return None, None, "Matplotlib is not installed. Run `pip install matplotlib` to render static PNG charts."
    dist = compute_genre_distribution(books, completed_only=True)
    if not dist:
        return None, None, "No completed books available for genre distribution."

    labels = [row["genre"] for row in dist]
    counts = [row["count"] for row in dist]
    colors = [SAAS_PALETTE[i % len(SAAS_PALETTE)] for i in range(len(labels))]

    fig, ax = plt.subplots(figsize=(7.2, 4.5))
    _, _, autotexts = ax.pie(
        counts,
        labels=labels,
        autopct="%1.1f%%",
        startangle=140,
        colors=colors,
        pctdistance=0.78,
        wedgeprops={"width": 0.42, "edgecolor": "#FFFFFF", "linewidth": 1.8},
        textprops={"fontsize": 8.5, "color": "#111827"},
    )
    for autotext in autotexts:
        autotext.set_color("#FFFFFF")
        autotext.set_fontsize(8)
        autotext.set_fontweight("bold")
    ax.set_title("Genre Distribution (Completed Books)", fontsize=12, fontweight="bold", color="#111827", pad=10)

    png_bytes = _fig_to_png_bytes(fig)
    return fig, png_bytes, None


def build_yearly_comparison_matplotlib(books: list[BookRecord]) -> tuple[Optional[Any], Optional[bytes], Optional[str]]:
    """Build Matplotlib bar chart comparing books and pages across years."""
    if not MATPLOTLIB_AVAILABLE:
        return None, None, "Matplotlib is not installed. Run `pip install matplotlib` to render static PNG charts."
    yearly = compute_yearly_comparison(books)
    if not yearly:
        return None, None, "No yearly reading records available."

    years = [str(row["year"]) for row in yearly]
    book_counts = [row["books"] for row in yearly]
    page_counts = [row["pages"] for row in yearly]

    fig, ax1 = plt.subplots(figsize=(8.0, 4.2))
    x = range(len(years))
    ax1.bar([i - 0.18 for i in x], book_counts, width=0.35, color="#6366F1", label="Books Completed")
    ax1.set_ylabel("Books Completed", color="#6366F1", fontsize=10)
    ax1.set_xticks(list(x))
    ax1.set_xticklabels(years, fontsize=9.5)
    ax1.spines["top"].set_visible(False)

    ax2 = ax1.twinx()
    ax2.bar([i + 0.18 for i in x], page_counts, width=0.35, color="#10B981", label="Total Pages")
    ax2.set_ylabel("Total Pages", color="#10B981", fontsize=10)
    ax2.spines["top"].set_visible(False)

    ax1.set_title("Yearly Reading Comparison", fontsize=12, fontweight="bold", color="#111827", pad=12)
    png_bytes = _fig_to_png_bytes(fig)
    return fig, png_bytes, None


def build_status_distribution_matplotlib(books: list[BookRecord]) -> tuple[Optional[Any], Optional[bytes], Optional[str]]:
    """Build Matplotlib horizontal bar chart of reading statuses."""
    if not MATPLOTLIB_AVAILABLE:
        return None, None, "Matplotlib is not installed. Run `pip install matplotlib` to render static PNG charts."
    dist = compute_status_distribution(books)
    if not dist:
        return None, None, "No books stored yet."

    statuses = [row["status"] for row in dist]
    counts = [row["count"] for row in dist]
    colors = ["#10B981", "#6366F1", "#94A3B8"]

    fig, ax = plt.subplots(figsize=(7.5, 3.4))
    bars = ax.barh(statuses, counts, color=colors[: len(statuses)], height=0.52)
    ax.set_title("Reading Status Breakdown", fontsize=12, fontweight="bold", color="#111827", pad=10)
    ax.set_xlabel("Book Count", fontsize=10, color="#64748B")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    for bar in bars:
        width = bar.get_width()
        ax.annotate(
            f"{int(width)}",
            xy=(width, bar.get_y() + bar.get_height() / 2),
            xytext=(5, 0),
            textcoords="offset points",
            va="center",
            fontsize=9,
            color="#111827",
        )

    png_bytes = _fig_to_png_bytes(fig)
    return fig, png_bytes, None


def build_plotly_monthly_activity(books: list[BookRecord], limit: int = 12) -> tuple[Optional[Any], Optional[str]]:
    """Interactive Plotly bar chart for monthly completed books."""
    if not PLOTLY_AVAILABLE:
        return None, "Plotly is not installed. Displaying Matplotlib chart fallback."
    series = compute_monthly_series(books)[-limit:]
    if not series:
        return None, "No completed books available to plot."
    fig = go.Figure(
        data=[
            go.Bar(
                x=[row["label"] for row in series],
                y=[row["books"] for row in series],
                customdata=[row["pages"] for row in series],
                marker_color="#6366F1",
                marker_line_width=0,
                hovertemplate="<b>%{x}</b><br>Books: %{y}<br>Pages: %{customdata:,}<extra></extra>",
            )
        ]
    )
    _apply_plotly_saas_theme(fig, "Monthly Reading Activity")
    fig.update_yaxes(dtick=1, title_text="Books")
    return fig, None


def build_plotly_monthly_pages(books: list[BookRecord], limit: int = 12) -> tuple[Optional[Any], Optional[str]]:
    """Interactive Plotly area/line chart for monthly pages read."""
    if not PLOTLY_AVAILABLE:
        return None, "Plotly is not installed. Displaying Matplotlib chart fallback."
    series = compute_monthly_series(books)[-limit:]
    if not series:
        return None, "No completed books available to plot."
    fig = go.Figure(
        data=[
            go.Scatter(
                x=[row["label"] for row in series],
                y=[row["pages"] for row in series],
                customdata=[row["books"] for row in series],
                mode="lines+markers",
                line=dict(color="#8B5CF6", width=2.8),
                marker=dict(size=7, color="#6366F1", line=dict(width=1.5, color="#FFFFFF")),
                fill="tozeroy",
                fillcolor="rgba(139, 92, 246, 0.12)",
                hovertemplate="<b>%{x}</b><br>Pages: %{y:,}<br>Books: %{customdata}<extra></extra>",
            )
        ]
    )
    _apply_plotly_saas_theme(fig, "Reading Progress (Pages Over Time)")
    fig.update_yaxes(title_text="Pages")
    return fig, None


def build_plotly_genre_donut(books: list[BookRecord]) -> tuple[Optional[Any], Optional[str]]:
    """Interactive Plotly donut chart for genre distribution."""
    if not PLOTLY_AVAILABLE:
        return None, "Plotly is not installed. Displaying Matplotlib chart fallback."
    dist = compute_genre_distribution(books, completed_only=True)
    if not dist:
        return None, "No completed books available for genre distribution."
    fig = go.Figure(
        data=[
            go.Pie(
                labels=[row["genre"] for row in dist],
                values=[row["count"] for row in dist],
                customdata=[row["pages"] for row in dist],
                hole=0.58,
                marker=dict(colors=SAAS_PALETTE[: len(dist)], line=dict(color="#FFFFFF", width=2)),
                textinfo="percent",
                hovertemplate="<b>%{label}</b><br>Books: %{value} (%{percent})<br>Pages: %{customdata:,}<extra></extra>",
            )
        ]
    )
    _apply_plotly_saas_theme(fig, "Genre Distribution", height=360)
    fig.update_layout(showlegend=True, legend=dict(orientation="v", yanchor="middle", y=0.5))
    return fig, None


def build_plotly_yearly_comparison(books: list[BookRecord]) -> tuple[Optional[Any], Optional[str]]:
    """Interactive Plotly grouped comparison across years."""
    if not PLOTLY_AVAILABLE:
        return None, "Plotly is not installed. Displaying Matplotlib chart fallback."
    yearly = compute_yearly_comparison(books)
    if not yearly:
        return None, "No yearly completion records available."
    years = [str(row["year"]) for row in yearly]
    fig = go.Figure(
        data=[
            go.Bar(
                name="Completed Books",
                x=years,
                y=[row["books"] for row in yearly],
                marker_color="#6366F1",
                hovertemplate="<b>%{x}</b><br>Completed Books: %{y}<extra></extra>",
            ),
            go.Bar(
                name="Avg Pages / Book",
                x=years,
                y=[row["avg_pages"] for row in yearly],
                marker_color="#10B981",
                hovertemplate="<b>%{x}</b><br>Avg Pages/Book: %{y}<extra></extra>",
            ),
        ]
    )
    _apply_plotly_saas_theme(fig, "Yearly Reading Comparison")
    fig.update_layout(barmode="group")
    return fig, None


def build_plotly_status_distribution(books: list[BookRecord]) -> tuple[Optional[Any], Optional[str]]:
    """Interactive Plotly horizontal bar chart for status distribution."""
    if not PLOTLY_AVAILABLE:
        return None, "Plotly is not installed. Displaying Matplotlib chart fallback."
    dist = compute_status_distribution(books)
    if not dist:
        return None, "No books stored yet."
    colors = ["#10B981", "#6366F1", "#94A3B8"]
    fig = go.Figure(
        data=[
            go.Bar(
                y=[row["status"] for row in dist],
                x=[row["count"] for row in dist],
                orientation="h",
                marker_color=colors[: len(dist)],
                customdata=[row["percentage"] for row in dist],
                hovertemplate="<b>%{y}</b><br>Count: %{x} (%{customdata}%)<extra></extra>",
            )
        ]
    )
    _apply_plotly_saas_theme(fig, "Reading Status Breakdown", height=280)
    fig.update_xaxes(title_text="Books")
    return fig, None
